/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Comprehensive Syllabus & Learning Notes Database
 * Course: Diploma First-Year Engineering Mechanics (Course Code: TH-7, 2026–27)
 * Created by Jeet
 */

export interface MCQQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Challenging';
}

export interface PracticeProblem {
  id: string;
  title: string;
  level: 'Easy' | 'Medium' | 'Challenging';
  problemText: string;
  given: string[];
  toFind: string;
  hint: string;
  finalAnswer: string;
  solutionSteps: string[];
  hinglishExplanation: string;
}

export interface TopicNote {
  id: string;
  title: string;
  subheading: string;
  definition: string;
  hinglishMasterclass: string;
  keyTerms: { term: string; symbol: string; unit: string; description: string }[];
  formulas: { name: string; math: string; whenToUse: string }[];
  workedExamples: {
    title: string;
    question: string;
    given: string;
    steps: string[];
    answer: string;
  }[];
  commonMistakes: string[];
  quickRevision: string[];
  practiceQuestions: PracticeProblem[];
  mcqs: MCQQuestion[];
  calculatorId?: string;
}

export interface SyllabusUnit {
  id: number;
  code: string;
  title: string;
  shortTitle: string;
  iconName: string;
  description: string;
  weightage: string;
  topics: TopicNote[];
}

export const SYLLABUS_UNITS: SyllabusUnit[] = [
  // --------------------------------------------------------------------------
  // UNIT 1: INTRODUCTION TO MECHANICS
  // --------------------------------------------------------------------------
  {
    id: 1,
    code: 'UNIT-01',
    title: 'Introduction to Mechanics',
    shortTitle: 'Intro to Mechanics',
    iconName: 'Compass',
    weightage: '8-10 Marks',
    description: 'Foundations of Applied Mechanics, statics vs dynamics, physical quantities, SI units, Bow’s notation and transmissibility.',
    topics: [
      {
        id: 'u1-t1',
        title: 'Mechanics & Applied Mechanics',
        subheading: 'Branches: Statics and Dynamics (Kinematics & Kinetics)',
        definition: 'Mechanics is the branch of physical science that describes and predicts the state of rest or motion of bodies under the action of forces. Applied Mechanics applies these principles to practical engineering problems.',
        hinglishMasterclass: 'Bhai simple shabdo me: Mechanics matlab forces ka bodies par kya asar hota hai. Agar body ruki hui hai (rest par hai) to use Statics kehte hain (jaise pul, building, stationary truss). Agar body chal rahi hai to use Dynamics kehte hain. Dynamics ke do bache hain: Kinematics (sirf motion ki baat, bina force ki parwah kiye) aur Kinetics (force aur motion dono ki baat).',
        keyTerms: [
          { term: 'Statics', symbol: '—', unit: '—', description: 'Study of bodies at rest under the action of balanced forces.' },
          { term: 'Dynamics', symbol: '—', unit: '—', description: 'Study of bodies in motion under unbalanced forces.' },
          { term: 'Kinematics', symbol: '—', unit: '—', description: 'Study of motion without considering forces causing it.' },
          { term: 'Kinetics', symbol: '—', unit: '—', description: 'Study of motion taking into account the forces and masses involved.' },
        ],
        formulas: [
          { name: 'Newton’s Second Law', math: 'F = m × a', whenToUse: 'Whenever an unbalanced force causes a mass to accelerate.' },
          { name: 'Weight of Body', math: 'W = m × g', whenToUse: 'To calculate gravitational pull where g = 9.81 m/s².' },
        ],
        workedExamples: [
          {
            title: 'Weight calculation on Earth',
            question: 'Find the weight of an engineering component having a mass of 45 kg on Earth (g = 9.81 m/s²).',
            given: 'Mass m = 45 kg, Acceleration due to gravity g = 9.81 m/s²',
            steps: [
              'Formula: W = m × g',
              'Substitution: W = 45 × 9.81',
              'Multiplication: W = 441.45 N',
            ],
            answer: 'W = 441.45 N',
          },
          {
            title: 'Force causing acceleration',
            question: 'What horizontal force is required to accelerate a 12 kg trolley at 2.5 m/s²?',
            given: 'm = 12 kg, a = 2.5 m/s²',
            steps: [
              'Formula: F = m × a',
              'Substitution: F = 12 × 2.5',
              'Answer: F = 30 N',
            ],
            answer: 'F = 30 N',
          },
        ],
        commonMistakes: [
          'Confusing Mass (kg, scalar, constant everywhere) with Weight (N, vector, changes with gravity).',
          'Writing units of force as kg instead of Newtons (N). 1 kg-wt = 9.81 N.',
        ],
        quickRevision: [
          'Statics = Rest; Dynamics = Motion.',
          'Particle has mass but negligible dimensions.',
          'Rigid body = No deformation under applied load in ideal mechanics.',
        ],
        practiceQuestions: [
          {
            id: 'u1-p1',
            title: 'Mass vs Weight Identification',
            level: 'Easy',
            problemText: 'A casting has a weight of 981 N at sea level. What is its mass in kg?',
            given: ['Weight W = 981 N', 'g = 9.81 m/s²'],
            toFind: 'Mass m in kg',
            hint: 'Use m = W / g',
            finalAnswer: '100 kg',
            solutionSteps: ['W = m × g', 'm = 981 / 9.81 = 100 kg'],
            hinglishExplanation: 'Weight ko 9.81 se divide kar do, exact mass mil jayega.',
          },
        ],
        mcqs: [
          {
            id: 'u1-m1',
            question: 'The branch of mechanics dealing with bodies at rest is called:',
            options: ['Kinematics', 'Statics', 'Kinetics', 'Hydrodynamics'],
            correctIndex: 1,
            explanation: 'Statics specifically studies bodies in equilibrium at rest.',
            difficulty: 'Easy',
          },
          {
            id: 'u1-m2',
            question: 'Which of the following is a derived SI unit?',
            options: ['Kilogram (kg)', 'Metre (m)', 'Newton (N)', 'Second (s)'],
            correctIndex: 2,
            explanation: 'Newton is derived: 1 N = 1 kg·m/s².',
            difficulty: 'Easy',
          },
        ],
      },
      {
        id: 'u1-t2',
        title: 'Force, Characteristics & Bow’s Notation',
        subheading: 'Representation, Vector properties and Principle of Transmissibility',
        definition: 'A force is an external agent that changes or tends to change the state of rest or of uniform motion of a body. Bow’s notation is a method of lettering spaces between forces in graphical statics. Principle of Transmissibility states that the external effect of a force on a rigid body is unaltered if the force is transmitted along its line of action.',
        hinglishMasterclass: 'Bhai principle of transmissibility ko aasan bhasha me samjho: Agar ek car khadi hai, chahe tum use peeche se 500 N se dhakka do (push) ya aage se rassi baandh kar 500 N se khincho (pull) — agar line of action same hai, to car par overall external asar bilkul waisa hi hoga! Bow’s notation me forces ke beech ke khali spaces ko capital letters (A, B, C...) se naam diya jata hai.',
        keyTerms: [
          { term: 'Point of Application', symbol: 'P', unit: '—', description: 'The exact point on the body where the force acts.' },
          { term: 'Line of Action', symbol: '—', unit: '—', description: 'The infinite straight line along which the force is directed.' },
          { term: 'Bow’s Notation', symbol: 'AB, BC', unit: '—', description: 'Spaces between adjacent forces named with capital letters; forces named by adjacent spaces.' },
        ],
        formulas: [
          { name: 'Vector Representation', math: 'F̄ = Fₓ î + Fᵧ ĵ', whenToUse: 'To express force in 2D Cartesian coordinates.' },
        ],
        workedExamples: [
          {
            title: 'Bow’s Notation Force Identification',
            question: 'In a space diagram, force F lies between space A and space B. How is this force designated in vector space?',
            given: 'Spaces A and B adjacent to line of action',
            steps: [
              'Identify the space on the left / clockwise: Space A',
              'Identify the space on the right: Space B',
              'The vector in the force polygon is named ab (lowercase letters from A to B)',
            ],
            answer: 'Vector ab',
          },
        ],
        commonMistakes: [
          'Applying the principle of transmissibility to deformable/flexible bodies (it is only valid for rigid bodies).',
          'Confusing internal stress with external equilibrium when shifting a force along its line.',
        ],
        quickRevision: [
          '4 characteristics of force: Magnitude, Direction, Line of action, Point of application.',
          'Bow’s notation uses uppercase letters for spaces in space diagram and lowercase for vectors in force polygon.',
        ],
        practiceQuestions: [
          {
            id: 'u1-p2',
            title: 'Force Vector Form',
            level: 'Easy',
            problemText: 'A force of 50 N acts along the positive x-axis. Write its vector notation.',
            given: ['F = 50 N', 'θ = 0°'],
            toFind: 'Vector form',
            hint: 'F = Fx î + Fy ĵ where Fy = 0',
            finalAnswer: 'F̄ = 50 î N',
            solutionSteps: ['Fx = 50 cos(0°) = 50 N', 'Fy = 50 sin(0°) = 0 N', 'F̄ = 50 î N'],
            hinglishExplanation: 'Kyunki force sirf X axis par hai, isiliye ĵ component zero hoga.',
          },
        ],
        mcqs: [
          {
            id: 'u1-m3',
            question: 'The Principle of Transmissibility of forces is valid for:',
            options: ['Flexible bodies', 'Elastic strings', 'Rigid bodies', 'Fluids'],
            correctIndex: 2,
            explanation: 'Valid only for rigid bodies where internal deformations are negligible.',
            difficulty: 'Medium',
          },
        ],
      },
    ],
  },

  // --------------------------------------------------------------------------
  // UNIT 2: FORCE SYSTEM
  // --------------------------------------------------------------------------
  {
    id: 2,
    code: 'UNIT-02',
    title: 'Force System & Composition',
    shortTitle: 'Force System',
    iconName: 'Maximize2',
    weightage: '14-16 Marks',
    description: 'Coplanar force systems, resolution, moments, Varignon’s theorem, couples, parallelogram law with derivation, and resultant calculations.',
    topics: [
      {
        id: 'u2-t1',
        title: 'Parallelogram Law of Forces',
        subheading: 'Complete Geometric Derivation, Formulas and Special Cases',
        definition: 'If two forces acting simultaneously on a particle be represented in magnitude and direction by the two adjacent sides of a parallelogram drawn from a point, their resultant is represented in magnitude and direction by the diagonal of the parallelogram passing through that point.',
        hinglishMasterclass: 'Bhai ye Mechanics ka sabse important law hai, har exam me aata hai! Do forces P aur Q ke beech angle θ hai. R = √(P² + Q² + 2PQ cos θ). Agar dono 90° par hain (perpendicular) to cos 90° = 0 ho jata hai aur R = √(P² + Q²). Agar dono same direction me hain (θ = 0°) to R = P + Q (Maximum Resultant). Agar dono opposite hain (θ = 180°) to R = |P - Q| (Minimum Resultant).',
        keyTerms: [
          { term: 'Resultant (R)', symbol: 'R', unit: 'N', description: 'Single force which produces the same external effect as all individual forces combined.' },
          { term: 'Included Angle', symbol: 'θ', unit: '°', description: 'Angle between the lines of action of the two concurrent forces.' },
          { term: 'Inclination of Resultant', symbol: 'α', unit: '°', description: 'Angle made by the resultant R with the reference force F₁.' },
        ],
        formulas: [
          { name: 'Resultant Magnitude', math: 'R = √(F₁² + F₂² + 2F₁F₂ cos θ)', whenToUse: 'To find the resultant of any two concurrent forces at angle θ.' },
          { name: 'Direction of Resultant', math: 'tan α = (F₂ sin θ) / (F₁ + F₂ cos θ)', whenToUse: 'To find the angle α of resultant with force F₁.' },
          { name: 'Special Case: θ = 90°', math: 'R = √(F₁² + F₂²)', whenToUse: 'When the two forces are perpendicular.' },
          { name: 'Special Case: θ = 0°', math: 'R_max = F₁ + F₂', whenToUse: 'Collinear forces in the same direction.' },
        ],
        workedExamples: [
          {
            title: 'Perpendicular Forces (Mandatory User Test Case)',
            question: 'Two forces of 6 N and 8 N act at a point at right angles (θ = 90°). Find their resultant.',
            given: 'F₁ = 6 N, F₂ = 8 N, θ = 90°',
            steps: [
              'Formula: R = √(F₁² + F₂² + 2F₁F₂ cos θ)',
              'Substitution: R = √(6² + 8² + 2 × 6 × 8 × cos 90°)',
              'Step 1: R = √(36 + 64 + 96 × 0)',
              'Step 2: R = √(36 + 64 + 0)',
              'Step 3: R = √100',
              'Step 4: R = 10 N',
            ],
            answer: 'R = 10 N',
          },
          {
            title: 'Forces at 60° angle',
            question: 'Two forces of 10 N and 15 N act at an angle of 60°. Calculate the resultant and its direction.',
            given: 'F₁ = 10 N, F₂ = 15 N, θ = 60°',
            steps: [
              'R = √(10² + 15² + 2 × 10 × 15 × cos 60°)',
              'cos 60° = 0.5 => 2 × 10 × 15 × 0.5 = 150',
              'R = √(100 + 225 + 150) = √475 = 21.79 N',
              'tan α = (15 × sin 60°) / (10 + 15 × cos 60°) = 12.99 / 17.5 = 0.7423 => α = 36.59°',
            ],
            answer: 'R = 21.79 N at α = 36.59°',
          },
        ],
        commonMistakes: [
          'Forgetting that cos 90° is 0 and cos 180° is -1.',
          'Using the wrong base force when computing tan α. The force in the denominator without sine/cos is the reference force.',
        ],
        quickRevision: [
          'R_max = P + Q at θ = 0°',
          'R_min = P - Q at θ = 180°',
          'R = √(P² + Q²) at θ = 90°',
        ],
        practiceQuestions: [
          {
            id: 'u2-p1',
            title: 'Resultant of Equal Forces',
            level: 'Medium',
            problemText: 'Two equal forces F act at an angle θ = 120°. What is the magnitude of their resultant?',
            given: ['F₁ = F', 'F₂ = F', 'θ = 120°'],
            toFind: 'Resultant R in terms of F',
            hint: 'cos 120° = -0.5',
            finalAnswer: 'R = F',
            solutionSteps: [
              'R = √(F² + F² + 2F² cos 120°)',
              'cos 120° = -0.5 => 2F² × (-0.5) = -F²',
              'R = √(2F² - F²) = √F² = F',
            ],
            hinglishExplanation: 'Jab do barabar forces 120° par lagte hain, to unka resultant bhi unke barabar hi hota hai!',
          },
        ],
        mcqs: [
          {
            id: 'u2-m1',
            question: 'Two forces of 3 N and 4 N act at 90°. What is their resultant?',
            options: ['7 N', '1 N', '5 N', '12 N'],
            correctIndex: 2,
            explanation: 'R = √(3² + 4²) = √(9 + 16) = √25 = 5 N.',
            difficulty: 'Easy',
          },
          {
            id: 'u2-m2',
            question: 'The maximum resultant of two forces 10 N and 6 N is:',
            options: ['4 N', '16 N', '8 N', '60 N'],
            correctIndex: 1,
            explanation: 'R_max = F₁ + F₂ = 10 + 6 = 16 N (at θ = 0°).',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'parallelogram_law',
      },
      {
        id: 'u2-t2',
        title: 'Resolution of Forces & Moment / Varignon’s Theorem',
        subheading: 'Rectangular components, Varignon’s principle of moments, and couples',
        definition: 'Resolution is the process of splitting a single force into two mutually perpendicular components without changing its external effect. Varignon’s Theorem states that the moment of a force about any point is equal to the algebraic sum of the moments of its components about that same point.',
        hinglishMasterclass: 'Bhai Varignon’s Theorem ek jadoo hai! Agar kisi tirche (inclined) force ka moment lena mushkil lag raha ho, to us force ko horizontal (Fx) aur vertical (Fy) me tod lo. Fir dono components ka alag alag moment le kar add kar do — answer bilkul wahi aayega!',
        keyTerms: [
          { term: 'Moment (M)', symbol: 'M', unit: 'N·m', description: 'Rotational effect of force = Force × Perpendicular distance.' },
          { term: 'Couple', symbol: 'C', unit: 'N·m', description: 'Two equal, opposite, and non-collinear parallel forces.' },
          { term: 'Arm of Couple', symbol: 'a', unit: 'm', description: 'Perpendicular distance between the lines of action of the two forces.' },
        ],
        formulas: [
          { name: 'Horizontal Component', math: 'Fₓ = F cos θ', whenToUse: 'When angle θ is measured with the horizontal axis.' },
          { name: 'Vertical Component', math: 'Fᵧ = F sin θ', whenToUse: 'When angle θ is measured with the horizontal axis.' },
          { name: 'Moment of Force', math: 'M = F × d_⟂', whenToUse: 'Turning effect about a point.' },
          { name: 'Moment of Couple', math: 'C = F × a', whenToUse: 'Pure torque generated by a couple.' },
        ],
        workedExamples: [
          {
            title: 'Force Resolution',
            question: 'Resolve a force of 100 N acting at an inclination of 30° to the horizontal into rectangular components.',
            given: 'F = 100 N, θ = 30°',
            steps: [
              'Fₓ = F cos 30° = 100 × 0.866 = 86.60 N',
              'Fᵧ = F sin 30° = 100 × 0.500 = 50.00 N',
            ],
            answer: 'Fₓ = 86.60 N, Fᵧ = 50.00 N',
          },
          {
            title: 'Moment about pivot',
            question: 'A horizontal force of 40 N is applied at the end of a spanner 0.25 m long. Calculate the turning moment.',
            given: 'F = 40 N, d = 0.25 m, θ = 90°',
            steps: [
              'M = F × d = 40 × 0.25 = 10 N·m',
            ],
            answer: 'M = 10 N·m',
          },
        ],
        commonMistakes: [
          'Using sine for horizontal component when angle is with horizontal (cos should be used).',
          'Forgetting that couple has NO resultant force (ΣF = 0), so it only rotates, never translates.',
        ],
        quickRevision: [
          'Varignon: M = Σ(moments of components).',
          'Couple = F × a; Resultant force of a couple = 0.',
          'Clockwise moment is usually taken negative, Anti-clockwise positive (or vice-versa consistently).',
        ],
        practiceQuestions: [
          {
            id: 'u2-p2',
            title: 'Couple on Steering Wheel',
            level: 'Easy',
            problemText: 'A driver applies two equal and opposite forces of 20 N on a steering wheel of diameter 0.4 m. Calculate the couple.',
            given: ['F = 20 N', 'a = 0.4 m'],
            toFind: 'Couple C in N·m',
            hint: 'C = F × a',
            finalAnswer: '8 N·m',
            solutionSteps: ['C = F × a = 20 × 0.4 = 8 N·m'],
            hinglishExplanation: 'Steering wheel ka diameter hi couple ki arm distance hoti hai.',
          },
        ],
        mcqs: [
          {
            id: 'u2-m3',
            question: 'The resultant force of a couple is always:',
            options: ['Infinite', 'Zero', 'F × a', '2F'],
            correctIndex: 1,
            explanation: 'Forces are equal and opposite (+F - F = 0), so resultant force is zero.',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'force_resolution',
      },
    ],
  },

  // --------------------------------------------------------------------------
  // UNIT 3: EQUILIBRIUM
  // --------------------------------------------------------------------------
  {
    id: 3,
    code: 'UNIT-03',
    title: 'Equilibrium & Support Reactions',
    shortTitle: 'Equilibrium',
    iconName: 'Scale',
    weightage: '14-16 Marks',
    description: 'Conditions of equilibrium, Free-Body Diagrams (FBD), Lami’s theorem, types of beams, loads and support reaction calculations.',
    topics: [
      {
        id: 'u3-t1',
        title: 'Conditions of Equilibrium & Lami’s Theorem',
        subheading: 'Equations of equilibrium and 3-force concurrent coplanar theorem',
        definition: 'A body is said to be in equilibrium when the resultant of all forces acting upon it is zero. Lami’s Theorem states that if three coplanar forces acting at a point are in equilibrium, each force is proportional to the sine of the angle between the other two forces.',
        hinglishMasterclass: 'Bhai Lami’s Theorem exam ka favorite question hai! Equation hoti hai: P/sin α = Q/sin β = R/sin γ. Par dhyan rahe: ye tabhi lag sakta hai jab teen (3) forces hon, teeno ek hi point par mil rahe hon (concurrent), aur body poori tarah shaant (equilibrium) me ho!',
        keyTerms: [
          { term: 'Equilibrant', symbol: 'E', unit: 'N', description: 'Single force that balances a given force system (equal in magnitude, opposite in direction to Resultant R).' },
          { term: 'Free Body Diagram (FBD)', symbol: 'FBD', unit: '—', description: 'Diagram showing isolated body with all external forces and support reactions acting on it.' },
        ],
        formulas: [
          { name: 'Coplanar Equilibrium Equations', math: 'ΣFₓ = 0,  ΣFᵧ = 0,  ΣM = 0', whenToUse: 'General 2D equilibrium conditions.' },
          { name: 'Lami’s Theorem', math: 'P / sin α = Q / sin β = R / sin γ', whenToUse: 'Equilibrium of exactly 3 concurrent coplanar forces.' },
        ],
        workedExamples: [
          {
            title: 'Lami’s Theorem Application',
            question: 'An electric lamp of weight 60 N hangs from a point O by two cords making angles 120° and 150° with the vertical cord. Find tensions T₁ and T₂.',
            given: 'W = 60 N, angles between pairs: α = 150°, β = 120°, γ = 90°',
            steps: [
              'Third angle = 360° - (120° + 150°) = 90°',
              'By Lami’s Theorem: T₁/sin 150° = T₂/sin 120° = 60/sin 90°',
              'sin 90° = 1.0 => Ratio = 60',
              'T₁ = 60 × sin 150° = 60 × 0.5 = 30 N',
              'T₂ = 60 × sin 120° = 60 × 0.866 = 51.96 N',
            ],
            answer: 'T₁ = 30 N, T₂ = 51.96 N',
          },
        ],
        commonMistakes: [
          'Using Lami’s theorem when 4 forces act at a point (it is ONLY valid for 3 forces).',
          'Taking the angle between the force and vertical instead of the angle between the other two forces.',
        ],
        quickRevision: [
          'Resultant + Equilibrant = 0.',
          'Lami’s theorem is the trigonometric sine rule applied to concurrent force polygon.',
        ],
        practiceQuestions: [
          {
            id: 'u3-p1',
            title: 'Symmetric 3-Force Equilibrium',
            level: 'Medium',
            problemText: 'Three forces of equal magnitude F hold a ring in equilibrium. What must be the angle between each pair of forces?',
            given: ['F₁ = F₂ = F₃ = F'],
            toFind: 'Angle θ between forces',
            hint: 'By symmetry, 360° / 3',
            finalAnswer: '120° each',
            solutionSteps: ['For equal forces in Lami’s theorem, sin α = sin β = sin γ => α = β = γ = 360° / 3 = 120°'],
            hinglishExplanation: 'Kyunki teeno forces barabar hain, isiliye angles bhi bilkul barabar (120°) honge.',
          },
        ],
        mcqs: [
          {
            id: 'u3-m1',
            question: 'Lami’s theorem is applicable for the equilibrium of how many forces?',
            options: ['Two forces', 'Three concurrent forces', 'Four parallel forces', 'Any number of forces'],
            correctIndex: 1,
            explanation: 'Lami’s theorem applies strictly to 3 concurrent, coplanar forces.',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'lamis_theorem',
      },
      {
        id: 'u3-t2',
        title: 'Beams, Types of Loads & Support Reactions',
        subheading: 'Simply supported beams with point loads and UDLs',
        definition: 'A beam is a structural member subjected to transverse loads that cause bending. A simply supported beam rests on a hinged support at one end and a roller support at the other. Support reactions are calculated using ΣFy = 0 and ΣM = 0.',
        hinglishMasterclass: 'Bhai beam ke reaction nikalne ka 2-step brahmastra: Step 1: Support A par moment lo (ΣM_A = 0) — isse support B ka reaction R_B mil jayega. Step 2: ΣFy = 0 lagao, yaani Total Upward Forces = Total Downward Forces, isse R_A = Total Load - R_B nikal aayega. UDL (Uniformly Distributed Load) ka total load = w × L hota hai aur wo hamesha center (L/2) par act karta hai!',
        keyTerms: [
          { term: 'Simply Supported Beam', symbol: 'SSB', unit: '—', description: 'Beam supported on roller at one end and pin/hinge at the other.' },
          { term: 'Point Load', symbol: 'W', unit: 'N', description: 'Load concentrated at a single point.' },
          { term: 'UDL', symbol: 'w', unit: 'N/m', description: 'Uniformly Distributed Load spread over beam length.' },
        ],
        formulas: [
          { name: 'Vertical Equilibrium', math: 'R_A + R_B = Σ(Loads)', whenToUse: 'To balance all vertical forces on the beam.' },
          { name: 'Moment Equilibrium', math: 'ΣM_A = 0', whenToUse: 'Taking moment about support A to find reaction R_B.' },
        ],
        workedExamples: [
          {
            title: 'Simply Supported Beam with Point Load',
            question: 'A beam of span 6 m has a point load of 1200 N at 2 m from left support A. Find reactions R_A and R_B.',
            given: 'L = 6 m, W = 1200 N at a = 2 m',
            steps: [
              'ΣM_A = 0 => R_B × 6 - 1200 × 2 = 0',
              'R_B × 6 = 2400 => R_B = 400 N',
              'R_A = 1200 - R_B = 1200 - 400 = 800 N',
            ],
            answer: 'R_A = 800 N, R_B = 400 N',
          },
        ],
        commonMistakes: [
          'Forgetting that UDL total load is w × L and acts at distance L/2.',
          'Mixing up units: using kN for load and N·m for moment without converting.',
        ],
        quickRevision: [
          'Roller support provides 1 vertical reaction.',
          'Hinged support provides 2 reactions (horizontal and vertical).',
          'Fixed support provides 3 reactions (horizontal, vertical, and resisting moment).',
        ],
        practiceQuestions: [
          {
            id: 'u3-p2',
            title: 'Central Point Load Beam',
            level: 'Easy',
            problemText: 'A simply supported beam of span 4 m carries a point load of 500 N at its center. Find reactions R_A and R_B.',
            given: ['L = 4 m', 'W = 500 N at mid-span'],
            toFind: 'R_A and R_B',
            hint: 'Due to symmetry, load divides equally.',
            finalAnswer: 'R_A = 250 N, R_B = 250 N',
            solutionSteps: ['By symmetry, R_A = R_B = W / 2 = 500 / 2 = 250 N'],
            hinglishExplanation: 'Jab load theek beech me hota hai, to dono supports par aadha aadha load bat jata hai.',
          },
        ],
        mcqs: [
          {
            id: 'u3-m2',
            question: 'How many reaction components are present at a roller support in 2D?',
            options: ['One', 'Two', 'Three', 'Zero'],
            correctIndex: 0,
            explanation: 'A roller support can only resist motion perpendicular to the plane of rollers (1 normal reaction).',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'beam_reactions',
      },
    ],
  },

  // --------------------------------------------------------------------------
  // UNIT 4: FRICTION
  // --------------------------------------------------------------------------
  {
    id: 4,
    code: 'UNIT-04',
    title: 'Friction on Planes & Ladders',
    shortTitle: 'Friction',
    iconName: 'Shield',
    weightage: '12-14 Marks',
    description: 'Coulomb friction laws, limiting friction, coefficient of friction, angle of friction, angle of repose, horizontal & inclined planes, and ladder friction.',
    topics: [
      {
        id: 'u4-t1',
        title: 'Laws of Friction, μ, Angle of Friction & Repose',
        subheading: 'Definitions, Limiting equilibrium and Derivation of μ = tan φ',
        definition: 'Friction is the tangential resisting force that opposes the relative motion or tendency of motion between two surfaces in contact. Limiting friction is the maximum static friction force before motion begins. Coefficient of friction μ = F_lim / N. Angle of friction φ is the angle made by the resultant reaction with normal reaction.',
        hinglishMasterclass: 'Bhai friction ka rule: Friction tab tak chupchap baithta hai jab tak motion shuru na ho. Jaise hi tum body ko dhakka dete ho, friction oppose karta hai. Jo maximum taakat lagti hai hilane ke liye use Limiting Friction kehte hain (F = μN). Angle of Repose (α) wo dhaal (slope) ka angle hai jiss par rakhi hui cheez bina kisi dhakke ke apne aap fisalna shuru kar de — aur sabse mazedar baat: μ = tan φ = tan α_repose!',
        keyTerms: [
          { term: 'Coefficient of Friction', symbol: 'μ', unit: '— (dimensionless)', description: 'Ratio of limiting friction to normal reaction (μ = F/N).' },
          { term: 'Angle of Friction', symbol: 'φ', unit: '°', description: 'Angle between normal reaction N and total reaction R.' },
          { term: 'Angle of Repose', symbol: 'α_repose', unit: '°', description: 'Maximum inclination of plane at which a body remains in equilibrium without sliding.' },
        ],
        formulas: [
          { name: 'Limiting Friction', math: 'F_{lim} = μ × N', whenToUse: 'When body is on the verge of motion.' },
          { name: 'Relation between μ and φ', math: 'μ = tan φ', whenToUse: 'To find angle of friction from coefficient or vice versa.' },
          { name: 'Angle of Repose Equality', math: 'α_{repose} = φ', whenToUse: 'Proving angle of repose equals angle of friction.' },
        ],
        workedExamples: [
          {
            title: 'Horizontal Surface Pull',
            question: 'A block of weight 200 N rests on a floor with μ = 0.25. Find the minimum horizontal force required to cause impending motion.',
            given: 'W = 200 N, μ = 0.25, pull angle θ = 0°',
            steps: [
              'Normal Reaction N = W = 200 N',
              'Limiting Friction F_lim = μ × N = 0.25 × 200 = 50 N',
              'Minimum Effort P = F_lim = 50 N',
            ],
            answer: 'P = 50 N',
          },
        ],
        commonMistakes: [
          'Assuming friction always equals μN. It ONLY equals μN at limiting equilibrium (impending motion); otherwise F ≤ μN.',
          'Drawing friction in the direction of motion instead of OPPOSITE to motion.',
        ],
        quickRevision: [
          'Static friction is self-adjusting up to limiting friction.',
          'Dynamic friction is slightly less than limiting friction.',
          'μ is purely a surface-property ratio, has no units.',
        ],
        practiceQuestions: [
          {
            id: 'u4-p1',
            title: 'Angle of Friction Calculation',
            level: 'Easy',
            problemText: 'The coefficient of friction between steel and wood is 0.577. Find the angle of friction in degrees.',
            given: ['μ = 0.577'],
            toFind: 'Angle φ',
            hint: 'φ = tan⁻¹(μ)',
            finalAnswer: '30°',
            solutionSteps: ['φ = tan⁻¹(0.577) ≈ 30°'],
            hinglishExplanation: 'tan 30° = 1/√3 ≈ 0.577, isiliye angle 30 degree hoga.',
          },
        ],
        mcqs: [
          {
            id: 'u4-m1',
            question: 'The relationship between coefficient of friction μ and angle of friction φ is:',
            options: ['μ = sin φ', 'μ = cos φ', 'μ = tan φ', 'μ = cot φ'],
            correctIndex: 2,
            explanation: 'By definition, tan φ = F/N = μ.',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'horizontal_friction',
      },
      {
        id: 'u4-t2',
        title: 'Inclined Plane & Ladder Friction',
        subheading: 'Motion impending UP and DOWN the incline, and ladder equilibrium',
        definition: 'On an inclined plane at angle α, gravity resolves into W cos α (pressing onto the plane) and W sin α (pulling down along the plane). For motion impending UP, effort P = W(sin α + μ cos α). For ladder friction, moments are taken about the base or wall contact to evaluate slipping.',
        hinglishMasterclass: 'Bhai inclined plane par sabse badi galti hoti hai normal reaction lene me! Incline par N = W cos α hota hai (W nahi!). Agar body ko UPAR khinchna hai to friction NEECHE lagega, isiliye force zyada lagta hai P = W(sin α + μ cos α). Agar ladder ki baat karein to ladder neeche floor par slip hona chahti hai bahar ki taraf, isiliye floor friction deewar ki taraf andar lagega!',
        keyTerms: [
          { term: 'Normal Reaction on Incline', symbol: 'N', unit: 'N', description: 'N = W cos α perpendicular to plane.' },
          { term: 'Ladder Friction', symbol: 'F_f, F_w', unit: 'N', description: 'Friction forces at floor and wall preventing ladder slipping.' },
        ],
        formulas: [
          { name: 'Effort to pull UP incline', math: 'P_{up} = W (sin α + μ cos α)', whenToUse: 'When applied force is parallel to incline and pulls body up.' },
          { name: 'Effort to prevent sliding DOWN', math: 'P_{down} = W (sin α - μ cos α)', whenToUse: 'Minimum supporting force to keep body from slipping down.' },
        ],
        workedExamples: [
          {
            title: 'Pulling body up incline',
            question: 'A 100 N body lies on a 30° plane with μ = 0.2. What force parallel to the plane is needed to move it UP?',
            given: 'W = 100 N, α = 30°, μ = 0.2',
            steps: [
              'N = W cos 30° = 100 × 0.866 = 86.60 N',
              'F_lim = μ × N = 0.2 × 86.60 = 17.32 N',
              'Gravity down plane = W sin 30° = 100 × 0.5 = 50.00 N',
              'P = 50.00 + 17.32 = 67.32 N',
            ],
            answer: 'P = 67.32 N',
          },
        ],
        commonMistakes: [
          'Using N = W on an inclined plane instead of N = W cos α.',
          'Subtracting friction when pulling UP (friction opposes upward motion, so it adds to gravity component).',
        ],
        quickRevision: [
          'If α < φ: Body will NOT slide down on its own.',
          'If α > φ: Body will slide down automatically unless supported.',
        ],
        practiceQuestions: [
          {
            id: 'u4-p2',
            title: 'Self-holding on Incline',
            level: 'Medium',
            problemText: 'A plane has angle 20° and μ = 0.4. Will the body slide down on its own?',
            given: ['α = 20°', 'μ = 0.4'],
            toFind: 'Whether body slides',
            hint: 'Find angle of repose φ = tan⁻¹(0.4)',
            finalAnswer: 'No, body is safe (will not slide)',
            solutionSteps: ['φ = tan⁻¹(0.4) = 21.8°', 'Since α (20°) < φ (21.8°), friction holds the body in resting equilibrium.'],
            hinglishExplanation: 'Kyunki incline angle (20°) angle of repose (21.8°) se chhota hai, body bilkul nahi fislegi.',
          },
        ],
        mcqs: [
          {
            id: 'u4-m2',
            question: 'On an inclined plane of angle α, normal reaction N is equal to:',
            options: ['W', 'W sin α', 'W cos α', 'W tan α'],
            correctIndex: 2,
            explanation: 'The perpendicular component of gravity is W cos α.',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'inclined_friction',
      },
    ],
  },

  // --------------------------------------------------------------------------
  // UNIT 5: CENTROID AND CENTRE OF GRAVITY
  // --------------------------------------------------------------------------
  {
    id: 5,
    code: 'UNIT-05',
    title: 'Centroid & Centre of Gravity',
    shortTitle: 'Centroid & CG',
    iconName: 'Target',
    weightage: '12-14 Marks',
    description: 'Centroid of standard 2D shapes, composite figures, C, I, L, T sections, and Centre of Gravity of 3D solids.',
    topics: [
      {
        id: 'u5-t1',
        title: 'Centroid of Standard Shapes & T/I Sections',
        subheading: 'Centroid vs CG, formulas for 2D figures, and composite tabular method',
        definition: 'Centroid is the geometric center of a 2D plane area (where the entire area may be assumed to be concentrated). Centre of Gravity (CG) is the point through which the whole weight of a 3D body acts. For composite shapes, X̄ = Σ(Ai × xi) / ΣAi and Ȳ = Σ(Ai × yi) / ΣAi.',
        hinglishMasterclass: 'Bhai Centroid aur Center of Gravity me antar pakdo: Centroid 2D areas (kisi kagaz ke tukde ya cross section) ka hota hai, isme mass/weight ka koi lena dena nahi hota. CG 3D solid bodies (cone, sphere, cylinder) ka hota hai jahan poora wajan act karta hai! Composite figure me har tukde ka Area nikaalo, uska x aur y coordinate nikaalo, fir weighted average formula laga do!',
        keyTerms: [
          { term: 'Centroid', symbol: 'G(X̄, Ȳ)', unit: 'mm or m', description: 'Center of area for plane laminas.' },
          { term: 'Centre of Gravity', symbol: 'C.G.', unit: 'mm or m', description: 'Center of gravity / weight for solid 3D bodies.' },
          { term: 'Axis of Symmetry', symbol: '—', unit: '—', description: 'Line about which shape is mirrored; centroid always lies on this axis.' },
        ],
        formulas: [
          { name: 'Composite Centroid X̄', math: 'X̄ = (A₁x₁ + A₂x₂ + ...) / (A₁ + A₂ + ...)', whenToUse: 'Finding horizontal centroid coordinate of combined shape.' },
          { name: 'Composite Centroid Ȳ', math: 'Ȳ = (A₁y₁ + A₂y₂ + ...) / (A₁ + A₂ + ...)', whenToUse: 'Finding vertical centroid coordinate of combined shape.' },
          { name: 'Semicircle Centroid', math: 'Ȳ = 4r / (3π)', whenToUse: 'Distance from diameter base to centroid.' },
          { name: 'Triangle Centroid', math: 'Ȳ = h / 3', whenToUse: 'Distance from base of triangle to centroid.' },
        ],
        workedExamples: [
          {
            title: 'T-Section Centroid (Standard Example)',
            question: 'Find the centroid of a T-section with flange 100 × 20 mm and web 20 × 80 mm from the bottom base.',
            given: 'Flange: 100 × 20 mm, Web: 20 × 80 mm',
            steps: [
              'Part 1 (Web): A₁ = 20 × 80 = 1600 mm², y₁ = 80/2 = 40 mm, A₁y₁ = 64,000 mm³',
              'Part 2 (Flange): A₂ = 100 × 20 = 2000 mm², y₂ = 80 + 10 = 90 mm, A₂y₂ = 180,000 mm³',
              'Total Area ΣA = 1600 + 2000 = 3600 mm²',
              'Total Ay = 64,000 + 180,000 = 244,000 mm³',
              'Ȳ = 244,000 / 3600 = 67.78 mm',
              'By vertical symmetry, X̄ = 100 / 2 = 50 mm',
            ],
            answer: 'X̄ = 50 mm, Ȳ = 67.78 mm from bottom',
          },
        ],
        commonMistakes: [
          'Measuring y₂ for flange from its own local base instead of the global reference axis at the bottom of the web.',
          'Subtracting cutout areas without making their area negative.',
        ],
        quickRevision: [
          'Rectangle: b/2, d/2',
          'Right triangle: b/3, h/3 from 90° corner',
          'Circle: at center',
          'Semicircle: 4r/(3π) ≈ 0.424r from base',
          'Hemisphere C.G.: 3r/8 from flat base',
          'Right circular cone C.G.: h/4 from circular base',
        ],
        practiceQuestions: [
          {
            id: 'u5-p1',
            title: 'Semicircle Centroid Distance',
            level: 'Easy',
            problemText: 'A semicircle has radius r = 30 mm. How far is its centroid from the straight base?',
            given: ['r = 30 mm'],
            toFind: 'Ȳ distance',
            hint: 'Use Ȳ = 4r / (3π)',
            finalAnswer: '12.73 mm',
            solutionSteps: ['Ȳ = (4 × 30) / (3 × π) = 120 / 9.4248 = 12.73 mm'],
            hinglishExplanation: 'Formula 4r / (3π) direct lagao, value 12.73 mm aayegi.',
          },
        ],
        mcqs: [
          {
            id: 'u5-m1',
            question: 'The centroid of a triangle of height h from its base lies at a distance of:',
            options: ['h / 2', 'h / 3', '2h / 3', 'h / 4'],
            correctIndex: 1,
            explanation: 'From base it is h/3; from vertex it is 2h/3.',
            difficulty: 'Easy',
          },
          {
            id: 'u5-m2',
            question: 'The centre of gravity of a solid cone of height h from its base is at:',
            options: ['h / 2', 'h / 3', 'h / 4', '3h / 8'],
            correctIndex: 2,
            explanation: 'For a solid right circular cone, CG is at h/4 from base.',
            difficulty: 'Medium',
          },
        ],
        calculatorId: 'centroid_t_section',
      },
    ],
  },

  // --------------------------------------------------------------------------
  // UNIT 6: MOMENT OF INERTIA
  // --------------------------------------------------------------------------
  {
    id: 6,
    code: 'UNIT-06',
    title: 'Moment of Inertia (Area MOI)',
    shortTitle: 'Moment of Inertia',
    iconName: 'Box',
    weightage: '12-14 Marks',
    description: 'Second moment of area, standard formulas, Parallel Axis Theorem, Perpendicular Axis Theorem, and composite section MOI.',
    topics: [
      {
        id: 'u6-t1',
        title: 'Area Moment of Inertia & Theorems',
        subheading: 'Parallel axis theorem, perpendicular axis theorem, and standard shapes',
        definition: 'Area Moment of Inertia (Second Moment of Area) is the capacity of a cross-section to resist bending about an axis. Parallel Axis Theorem states that I_AB = I_G + A·h², where I_G is MOI about centroidal axis, A is area, and h is distance between axes. Perpendicular Axis Theorem states that for planar lamina, I_zz = I_xx + I_yy.',
        hinglishMasterclass: 'Bhai Moment of Inertia (MOI) beam ki taakat hoti hai! Agar kisi scale ya rular ko flat rakh ke jhukao to aasani se mud jata hai, par usi ko vertical khada karke jhukane ki koshish karo to bilkul nahi jhukta! Kyun? Kyunki khada karne par depth d badh gayi aur I = bd³/12 me d ka cube (³) hota hai! Parallel axis theorem bolta hai: kisi bhi parallel axis par MOI nikalna ho to Centroidal MOI (I_G) me Area × (distance)² jod do!',
        keyTerms: [
          { term: 'Second Moment of Area', symbol: 'I', unit: 'mm⁴ or m⁴', description: 'Geometric property measuring bending resistance.' },
          { term: 'Radius of Gyration', symbol: 'k', unit: 'mm', description: 'k = √(I / A), distance from axis at which entire area could be concentrated.' },
          { term: 'Polar Moment of Inertia', symbol: 'J or I_zz', unit: 'mm⁴', description: 'MOI about axis perpendicular to the plane (I_zz = I_xx + I_yy).' },
        ],
        formulas: [
          { name: 'Rectangle Centroidal MOI', math: 'I_{xx} = (b × d³) / 12,  I_{yy} = (d × b³) / 12', whenToUse: 'For rectangle of width b and depth d.' },
          { name: 'Circle Centroidal MOI', math: 'I_{xx} = I_{yy} = (π × d⁴) / 64', whenToUse: 'For solid circular section of diameter d.' },
          { name: 'Parallel Axis Theorem', math: 'I_{AB} = I_G + A × h²', whenToUse: 'Transferring MOI from centroidal axis to any parallel axis.' },
          { name: 'Perpendicular Axis Theorem', math: 'I_{zz} = I_{xx} + I_{yy}', whenToUse: 'Finding polar MOI for plane laminas.' },
        ],
        workedExamples: [
          {
            title: 'Rectangle MOI about base',
            question: 'Find the MOI of a rectangular section 30 mm wide and 60 mm deep about its base using Parallel Axis Theorem.',
            given: 'b = 30 mm, d = 60 mm, h = d/2 = 30 mm',
            steps: [
              'I_G = (b × d³) / 12 = (30 × 60³) / 12 = (30 × 216,000) / 12 = 540,000 mm⁴',
              'Area A = 30 × 60 = 1800 mm²',
              'h = 60 / 2 = 30 mm => A × h² = 1800 × 30² = 1800 × 900 = 1,620,000 mm⁴',
              'I_base = I_G + A h² = 540,000 + 1,620,000 = 2,160,000 mm⁴',
              'Verification using bd³/3 = (30 × 60³) / 3 = 2,160,000 mm⁴. Perfect match!',
            ],
            answer: 'I_base = 2.16 × 10⁶ mm⁴',
          },
        ],
        commonMistakes: [
          'Confusing area moment of inertia (mm⁴) with mass moment of inertia (kg·m²).',
          'Applying the parallel axis theorem from a non-centroidal axis (one of the two axes MUST be the centroidal axis).',
        ],
        quickRevision: [
          'Rectangle: I_xx = bd³/12, I_base = bd³/3',
          'Circle: I = πd⁴/64',
          'Triangle: I_G = bh³/36, I_base = bh³/12',
          'Polar MOI: J = πd⁴/32',
        ],
        practiceQuestions: [
          {
            id: 'u6-p1',
            title: 'Circular Shaft MOI',
            level: 'Easy',
            problemText: 'A circular pin has diameter d = 20 mm. Find its centroidal moment of inertia.',
            given: ['d = 20 mm'],
            toFind: 'I_xx in mm⁴',
            hint: 'I = π d⁴ / 64',
            finalAnswer: '7853.98 mm⁴',
            solutionSteps: ['d⁴ = 20⁴ = 160,000', 'I = (π × 160,000) / 64 = 7853.98 mm⁴'],
            hinglishExplanation: '20 ki power 4 nikaal kar π se multiply aur 64 se divide karo.',
          },
        ],
        mcqs: [
          {
            id: 'u6-m1',
            question: 'The unit of Area Moment of Inertia in SI is:',
            options: ['m²', 'm³', 'm⁴', 'N·m'],
            correctIndex: 2,
            explanation: 'Area (m²) × distance squared (m²) = m⁴.',
            difficulty: 'Easy',
          },
          {
            id: 'u6-m2',
            question: 'The moment of inertia of a triangle of base b and height h about its centroidal axis is:',
            options: ['bh³ / 12', 'bh³ / 36', 'bh³ / 24', 'bh³ / 4'],
            correctIndex: 1,
            explanation: 'Centroidal is bh³/36; about base is bh³/12.',
            difficulty: 'Medium',
          },
        ],
        calculatorId: 'moi_rectangle',
      },
    ],
  },

  // --------------------------------------------------------------------------
  // UNIT 7: SIMPLE LIFTING MACHINES
  // --------------------------------------------------------------------------
  {
    id: 7,
    code: 'UNIT-07',
    title: 'Simple Lifting Machines',
    shortTitle: 'Lifting Machines',
    iconName: 'Cpu',
    weightage: '14-16 Marks',
    description: 'MA, VR, efficiency, law of machine, friction in machines, reversibility, wheel & axle, winch crabs, screw jacks, and pulley systems.',
    topics: [
      {
        id: 'u7-t1',
        title: 'Machine Principles & Reversibility',
        subheading: 'MA, VR, Efficiency, Friction losses and Self-locking condition',
        definition: 'A machine is a device which receives energy in some available form and utilizes it to do some particular kind of work. Mechanical Advantage MA = W / P. Velocity Ratio VR = distance moved by effort / distance moved by load. Efficiency η = (MA / VR) × 100%. A machine is reversible if η > 50%, and self-locking if η ≤ 50%.',
        hinglishMasterclass: 'Bhai ye unit numericals ke liye goldmine hai! Load (W) jo uthana hai, Effort (P) jo hum laga rahe hain. Mechanical Advantage (MA) batata hai humne kitna fayda uthaya (W/P). Velocity Ratio (VR) machine ki geometry se nikalta hai aur kabhi nahi badalta chahe friction ho ya na ho! Reversibility ka golden rule: Agar efficiency 50% se zyada hai to effort chhodte hi load gir padega (Reversible). Screw Jack me car uthane ke baad car niche nahi girti kyunki uski efficiency 50% se kam hoti hai (Self-locking)!',
        keyTerms: [
          { term: 'Mechanical Advantage', symbol: 'M.A.', unit: '—', description: 'Ratio of load lifted to effort applied (W/P).' },
          { term: 'Velocity Ratio', symbol: 'V.R.', unit: '—', description: 'Ratio of displacement of effort to displacement of load (y/x).' },
          { term: 'Law of Machine', symbol: 'P = mW + C', unit: 'P in N', description: 'Linear relation between effort P and load W, where m = slope, C = friction intercept.' },
          { term: 'Self-Locking Machine', symbol: 'η ≤ 50%', unit: '—', description: 'Machine incapable of doing reverse work when effort is removed.' },
        ],
        formulas: [
          { name: 'Mechanical Advantage', math: 'M.A. = W / P', whenToUse: 'General definition of advantage.' },
          { name: 'Efficiency', math: 'η = (M.A. / V.R.) × 100%', whenToUse: 'Calculating overall mechanical efficiency.' },
          { name: 'Effort lost in friction', math: 'P_f = P - (W / V.R.)', whenToUse: 'Actual effort minus ideal effort.' },
          { name: 'Maximum Mechanical Advantage', math: 'M.A._{max} = 1 / m', whenToUse: 'From law of machine P = mW + C as W approaches infinity.' },
        ],
        workedExamples: [
          {
            title: 'Efficiency & Reversibility Test',
            question: 'In a machine with VR = 20, an effort of 25 N lifts a load of 400 N. Find MA, efficiency, and test reversibility.',
            given: 'VR = 20, P = 25 N, W = 400 N',
            steps: [
              'MA = W / P = 400 / 25 = 16',
              'η = (MA / VR) × 100% = (16 / 20) × 100% = 80%',
              'Since 80% > 50%, the machine is REVERSIBLE.',
            ],
            answer: 'MA = 16, η = 80%, Reversible',
          },
        ],
        commonMistakes: [
          'Thinking VR depends on friction (VR is purely geometric and constant for a machine).',
          'Declaring a screw jack reversible when efficiency is 35% (it is self-locking because 35% ≤ 50%).',
        ],
        quickRevision: [
          'Ideal machine: η = 100%, MA = VR.',
          'Reversible: η > 50%; Self-locking: η ≤ 50%.',
          'Law of machine: P = mW + C; Max MA = 1/m; Max η = 1 / (m × VR).',
        ],
        practiceQuestions: [
          {
            id: 'u7-p1',
            title: 'Effort Lost in Friction',
            level: 'Medium',
            problemText: 'A machine has VR = 10. To lift 500 N, an effort of 80 N is required. Find effort lost in friction.',
            given: ['VR = 10', 'W = 500 N', 'P = 80 N'],
            toFind: 'P_f in N',
            hint: 'P_ideal = W / VR = 50 N',
            finalAnswer: '30 N',
            solutionSteps: ['P_ideal = 500 / 10 = 50 N', 'P_f = P - P_ideal = 80 - 50 = 30 N'],
            hinglishExplanation: 'Asli effort 80 N me se 50 N load uthane me laga aur 30 N friction me barbaad ho gaya.',
          },
        ],
        mcqs: [
          {
            id: 'u7-m1',
            question: 'For a self-locking lifting machine, the efficiency must be:',
            options: ['Greater than 50%', 'Equal to 100%', 'Less than or equal to 50%', 'Zero'],
            correctIndex: 2,
            explanation: 'Self-locking requires η ≤ 50% so friction energy exceeds potential energy.',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'lifting_machine',
      },
      {
        id: 'u7-t2',
        title: 'Individual Machines: Wheel & Axle, Screw Jack, Winch, Pulleys',
        subheading: 'Velocity ratio formulas and geometric calculations for all syllabus machines',
        definition: 'Each simple machine possesses a distinct velocity ratio determined by its dimensions. Simple Wheel & Axle: VR = D/d. Differential Axle: VR = 2D/(d₁ - d₂). Screw Jack: VR = 2πL/p. Single Purchase Crab Winch: VR = (2R/d) × (T₂/T₁). Pulley System 1: VR = 2ⁿ. Pulley System 2: VR = n.',
        hinglishMasterclass: 'Bhai har machine ka apna formula yaad karo: 1. Wheel and Axle: Bada diameter / Chhota diameter (D/d). 2. Screw Jack: 2πL / p (p = pitch, L = handle length). 3. First system of pulleys: 2ⁿ (n = movable pulleys). 4. Second system: n (total pulleys). 5. Crab Winch: handle radius × teeth ratio!',
        keyTerms: [
          { term: 'Pitch of Screw (p)', symbol: 'p', unit: 'mm', description: 'Distance advanced by screw in one complete revolution.' },
          { term: 'Pinion & Spur Gear', symbol: 'T₁, T₂', unit: 'teeth', description: 'Small driver pinion (T₁) and larger driven spur wheel (T₂).' },
        ],
        formulas: [
          { name: 'Simple Wheel & Axle', math: 'V.R. = D / d', whenToUse: 'D = diameter of wheel, d = diameter of axle.' },
          { name: 'Simple Screw Jack', math: 'V.R. = (2 × π × L) / p', whenToUse: 'L = handle length, p = pitch.' },
          { name: 'Single Purchase Winch', math: 'V.R. = (2R / d) × (T₂ / T₁)', whenToUse: 'R = handle radius, d = drum diameter, T₂/T₁ = gear ratio.' },
          { name: '1st System Pulleys', math: 'V.R. = 2ⁿ', whenToUse: 'n = number of movable pulleys.' },
          { name: '2nd System Pulleys', math: 'V.R. = n', whenToUse: 'n = total number of pulleys in both blocks.' },
        ],
        workedExamples: [
          {
            title: 'Screw Jack VR',
            question: 'A simple screw jack has pitch p = 8 mm and handle length L = 400 mm. Find its Velocity Ratio.',
            given: 'p = 8 mm, L = 400 mm',
            steps: [
              'VR = (2 × π × L) / p',
              'VR = (2 × 3.1416 × 400) / 8 = 2513.27 / 8 = 314.16',
            ],
            answer: 'VR = 314.16',
          },
        ],
        commonMistakes: [
          'Confusing radius and diameter in Wheel and Axle. Both must be diameters or both radii.',
          'Using pitch in cm while handle length in mm without converting to same unit.',
        ],
        quickRevision: [
          'Simple wheel: D/d',
          'Diff wheel: 2D/(d₁ - d₂)',
          'Screw jack: 2πL/p',
          'Worm & wheel: (T·R)/(n·r)',
          '1st pulley: 2ⁿ; 2nd pulley: n; 3rd pulley: 2ⁿ - 1',
        ],
        practiceQuestions: [
          {
            id: 'u7-p2',
            title: 'Wheel and Axle Ratio',
            level: 'Easy',
            problemText: 'A wheel and axle has wheel diameter 400 mm and axle diameter 80 mm. Find VR.',
            given: ['D = 400 mm', 'd = 80 mm'],
            toFind: 'VR',
            hint: 'VR = D / d',
            finalAnswer: '5',
            solutionSteps: ['VR = 400 / 80 = 5'],
            hinglishExplanation: 'Bade diameter ko chhote diameter se divide kar do: 400/80 = 5.',
          },
        ],
        mcqs: [
          {
            id: 'u7-m2',
            question: 'In the first system of pulleys with 3 movable pulleys, the velocity ratio is:',
            options: ['3', '6', '8', '9'],
            correctIndex: 2,
            explanation: 'VR = 2ⁿ = 2³ = 8.',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'lifting_machine',
      },
    ],
  },

  // --------------------------------------------------------------------------
  // UNIT 8: GEAR AND GEAR TRAIN
  // --------------------------------------------------------------------------
  {
    id: 8,
    code: 'UNIT-08',
    title: 'Gear and Gear Train',
    shortTitle: 'Gears & Trains',
    iconName: 'Settings',
    weightage: '8-10 Marks',
    description: 'Gear drives, types, velocity ratio of simple and compound gear trains, tooth counts, speed ratios and rotation directions.',
    topics: [
      {
        id: 'u8-t1',
        title: 'Simple and Compound Gear Trains',
        subheading: 'Speed ratios, train value, idler gears and direction of rotation',
        definition: 'A gear train is a combination of two or more gears used to transmit power and motion from one shaft to another. In a simple gear train, each shaft carries only one gear. In a compound gear train, at least one shaft carries more than one gear. Velocity Ratio = Speed of Driver / Speed of Follower = Product of teeth on Followers / Product of teeth on Drivers.',
        hinglishMasterclass: 'Bhai gears me rule yaad rakho: Teeth (T) aur Speed (N) ka inverse relation hota hai (N₁/N₂ = T₂/T₁)! Bada gear hamesha dheere ghoomta hai par zyada torque deta hai. Simple train me beech wale gears (Idlers) speed ratio ko bilkul nahi badalte — wo sirf distance cover karne aur rotation ki direction ko badalne ke kaam aate hain. Compound train me ek hi shaft par 2 gears fix hote hain jo exact same speed par ghoomte hain!',
        keyTerms: [
          { term: 'Driver Gear', symbol: '1', unit: 'RPM, teeth', description: 'Gear that receives power from motor/engine.' },
          { term: 'Driven / Follower', symbol: '2, 4', unit: 'RPM, teeth', description: 'Gear that receives motion from the driver.' },
          { term: 'Idler Gear', symbol: '—', unit: '—', description: 'Intermediate gear in simple train that does not affect velocity ratio.' },
          { term: 'Train Value', symbol: 'TV', unit: '—', description: 'Reciprocal of speed ratio = N_driven / N_driver.' },
        ],
        formulas: [
          { name: 'Simple Gear Train Ratio', math: 'N₁ / N₂ = T₂ / T₁', whenToUse: 'Two gears or with intermediate idlers.' },
          { name: 'Compound Gear Train Ratio', math: 'N₁ / N_last = (T₂ × T₄ × ...) / (T₁ × T₃ × ...)', whenToUse: 'Multiple gears compounded on shared shafts.' },
          { name: 'Train Value', math: 'Train Value = 1 / Speed Ratio', whenToUse: 'Ratio of driven speed to driver speed.' },
        ],
        workedExamples: [
          {
            title: 'Simple Gear Train Speed',
            question: 'A gear A with 30 teeth drives gear B with 60 teeth. If gear A rotates at 1200 RPM, find speed of gear B.',
            given: 'T_A = 30, T_B = 60, N_A = 1200 RPM',
            steps: [
              'Formula: N_B = N_A × (T_A / T_B)',
              'Substitution: N_B = 1200 × (30 / 60)',
              'Calculation: N_B = 1200 × 0.5 = 600 RPM',
              'Direction: Opposite to gear A',
            ],
            answer: 'N_B = 600 RPM (opposite rotation)',
          },
          {
            title: 'Compound Gear Train',
            question: 'In a compound train: Driver 1 (T₁=20) drives 2 (T₂=50). Gear 3 (T₃=25) on same shaft as 2 drives 4 (T₄=75). If N₁=1500 RPM, find N₄.',
            given: 'T₁=20, T₂=50, T₃=25, T₄=75, N₁=1500 RPM',
            steps: [
              'Speed Ratio = (T₂ × T₄) / (T₁ × T₃) = (50 × 75) / (20 × 25) = 3750 / 500 = 7.5',
              'N₄ = N₁ / 7.5 = 1500 / 7.5 = 200 RPM',
            ],
            answer: 'N₄ = 200 RPM',
          },
        ],
        commonMistakes: [
          'Thinking idler gears change the speed ratio in a simple gear train (they do NOT change the ratio, only direction).',
          'Multiplying driver teeth in numerator and driven in denominator (it is driven in numerator when finding N_driver/N_driven).',
        ],
        quickRevision: [
          'Simple gear train speed ratio depends ONLY on first and last gear.',
          'External gears rotate in opposite directions.',
          'Internal gears rotate in same direction.',
          'Odd number of gears => first and last rotate in SAME direction.',
          'Even number of gears => first and last rotate in OPPOSITE directions.',
        ],
        practiceQuestions: [
          {
            id: 'u8-p1',
            title: 'Direction with 3 Gears',
            level: 'Easy',
            problemText: 'A simple gear train has 3 gears. If driver rotates clockwise, in which direction does follower rotate?',
            given: ['Total gears = 3 (odd)'],
            toFind: 'Follower rotation direction',
            hint: 'Odd number of gears retain direction.',
            finalAnswer: 'Clockwise (Same as driver)',
            solutionSteps: ['Gear 1 (CW) -> Gear 2 (CCW) -> Gear 3 (CW)'],
            hinglishExplanation: 'Pehla gear clockwise ghoomega to doosra anti-clockwise aur teesra wapas clockwise ghoomega!',
          },
        ],
        mcqs: [
          {
            id: 'u8-m1',
            question: 'The intermediate gears in a simple gear train are used to:',
            options: ['Increase speed ratio', 'Decrease speed ratio', 'Change direction of rotation or bridge distance', 'Increase torque exponentially'],
            correctIndex: 2,
            explanation: 'Idler gears do not alter the velocity ratio; they bridge distance and change direction.',
            difficulty: 'Easy',
          },
        ],
        calculatorId: 'geartrain_simple',
      },
    ],
  },
];
