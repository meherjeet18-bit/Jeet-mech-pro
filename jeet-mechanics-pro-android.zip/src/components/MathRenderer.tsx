/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Mathematical Formula & Equation Renderer
 * Renders mathematical expressions with proper square roots (√), superscripts,
 * subscripts, Greek symbols, and fractions without external CDNs (100% offline).
 * Created by Jeet
 */

import React from 'react';

interface MathRendererProps {
  formula: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  displayMode?: 'inline' | 'block';
}

/**
 * Transforms math strings to formatted elements:
 * e.g., "R = √(F₁² + F₂² + 2F₁F₂ cos θ)"
 * Handles radical overbars, subscripts, superscripts, Greek characters.
 */
export const MathRenderer: React.FC<MathRendererProps> = ({
  formula,
  className = '',
  size = 'md',
  displayMode = 'block',
}) => {
  const sizeClasses = {
    sm: 'text-sm',
    md: 'text-base font-medium',
    lg: 'text-lg font-semibold tracking-wide',
    xl: 'text-xl md:text-2xl font-bold tracking-wide',
  };

  // Convert raw math notations into clean rendered tokens
  const renderFormulaContent = (text: string) => {
    // If text contains square root "√( ... )" or "√(...)", render with custom radical styling
    const parts: React.ReactNode[] = [];
    const radicalRegex = /√\(([^)]+)\)|√([0-9a-zA-Z._+*²³-]+)/g;
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = radicalRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push(
          <span key={`text-${lastIndex}`}>
            {formatSymbols(text.substring(lastIndex, match.index))}
          </span>
        );
      }

      const radicand = match[1] || match[2];
      parts.push(
        <span key={`rad-${match.index}`} className="inline-flex items-baseline mx-0.5 whitespace-nowrap">
          <span className="text-amber-400 font-serif text-lg leading-none select-none font-bold mr-0.5">√</span>
          <span className="border-t-2 border-amber-400/90 pt-0.5 px-1 font-mono tracking-tight bg-slate-800/40 rounded-t-sm">
            {formatSymbols(radicand)}
          </span>
        </span>
      );

      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
      parts.push(
        <span key={`text-end`}>
          {formatSymbols(text.substring(lastIndex))}
        </span>
      );
    }

    return parts.length > 0 ? parts : formatSymbols(text);
  };

  const formatSymbols = (str: string) => {
    // Replace common ASCII approximations with proper engineering typography
    return str
      .replace(/\*\*/g, '^')
      .replace(/sqrt\(/gi, '√(')
      .replace(/\bF1\b/g, 'F₁')
      .replace(/\bF2\b/g, 'F₂')
      .replace(/\bF3\b/g, 'F₃')
      .replace(/\bFx\b/g, 'Fₓ')
      .replace(/\bFy\b/g, 'Fᵧ')
      .replace(/\bRA\b/g, 'R_A')
      .replace(/\bRB\b/g, 'R_B')
      .replace(/\btheta\b/gi, 'θ')
      .replace(/\balpha\b/gi, 'α')
      .replace(/\bbeta\b/gi, 'β')
      .replace(/\bgamma\b/gi, 'γ')
      .replace(/\bphi\b/gi, 'φ')
      .replace(/\bmu\b/gi, 'μ')
      .replace(/\beta\b/gi, 'η')
      .replace(/\bSigma\b/gi, 'Σ')
      .replace(/\bpi\b/gi, 'π')
      .replace(/\* /g, '× ')
      .replace(/ \*/g, ' ×');
  };

  return (
    <div
      className={`font-mono text-slate-100 ${sizeClasses[size]} ${
        displayMode === 'block' ? 'py-1' : 'inline-block'
      } ${className}`}
    >
      {renderFormulaContent(formula)}
    </div>
  );
};
