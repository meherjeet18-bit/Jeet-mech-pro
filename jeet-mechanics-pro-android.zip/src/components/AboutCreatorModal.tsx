/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — About Screen & Creator Information Modal
 * Highlights Creator Jeet, Course Code TH-7, and Android APK installation instructions.
 * Created by Jeet
 */

import React from 'react';
import { X, Smartphone, ShieldCheck, Download, Award, Code2, Cpu, CheckCircle } from 'lucide-react';

interface AboutCreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutCreatorModal: React.FC<AboutCreatorModalProps> = ({ isOpen, onClose }) => {
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl max-h-[85vh] rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-white text-base">About Jeet Mechanics Pro</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close about dialog"
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1 text-slate-300 text-xs sm:text-sm scrollbar-thin">
          {/* Creator Profile Card */}
          <div className="rounded-2xl bg-gradient-to-br from-amber-500/20 via-slate-800 to-slate-950 p-5 border border-amber-400/40 text-center space-y-2">
            <div className="inline-flex p-3 rounded-2xl bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/20 mb-1">
              <Code2 className="w-8 h-8" />
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">
              JEET MECHANICS PRO
            </h2>
            <p className="text-amber-300 font-bold text-sm tracking-widest uppercase">
              Designed & Developed by Jeet
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Built specifically for Diploma First-Year Engineering Mechanics, Course Code: <strong>TH-7 (2026–27)</strong>.
            </p>
          </div>

          {/* Core App Philosophy */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <Cpu className="w-4 h-4 text-sky-400" />
              Teacher Blackboard Solution Engine
            </h4>
            <p className="text-slate-300 leading-relaxed text-xs">
              Unlike generic calculators that spit out raw numbers, Jeet Mechanics Pro breaks down every numerical step into 13 pedagogical classroom blackboard steps:
            </p>
            <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div>1. Problem Restatement</div>
              <div>2. Given with SI Units</div>
              <div>3. To Find Unknowns</div>
              <div>4. Labeled Vector / FBD</div>
              <div>5. Mathematical Formula</div>
              <div>6. Variable Substitution</div>
              <div>7. Step 1 (Powers & Trig)</div>
              <div>8. Step 2 (Mult & Div)</div>
              <div>9. Step 3 (Add & Sub)</div>
              <div>10. Step 4 (Roots & Final)</div>
              <div>11. Final Answer with Units</div>
              <div>12. Hinglish Masterclass</div>
              <div className="col-span-2">13. Equilibrium / Bounds Verification</div>
            </div>
          </div>

          {/* Android Offline & APK Packaging Workflow */}
          <div className="rounded-xl bg-slate-950 p-4 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-amber-300 text-xs sm:text-sm flex items-center gap-2">
                <Smartphone className="w-4 h-4" />
                Android Native APK & Project Package
              </h4>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Capacitor Native Android
              </span>
            </div>

            {/* Direct Download Button */}
            <a
              href="/downloads/jeet-mechanics-pro-android.zip"
              download="jeet-mechanics-pro-android.zip"
              className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs sm:text-sm shadow-lg hover:from-amber-300 hover:to-amber-400 transition cursor-pointer text-center no-underline"
            >
              <Download className="w-4 h-4" />
              <span>Download Android Project ZIP (jeet-mechanics-pro-android.zip)</span>
            </a>

            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <CheckCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Option 1: Open in Android Studio (Zero Setup)</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  1. Download and extract <code>jeet-mechanics-pro-android.zip</code>.<br />
                  2. Open <strong>Android Studio</strong> and select the <code>android/</code> folder.<br />
                  3. Click <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.<br />
                  4. The installable <strong>app-debug.apk</strong> is generated immediately in <code>android/app/build/outputs/apk/debug/</code>.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <CheckCircle className="w-3.5 h-3.5 text-sky-400" />
                  <span>Option 2: Automatic Free GitHub Actions APK Builder</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  This project includes <code>.github/workflows/build-apk.yml</code>. Simply push this project to a GitHub repository, and GitHub's cloud runners will automatically compile and provide the downloadable <strong>app-debug.apk</strong> under the GitHub Actions Artifacts tab!
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Option 3: Direct Android PWA Install (On-Device)</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Open this application in Chrome or Brave on your Android phone, then tap <strong>"Install App"</strong> in the top header. It installs directly onto your phone home screen as a standalone offline Android app.
                </p>
              </div>
            </div>
          </div>

          {/* Verification & Compliance */}
          <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-950/20 p-3 rounded-xl border border-emerald-900/30">
            <ShieldCheck className="w-5 h-5 shrink-0" />
            <span>Package Identity: com.jeet.mechanicspro | Course Code: TH-7 | 100% Offline</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Jeet Mechanics Pro v1.0.0</span>
          <span>© 2026–27 Jeet</span>
        </div>
      </div>
    </div>
  );
};
