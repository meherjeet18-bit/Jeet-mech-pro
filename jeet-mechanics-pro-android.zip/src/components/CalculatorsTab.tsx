/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Dedicated Engineering Calculators Tab
 * Covers all eight units with blackboard step-by-step solutions.
 * Created by Jeet
 */

import React, { useState, useEffect } from 'react';
import {
  solveParallelogramLaw,
  solveResolutionOfForce,
  solveMomentOfForce,
  solveCouple,
  solveLamisTheorem,
  solveSimplySupportedBeam,
  solveHorizontalFriction,
  solveInclinedPlaneFriction,
  solveTSectionCentroid,
  solveRectangleMOI,
  solveLiftingMachine,
  solveGearTrain,
  BlackboardSolution,
} from '../utils/mechanicsEngine';
import { BlackboardSolutionView } from './BlackboardSolutionView';
import { 
  Calculator, 
  RotateCcw, 
  Sparkles, 
  History, 
  BookMarked,
  ArrowRight,
  Flame
} from 'lucide-react';

interface CalculatorsTabProps {
  initialCalculatorId?: string;
  onSaveToHistory?: (solution: BlackboardSolution) => void;
  onBookmark?: (solution: BlackboardSolution) => void;
  bookmarkedIds?: string[];
}

export const CalculatorsTab: React.FC<CalculatorsTabProps> = ({
  initialCalculatorId = 'parallelogram_law',
  onSaveToHistory,
  onBookmark,
  bookmarkedIds = [],
}) => {
  const [selectedCalc, setSelectedCalc] = useState<string>(initialCalculatorId);
  const [currentSolution, setCurrentSolution] = useState<BlackboardSolution | null>(null);

  // Sync if initialCalculatorId changes from parent
  useEffect(() => {
    if (initialCalculatorId) {
      setSelectedCalc(initialCalculatorId);
    }
  }, [initialCalculatorId]);

  // Form states for Unit 2: Parallelogram Law (defaults to mandatory test case)
  const [f1, setF1] = useState<number>(6);
  const [f2, setF2] = useState<number>(8);
  const [theta, setTheta] = useState<number>(90);

  // Form states for Unit 2: Resolution
  const [resF, setResF] = useState<number>(100);
  const [resTheta, setResTheta] = useState<number>(30);

  // Form states for Unit 2: Moment & Couple
  const [momentF, setMomentF] = useState<number>(50);
  const [momentDist, setMomentDist] = useState<number>(2);
  const [momentAngle, setMomentAngle] = useState<number>(90);
  const [coupleF, setCoupleF] = useState<number>(20);
  const [coupleArm, setCoupleArm] = useState<number>(0.4);

  // Form states for Unit 3: Lami's Theorem
  const [lamiF1, setLamiF1] = useState<number>(100);
  const [lamiAlpha, setLamiAlpha] = useState<number>(120);
  const [lamiBeta, setLamiBeta] = useState<number>(120);

  // Form states for Unit 3: Beam Reactions
  const [beamSpan, setBeamSpan] = useState<number>(6);
  const [pointLoad, setPointLoad] = useState<number>(1200);
  const [pointDistA, setPointDistA] = useState<number>(2);
  const [udlIntensity, setUdlIntensity] = useState<number>(0);

  // Form states for Unit 4: Horizontal Friction
  const [horizWeight, setHorizWeight] = useState<number>(200);
  const [horizMu, setHorizMu] = useState<number>(0.25);
  const [horizPullAngle, setHorizPullAngle] = useState<number>(0);

  // Form states for Unit 4: Inclined Plane Friction
  const [incWeight, setIncWeight] = useState<number>(100);
  const [incMu, setIncMu] = useState<number>(0.3);
  const [incAlpha, setIncAlpha] = useState<number>(30);
  const [incDirection, setIncDirection] = useState<'up' | 'down'>('up');

  // Form states for Unit 5: T-Section Centroid
  const [tFlangeW, setTFlangeW] = useState<number>(100);
  const [tFlangeT, setTFlangeT] = useState<number>(20);
  const [tWebW, setTWebW] = useState<number>(20);
  const [tWebH, setTWebH] = useState<number>(80);

  // Form states for Unit 6: Moment of Inertia of Rectangle
  const [moiB, setMoiB] = useState<number>(30);
  const [moiD, setMoiD] = useState<number>(60);

  // Form states for Unit 7: Lifting Machines
  const [machType, setMachType] = useState<'wheel_axle' | 'screw_jack' | 'pulley_1' | 'pulley_2' | 'crab_winch'>('wheel_axle');
  const [machLoad, setMachLoad] = useState<number>(1000);
  const [machEffort, setMachEffort] = useState<number>(250);
  const [wheelD, setWheelD] = useState<number>(400);
  const [axleD, setAxleD] = useState<number>(80);
  const [screwL, setScrewL] = useState<number>(400);
  const [screwP, setScrewP] = useState<number>(8);
  const [pulleyN, setPulleyN] = useState<number>(3);

  // Form states for Unit 8: Gear Train
  const [gearType, setGearType] = useState<'simple' | 'compound'>('simple');
  const [gearSpeedN1, setGearSpeedN1] = useState<number>(1200);
  const [gearT1, setGearT1] = useState<number>(20);
  const [gearT2, setGearT2] = useState<number>(60);
  const [gearT3, setGearT3] = useState<number>(25);
  const [gearT4, setGearT4] = useState<number>(75);

  // Auto-run initial calculation on selection change
  useEffect(() => {
    executeCurrentCalculation();
  }, [selectedCalc]);

  const executeCurrentCalculation = () => {
    let sol: BlackboardSolution | null = null;

    switch (selectedCalc) {
      case 'parallelogram_law':
        sol = solveParallelogramLaw(Number(f1) || 0, Number(f2) || 0, Number(theta) || 0);
        break;
      case 'force_resolution':
        sol = solveResolutionOfForce(Number(resF) || 0, Number(resTheta) || 0);
        break;
      case 'moment_of_force':
        sol = solveMomentOfForce(Number(momentF) || 0, Number(momentDist) || 0, Number(momentAngle) || 90);
        break;
      case 'couple_moment':
        sol = solveCouple(Number(coupleF) || 0, Number(coupleArm) || 0);
        break;
      case 'lamis_theorem':
        sol = solveLamisTheorem(Number(lamiF1) || 0, Number(lamiAlpha) || 0, Number(lamiBeta) || 0);
        break;
      case 'beam_reactions':
        sol = solveSimplySupportedBeam(
          Number(beamSpan) || 1,
          Number(pointLoad) || 0,
          Number(pointDistA) || 0,
          Number(udlIntensity) || 0
        );
        break;
      case 'horizontal_friction':
        sol = solveHorizontalFriction(Number(horizWeight) || 0, Number(horizMu) || 0, Number(horizPullAngle) || 0);
        break;
      case 'inclined_friction':
        sol = solveInclinedPlaneFriction(Number(incWeight) || 0, Number(incMu) || 0, Number(incAlpha) || 0, incDirection);
        break;
      case 'centroid_t_section':
        sol = solveTSectionCentroid(Number(tFlangeW) || 1, Number(tFlangeT) || 1, Number(tWebW) || 1, Number(tWebH) || 1);
        break;
      case 'moi_rectangle':
        sol = solveRectangleMOI(Number(moiB) || 1, Number(moiD) || 1);
        break;
      case 'lifting_machine':
        const params: Record<string, number> = {};
        if (machType === 'wheel_axle') {
          params.D = wheelD;
          params.d = axleD;
        } else if (machType === 'screw_jack') {
          params.L = screwL;
          params.p = screwP;
        } else if (machType === 'pulley_1' || machType === 'pulley_2') {
          params.n = pulleyN;
        } else if (machType === 'crab_winch') {
          params.R = 300;
          params.d = 100;
          params.T1 = 20;
          params.T2 = 100;
        }
        sol = solveLiftingMachine(machType, Number(machLoad) || 1, Number(machEffort) || 1, params);
        break;
      case 'geartrain_simple':
        sol = solveGearTrain(gearType, Number(gearSpeedN1) || 1, Number(gearT1) || 1, Number(gearT2) || 1, {
          teethT3: Number(gearT3) || 1,
          teethT4: Number(gearT4) || 1,
        });
        break;
      default:
        sol = solveParallelogramLaw(f1, f2, theta);
        break;
    }

    if (sol) {
      setCurrentSolution(sol);
      if (onSaveToHistory) {
        onSaveToHistory(sol);
      }
    }
  };

  const loadMandatoryTestCase = () => {
    setSelectedCalc('parallelogram_law');
    setF1(6);
    setF2(8);
    setTheta(90);
    const sol = solveParallelogramLaw(6, 8, 90);
    setCurrentSolution(sol);
    if (onSaveToHistory) onSaveToHistory(sol);
  };

  const calculatorList = [
    { id: 'parallelogram_law', unit: 'Unit 2', name: 'Parallelogram Law (Resultant)', badge: 'Mandatory Test' },
    { id: 'force_resolution', unit: 'Unit 2', name: 'Resolution of Forces (Fₓ, Fᵧ)', badge: null },
    { id: 'moment_of_force', unit: 'Unit 2', name: 'Moment of Force & Varignon', badge: null },
    { id: 'couple_moment', unit: 'Unit 2', name: 'Couple & Torque', badge: null },
    { id: 'lamis_theorem', unit: 'Unit 3', name: "Lami's Theorem (3 Forces)", badge: 'High Yield' },
    { id: 'beam_reactions', unit: 'Unit 3', name: 'Beam Support Reactions', badge: 'High Yield' },
    { id: 'horizontal_friction', unit: 'Unit 4', name: 'Horizontal Friction (Impending)', badge: null },
    { id: 'inclined_friction', unit: 'Unit 4', name: 'Inclined Plane Friction', badge: null },
    { id: 'centroid_t_section', unit: 'Unit 5', name: 'Centroid of T-Section', badge: 'Tabular' },
    { id: 'moi_rectangle', unit: 'Unit 6', name: 'Moment of Inertia (Rectangle)', badge: null },
    { id: 'lifting_machine', unit: 'Unit 7', name: 'Simple Lifting Machines', badge: 'MA & VR' },
    { id: 'geartrain_simple', unit: 'Unit 8', name: 'Gear Train Velocity Ratio', badge: null },
  ];

  return (
    <div className="space-y-6">
      {/* Header and Quick Mandatory Test Numerical Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-amber-500/20 via-sky-500/10 to-slate-900 p-4 sm:p-5 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 font-bold text-xs">TH-7</span>
            <h2 className="text-lg sm:text-xl font-bold text-white">Engineering Mechanics Solvers</h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Teacher step-by-step blackboard explanation for every calculation in Diploma Course TH-7.
          </p>
        </div>

        <button
          onClick={loadMandatoryTestCase}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs sm:text-sm shadow-md hover:from-amber-400 hover:to-amber-500 transition cursor-pointer"
        >
          <Flame className="w-4 h-4 fill-slate-950" />
          <span>Load Mandatory Test Numerical (F₁=6N, F₂=8N, θ=90°)</span>
        </button>
      </div>

      {/* Calculator Selector Pills (Categorized by Unit) */}
      <div className="overflow-x-auto pb-2 scrollbar-thin">
        <div className="flex gap-2 min-w-max">
          {calculatorList.map((c) => {
            const isActive = selectedCalc === c.id;
            return (
              <button
                key={c.id}
                onClick={() => setSelectedCalc(c.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 font-bold shadow-lg shadow-amber-400/20'
                    : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                <span className={`text-[10px] px-1.5 py-0.5 rounded ${isActive ? 'bg-slate-900 text-amber-300' : 'bg-slate-900 text-slate-400'}`}>
                  {c.unit}
                </span>
                <span>{c.name}</span>
                {c.badge && (
                  <span className={`text-[9px] px-1.5 py-0.2 rounded font-semibold ${isActive ? 'bg-amber-600 text-white' : 'bg-amber-400/20 text-amber-300'}`}>
                    {c.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Input Parameter Form Card */}
      <div className="rounded-2xl bg-slate-800/70 p-4 sm:p-6 border border-slate-700/60 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-700/60 mb-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-amber-400" />
            <h3 className="font-semibold text-slate-100 text-base">
              {calculatorList.find((c) => c.id === selectedCalc)?.name || 'Calculator Parameters'}
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">100% Offline Engine</span>
        </div>

        {/* Dynamic Input Fields depending on active solver */}
        {selectedCalc === 'parallelogram_law' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">First Force F₁ (N)</label>
              <input
                type="number"
                value={f1}
                onChange={(e) => setF1(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
                placeholder="e.g. 6"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Default test: 6 N</span>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Second Force F₂ (N)</label>
              <input
                type="number"
                value={f2}
                onChange={(e) => setF2(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
                placeholder="e.g. 8"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Default test: 8 N</span>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Included Angle θ (°)</label>
              <input
                type="number"
                value={theta}
                onChange={(e) => setTheta(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
                placeholder="e.g. 90"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Default test: 90°</span>
            </div>
          </div>
        )}

        {selectedCalc === 'force_resolution' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Force Magnitude F (N)</label>
              <input
                type="number"
                value={resF}
                onChange={(e) => setResF(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Angle with Horizontal θ (°)</label>
              <input
                type="number"
                value={resTheta}
                onChange={(e) => setResTheta(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'moment_of_force' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Force F (N)</label>
              <input
                type="number"
                value={momentF}
                onChange={(e) => setMomentF(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Lever Arm Distance d (m)</label>
              <input
                type="number"
                value={momentDist}
                onChange={(e) => setMomentDist(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Angle with Arm θ (°)</label>
              <input
                type="number"
                value={momentAngle}
                onChange={(e) => setMomentAngle(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'couple_moment' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Force of Couple F (N)</label>
              <input
                type="number"
                value={coupleF}
                onChange={(e) => setCoupleF(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Arm Distance a (m)</label>
              <input
                type="number"
                value={coupleArm}
                onChange={(e) => setCoupleArm(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'lamis_theorem' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Known Force F₁ (N)</label>
              <input
                type="number"
                value={lamiF1}
                onChange={(e) => setLamiF1(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Angle Opp. to F₁ (α°)</label>
              <input
                type="number"
                value={lamiAlpha}
                onChange={(e) => setLamiAlpha(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Angle Opp. to F₂ (β°)</label>
              <input
                type="number"
                value={lamiBeta}
                onChange={(e) => setLamiBeta(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'beam_reactions' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Beam Span L (m)</label>
              <input
                type="number"
                value={beamSpan}
                onChange={(e) => setBeamSpan(parseFloat(e.target.value) || 1)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Point Load W (N)</label>
              <input
                type="number"
                value={pointLoad}
                onChange={(e) => setPointLoad(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Dist from A (m)</label>
              <input
                type="number"
                value={pointDistA}
                onChange={(e) => setPointDistA(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">UDL Intensity w (N/m)</label>
              <input
                type="number"
                value={udlIntensity}
                onChange={(e) => setUdlIntensity(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'horizontal_friction' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Body Weight W (N)</label>
              <input
                type="number"
                value={horizWeight}
                onChange={(e) => setHorizWeight(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Coefficient of Friction μ</label>
              <input
                type="number"
                step="0.01"
                value={horizMu}
                onChange={(e) => setHorizMu(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Angle of Pull θ (°)</label>
              <input
                type="number"
                value={horizPullAngle}
                onChange={(e) => setHorizPullAngle(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'inclined_friction' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Body Weight W (N)</label>
              <input
                type="number"
                value={incWeight}
                onChange={(e) => setIncWeight(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Coefficient μ</label>
              <input
                type="number"
                step="0.01"
                value={incMu}
                onChange={(e) => setIncMu(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Incline Angle α (°)</label>
              <input
                type="number"
                value={incAlpha}
                onChange={(e) => setIncAlpha(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Impending Motion</label>
              <select
                value={incDirection}
                onChange={(e) => setIncDirection(e.target.value as 'up' | 'down')}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              >
                <option value="up">Motion UP the plane</option>
                <option value="down">Prevent sliding DOWN</option>
              </select>
            </div>
          </div>
        )}

        {selectedCalc === 'centroid_t_section' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Flange Width (mm)</label>
              <input
                type="number"
                value={tFlangeW}
                onChange={(e) => setTFlangeW(parseFloat(e.target.value) || 1)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Flange Thickness (mm)</label>
              <input
                type="number"
                value={tFlangeT}
                onChange={(e) => setTFlangeT(parseFloat(e.target.value) || 1)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Web Width/Thick (mm)</label>
              <input
                type="number"
                value={tWebW}
                onChange={(e) => setTWebW(parseFloat(e.target.value) || 1)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Web Height (mm)</label>
              <input
                type="number"
                value={tWebH}
                onChange={(e) => setTWebH(parseFloat(e.target.value) || 1)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'moi_rectangle' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Breadth b (mm)</label>
              <input
                type="number"
                value={moiB}
                onChange={(e) => setMoiB(parseFloat(e.target.value) || 1)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Depth d (mm)</label>
              <input
                type="number"
                value={moiD}
                onChange={(e) => setMoiD(parseFloat(e.target.value) || 1)}
                className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        )}

        {selectedCalc === 'lifting_machine' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Machine Type</label>
                <select
                  value={machType}
                  onChange={(e) => setMachType(e.target.value as any)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
                >
                  <option value="wheel_axle">Simple Wheel & Axle</option>
                  <option value="screw_jack">Simple Screw Jack</option>
                  <option value="pulley_1">1st System Pulleys (VR = 2ⁿ)</option>
                  <option value="pulley_2">2nd System Pulleys (VR = n)</option>
                  <option value="crab_winch">Single Purchase Crab Winch</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Load Lifted W (N)</label>
                <input
                  type="number"
                  value={machLoad}
                  onChange={(e) => setMachLoad(parseFloat(e.target.value) || 1)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Effort Applied P (N)</label>
                <input
                  type="number"
                  value={machEffort}
                  onChange={(e) => setMachEffort(parseFloat(e.target.value) || 1)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            {machType === 'wheel_axle' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Wheel Diameter D (mm)</label>
                  <input
                    type="number"
                    value={wheelD}
                    onChange={(e) => setWheelD(parseFloat(e.target.value) || 1)}
                    className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Axle Diameter d (mm)</label>
                  <input
                    type="number"
                    value={axleD}
                    onChange={(e) => setAxleD(parseFloat(e.target.value) || 1)}
                    className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {machType === 'screw_jack' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Handle Length L (mm)</label>
                  <input
                    type="number"
                    value={screwL}
                    onChange={(e) => setScrewL(parseFloat(e.target.value) || 1)}
                    className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Pitch of Thread p (mm)</label>
                  <input
                    type="number"
                    value={screwP}
                    onChange={(e) => setScrewP(parseFloat(e.target.value) || 1)}
                    className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {(machType === 'pulley_1' || machType === 'pulley_2') && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Number of Pulleys (n)</label>
                <input
                  type="number"
                  value={pulleyN}
                  onChange={(e) => setPulleyN(parseInt(e.target.value) || 1)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                />
              </div>
            )}
          </div>
        )}

        {selectedCalc === 'geartrain_simple' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Train Type</label>
                <select
                  value={gearType}
                  onChange={(e) => setGearType(e.target.value as any)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono focus:border-amber-400 focus:outline-none"
                >
                  <option value="simple">Simple Gear Train</option>
                  <option value="compound">Compound Gear Train</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Driver Speed N₁ (RPM)</label>
                <input
                  type="number"
                  value={gearSpeedN1}
                  onChange={(e) => setGearSpeedN1(parseFloat(e.target.value) || 1)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Driver Teeth T₁</label>
                <input
                  type="number"
                  value={gearT1}
                  onChange={(e) => setGearT1(parseInt(e.target.value) || 1)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Driven Gear 2 Teeth T₂</label>
                <input
                  type="number"
                  value={gearT2}
                  onChange={(e) => setGearT2(parseInt(e.target.value) || 1)}
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                />
              </div>
              {gearType === 'compound' && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Compound Gear 3 Teeth T₃</label>
                    <input
                      type="number"
                      value={gearT3}
                      onChange={(e) => setGearT3(parseInt(e.target.value) || 1)}
                      className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Follower Gear 4 Teeth T₄</label>
                    <input
                      type="number"
                      value={gearT4}
                      onChange={(e) => setGearT4(parseInt(e.target.value) || 1)}
                      className="w-full rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2.5 text-white font-mono"
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {/* Calculate Action Button */}
        <div className="mt-5 flex items-center justify-end">
          <button
            onClick={executeCurrentCalculation}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-sm shadow-lg hover:from-amber-300 hover:to-amber-400 transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4 fill-slate-950" />
            <span>Generate Blackboard Teacher Solution</span>
          </button>
        </div>
      </div>

      {/* Render Current Solution View */}
      {currentSolution && (
        <BlackboardSolutionView
          solution={currentSolution}
          onBookmark={onBookmark}
          isBookmarked={bookmarkedIds.includes(currentSolution.solverId)}
        />
      )}
    </div>
  );
};
