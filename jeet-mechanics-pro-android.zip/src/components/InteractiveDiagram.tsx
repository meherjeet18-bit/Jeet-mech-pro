/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Interactive Engineering Vector & Free-Body Diagram Renderer
 * Provides high-contrast, labeled, vector diagrams with force arrows, components, and angles.
 * Created by Jeet
 */

import React from 'react';

interface InteractiveDiagramProps {
  data?: Record<string, any>;
  className?: string;
  theme?: 'chalkboard' | 'blueprint' | 'light';
}

export const InteractiveDiagram: React.FC<InteractiveDiagramProps> = ({
  data,
  className = '',
  theme = 'chalkboard',
}) => {
  if (!data || !data.type) return null;

  const type = data.type;

  // Background and line styling depending on theme
  const colors = {
    chalkboard: {
      bg: '#14202C',
      grid: '#1E2F40',
      axis: '#475569',
      f1: '#38BDF8', // cyan chalk
      f2: '#34D399', // emerald chalk
      resultant: '#FBBF24', // golden chalk
      component: '#94A3B8',
      text: '#F8FAFC',
      dim: '#CBD5E1',
      beam: '#64748B',
    },
    blueprint: {
      bg: '#0F2744',
      grid: '#19395F',
      axis: '#38BDF8',
      f1: '#7DD3FC',
      f2: '#A7F3D0',
      resultant: '#FDE047',
      component: '#93C5FD',
      text: '#FFFFFF',
      dim: '#BAE6FD',
      beam: '#38BDF8',
    },
    light: {
      bg: '#F8FAFC',
      grid: '#E2E8F0',
      axis: '#94A3B8',
      f1: '#0284C7',
      f2: '#059669',
      resultant: '#D97706',
      component: '#64748B',
      text: '#0F172A',
      dim: '#334155',
      beam: '#475569',
    },
  }[theme];

  return (
    <div className={`w-full overflow-hidden rounded-xl border border-slate-700/60 shadow-inner ${className}`} style={{ backgroundColor: colors.bg }}>
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900/60 border-b border-slate-800 text-xs font-mono text-slate-400">
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
          <span>Vector Free-Body Diagram (FBD)</span>
        </span>
        <span className="text-[10px] text-amber-300 font-semibold uppercase tracking-wider">
          {type.replace('_', ' ')}
        </span>
      </div>

      <div className="p-2 flex justify-center items-center">
        {type === 'parallelogram' && (
          <svg viewBox="0 0 400 240" className="w-full max-w-md h-52">
            <defs>
              <marker id="arrowGold" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill={colors.resultant} />
              </marker>
              <marker id="arrowCyan" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill={colors.f1} />
              </marker>
              <marker id="arrowGreen" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill={colors.f2} />
              </marker>
            </defs>

            {/* Grid background */}
            <line x1="40" y1="200" x2="360" y2="200" stroke={colors.axis} strokeWidth="1" strokeDasharray="3,3" />
            <line x1="80" y1="40" x2="80" y2="220" stroke={colors.axis} strokeWidth="1" strokeDasharray="3,3" />

            {/* Origin O */}
            <circle cx="80" cy="200" r="4" fill={colors.resultant} />
            <text x="65" y="215" fill={colors.dim} fontSize="12" fontFamily="monospace">O</text>

            {/* F1 Vector along horizontal: (80,200) to (240,200) */}
            <line x1="80" y1="200" x2="230" y2="200" stroke={colors.f1} strokeWidth="3" markerEnd="url(#arrowCyan)" />
            <text x="150" y="218" fill={colors.f1} fontSize="13" fontWeight="bold" fontFamily="monospace">
              F₁ = {data.f1} N
            </text>

            {/* F2 Vector at thetaDeg: for theta=90, (80,200) to (80, 80) */}
            {data.thetaDeg === 90 ? (
              <>
                <line x1="80" y1="200" x2="80" y2="90" stroke={colors.f2} strokeWidth="3" markerEnd="url(#arrowGreen)" />
                <text x="15" y="140" fill={colors.f2} fontSize="13" fontWeight="bold" fontFamily="monospace">
                  F₂ = {data.f2} N
                </text>

                {/* Parallelogram dashed lines */}
                <line x1="80" y1="80" x2="240" y2="80" stroke={colors.component} strokeWidth="1.5" strokeDasharray="4,4" />
                <line x1="240" y1="200" x2="240" y2="80" stroke={colors.component} strokeWidth="1.5" strokeDasharray="4,4" />

                {/* Diagonal Resultant R */}
                <line x1="80" y1="200" x2="232" y2="85" stroke={colors.resultant} strokeWidth="3.5" markerEnd="url(#arrowGold)" />
                <text x="170" y="130" fill={colors.resultant} fontSize="14" fontWeight="bold" fontFamily="monospace">
                  R = {Math.round(data.r * 100) / 100} N
                </text>

                {/* Angle arc 90 deg square symbol */}
                <path d="M 80,180 L 100,180 L 100,200" fill="none" stroke={colors.dim} strokeWidth="1.5" />
                <text x="105" y="195" fill={colors.dim} fontSize="11" fontFamily="monospace">θ = 90°</text>
              </>
            ) : (
              <>
                {/* General angle */}
                <line x1="80" y1="200" x2="180" y2="100" stroke={colors.f2} strokeWidth="3" markerEnd="url(#arrowGreen)" />
                <text x="100" y="95" fill={colors.f2} fontSize="13" fontWeight="bold" fontFamily="monospace">
                  F₂ = {data.f2} N
                </text>
                <line x1="180" y1="100" x2="340" y2="100" stroke={colors.component} strokeWidth="1.5" strokeDasharray="4,4" />
                <line x1="240" y1="200" x2="340" y2="100" stroke={colors.component} strokeWidth="1.5" strokeDasharray="4,4" />
                <line x1="80" y1="200" x2="330" y2="105" stroke={colors.resultant} strokeWidth="3.5" markerEnd="url(#arrowGold)" />
                <text x="220" y="140" fill={colors.resultant} fontSize="14" fontWeight="bold" fontFamily="monospace">
                  R = {Math.round(data.r * 100) / 100} N
                </text>
              </>
            )}
          </svg>
        )}

        {type === 'resolution' && (
          <svg viewBox="0 0 360 220" className="w-full max-w-sm h-48">
            <defs>
              <marker id="resGold" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill={colors.resultant} />
              </marker>
              <marker id="resCyan" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill={colors.f1} />
              </marker>
            </defs>
            {/* Origin & Axes */}
            <line x1="40" y1="180" x2="320" y2="180" stroke={colors.axis} strokeWidth="1.5" />
            <line x1="60" y1="30" x2="60" y2="200" stroke={colors.axis} strokeWidth="1.5" />

            {/* Resolved components Fx and Fy */}
            <line x1="60" y1="180" x2="220" y2="180" stroke={colors.f1} strokeWidth="3" markerEnd="url(#resCyan)" />
            <text x="120" y="200" fill={colors.f1} fontSize="12" fontWeight="bold" fontFamily="monospace">
              Fₓ = {Math.round(data.fx * 10) / 10} N
            </text>

            <line x1="230" y1="180" x2="230" y2="70" stroke={colors.f2} strokeWidth="2.5" strokeDasharray="3,3" />
            <text x="240" y="130" fill={colors.f2} fontSize="12" fontWeight="bold" fontFamily="monospace">
              Fᵧ = {Math.round(data.fy * 10) / 10} N
            </text>

            {/* Main Force Vector */}
            <line x1="60" y1="180" x2="225" y2="75" stroke={colors.resultant} strokeWidth="3.5" markerEnd="url(#resGold)" />
            <text x="130" y="105" fill={colors.resultant} fontSize="13" fontWeight="bold" fontFamily="monospace">
              F = {data.f} N
            </text>

            {/* Angle arc */}
            <path d="M 110,180 A 50 50 0 0 0 100,155" fill="none" stroke={colors.dim} strokeWidth="1.5" />
            <text x="115" y="165" fill={colors.dim} fontSize="11" fontFamily="monospace">θ = {data.thetaDeg}°</text>
          </svg>
        )}

        {type === 'beam' && (
          <svg viewBox="0 0 380 180" className="w-full max-w-md h-44">
            <defs>
              <marker id="beamDown" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
                <path d="M0,0 L0,7 L7,3.5 z" fill="#EF4444" />
              </marker>
              <marker id="beamUpA" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
                <path d="M0,0 L0,7 L7,3.5 z" fill={colors.f1} />
              </marker>
              <marker id="beamUpB" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
                <path d="M0,0 L0,7 L7,3.5 z" fill={colors.f2} />
              </marker>
            </defs>

            {/* Beam Horizontal Member */}
            <rect x="50" y="90" width="280" height="12" rx="2" fill={colors.beam} stroke={colors.text} strokeWidth="1" />

            {/* Support A (Hinged Triangle) */}
            <polygon points="50,102 40,122 60,122" fill="none" stroke={colors.f1} strokeWidth="2" />
            <line x1="35" y1="122" x2="65" y2="122" stroke={colors.dim} strokeWidth="2" />
            <text x="35" y="140" fill={colors.f1} fontSize="11" fontWeight="bold" fontFamily="monospace">
              R_A = {Math.round(data.ra)} N
            </text>
            <line x1="50" y1="150" x2="50" y2="108" stroke={colors.f1} strokeWidth="2.5" markerEnd="url(#beamUpA)" />

            {/* Support B (Roller) */}
            <circle cx="330" cy="110" r="7" fill="none" stroke={colors.f2} strokeWidth="2" />
            <line x1="315" y1="120" x2="345" y2="120" stroke={colors.dim} strokeWidth="2" />
            <text x="295" y="140" fill={colors.f2} fontSize="11" fontWeight="bold" fontFamily="monospace">
              R_B = {Math.round(data.rb)} N
            </text>
            <line x1="330" y1="150" x2="330" y2="118" stroke={colors.f2} strokeWidth="2.5" markerEnd="url(#beamUpB)" />

            {/* Point Load W */}
            {/* Position proportional to pointLoadDistA / spanL */}
            {(() => {
              const xPos = 50 + (280 * (data.pointLoadDistA / (data.spanL || 6)));
              return (
                <g>
                  <line x1={xPos} y1="35" x2={xPos} y2="84" stroke="#EF4444" strokeWidth="3" markerEnd="url(#beamDown)" />
                  <text x={xPos - 25} y="30" fill="#EF4444" fontSize="12" fontWeight="bold" fontFamily="monospace">
                    W = {data.pointLoadW} N
                  </text>
                </g>
              );
            })()}

            {/* Span indicator */}
            <line x1="50" y1="165" x2="330" y2="165" stroke={colors.dim} strokeWidth="1" strokeDasharray="2,2" />
            <text x="170" y="175" fill={colors.dim} fontSize="11" textAnchor="middle" fontFamily="monospace">
              Span L = {data.spanL} m
            </text>
          </svg>
        )}

        {type === 'horizontal_friction' && (
          <svg viewBox="0 0 340 180" className="w-full max-w-sm h-40">
            <defs>
              <marker id="fricArr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
                <path d="M0,0 L0,6 L6,3 z" fill="#FBBF24" />
              </marker>
              <marker id="normArr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
                <path d="M0,0 L0,6 L6,3 z" fill="#38BDF8" />
              </marker>
              <marker id="pullArr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
                <path d="M0,0 L0,6 L6,3 z" fill="#34D399" />
              </marker>
            </defs>
            {/* Ground surface */}
            <line x1="20" y1="130" x2="320" y2="130" stroke={colors.axis} strokeWidth="2" />
            {/* Ground hatching */}
            <line x1="30" y1="130" x2="20" y2="140" stroke={colors.axis} strokeWidth="1" />
            <line x1="70" y1="130" x2="60" y2="140" stroke={colors.axis} strokeWidth="1" />
            <line x1="110" y1="130" x2="100" y2="140" stroke={colors.axis} strokeWidth="1" />
            <line x1="150" y1="130" x2="140" y2="140" stroke={colors.axis} strokeWidth="1" />
            <line x1="190" y1="130" x2="180" y2="140" stroke={colors.axis} strokeWidth="1" />
            <line x1="230" y1="130" x2="220" y2="140" stroke={colors.axis} strokeWidth="1" />
            <line x1="270" y1="130" x2="260" y2="140" stroke={colors.axis} strokeWidth="1" />

            {/* Block */}
            <rect x="120" y="80" width="80" height="50" rx="3" fill="#1E293B" stroke={colors.resultant} strokeWidth="2" />
            <text x="145" y="110" fill={colors.text} fontSize="12" fontWeight="bold">W</text>

            {/* Weight W downward */}
            <line x1="160" y1="105" x2="160" y2="165" stroke="#EF4444" strokeWidth="2" markerEnd="url(#fricArr)" />
            <text x="168" y="165" fill="#EF4444" fontSize="11" fontFamily="monospace">W = {data.weightW} N</text>

            {/* Normal Reaction N upward */}
            <line x1="160" y1="80" x2="160" y2="25" stroke="#38BDF8" strokeWidth="2" markerEnd="url(#normArr)" />
            <text x="168" y="35" fill="#38BDF8" fontSize="11" fontFamily="monospace">N = {Math.round(data.normalReaction)} N</text>

            {/* Pull P forward */}
            <line x1="200" y1="105" x2="280" y2="105" stroke="#34D399" strokeWidth="2.5" markerEnd="url(#pullArr)" />
            <text x="235" y="95" fill="#34D399" fontSize="11" fontWeight="bold" fontFamily="monospace">P = {Math.round(data.pRequired)} N</text>

            {/* Limiting Friction backward */}
            <line x1="120" y1="128" x2="45" y2="128" stroke="#FBBF24" strokeWidth="2.5" markerEnd="url(#fricArr)" />
            <text x="40" y="120" fill="#FBBF24" fontSize="11" fontWeight="bold" fontFamily="monospace">F_lim = {Math.round(data.limitingFriction)} N</text>
          </svg>
        )}

        {type === 't_section' && (
          <svg viewBox="0 0 320 200" className="w-full max-w-xs h-48">
            {/* Flange */}
            <rect x="90" y="30" width="140" height="25" fill="#1E3E62" stroke="#38BDF8" strokeWidth="2" />
            {/* Web */}
            <rect x="145" y="55" width="30" height="110" fill="#0B192C" stroke="#38BDF8" strokeWidth="2" />

            {/* Centroid Point G */}
            <circle cx="160" cy="100" r="5" fill="#FBBF24" stroke="#FFFFFF" strokeWidth="1.5" />
            <text x="175" y="105" fill="#FBBF24" fontSize="12" fontWeight="bold" fontFamily="monospace">
              G (Ȳ = {Math.round(data.yBar * 10) / 10} mm)
            </text>

            {/* Centroidal Axes */}
            <line x1="60" y1="100" x2="260" y2="100" stroke="#FBBF24" strokeWidth="1.5" strokeDasharray="3,3" />
            <line x1="160" y1="15" x2="160" y2="185" stroke="#FBBF24" strokeWidth="1.5" strokeDasharray="3,3" />

            <text x="265" y="104" fill="#FBBF24" fontSize="11">X</text>
            <text x="156" y="15" fill="#FBBF24" fontSize="11">Y</text>

            {/* Base line */}
            <line x1="120" y1="165" x2="200" y2="165" stroke="#94A3B8" strokeWidth="2" />
            <text x="160" y="180" fill="#94A3B8" fontSize="10" textAnchor="middle">Reference Base (y=0)</text>
          </svg>
        )}

        {type === 'geartrain' && (
          <svg viewBox="0 0 340 180" className="w-full max-w-sm h-40">
            {/* Driver Gear 1 */}
            <circle cx="110" cy="90" r="45" fill="none" stroke="#38BDF8" strokeWidth="2.5" />
            <circle cx="110" cy="90" r="8" fill="#38BDF8" />
            <text x="110" y="94" fill="#FFFFFF" fontSize="10" textAnchor="middle">Driver</text>
            <text x="110" y="150" fill="#38BDF8" fontSize="11" textAnchor="middle" fontFamily="monospace">
              T₁ = {data.teethT1} ({data.speedDriverN1} RPM ↷)
            </text>

            {/* Driven Gear 2 */}
            <circle cx="215" cy="90" r="60" fill="none" stroke="#FBBF24" strokeWidth="2.5" />
            <circle cx="215" cy="90" r="8" fill="#FBBF24" />
            <text x="215" y="94" fill="#0F172A" fontSize="10" textAnchor="middle" fontWeight="bold">Driven</text>
            <text x="215" y="165" fill="#FBBF24" fontSize="11" textAnchor="middle" fontFamily="monospace">
              T₂ = {data.teethT2} ({Math.round(data.speedLast)} RPM ↶)
            </text>

            {/* Mesh Point */}
            <circle cx="155" cy="90" r="3" fill="#EF4444" />
            <text x="155" y="80" fill="#EF4444" fontSize="9" textAnchor="middle">Mesh</text>
          </svg>
        )}

        {/* Fallback for general types */}
        {!['parallelogram', 'resolution', 'beam', 'horizontal_friction', 't_section', 'geartrain'].includes(type) && (
          <div className="py-4 text-center font-mono text-xs text-slate-400">
            [Engineering Schematic: {type.replace('_', ' ').toUpperCase()}]
          </div>
        )}
      </div>
    </div>
  );
};
