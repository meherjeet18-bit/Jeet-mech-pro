/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Mandatory 13-Step Blackboard Teacher Solution View
 * Renders complete solutions with classroom blackboard styling.
 * Created by Jeet
 */

import React, { useState } from 'react';
import { BlackboardSolution } from '../utils/mechanicsEngine';
import { MathRenderer } from './MathRenderer';
import { InteractiveDiagram } from './InteractiveDiagram';
import { 
  CheckCircle2, 
  HelpCircle, 
  Copy, 
  Check, 
  Bookmark, 
  BookmarkCheck, 
  Sparkles,
  BookOpen,
  Eye,
  Maximize2
} from 'lucide-react';

interface BlackboardSolutionViewProps {
  solution: BlackboardSolution;
  onBookmark?: (solution: BlackboardSolution) => void;
  isBookmarked?: boolean;
}

export const BlackboardSolutionView: React.FC<BlackboardSolutionViewProps> = ({
  solution,
  onBookmark,
  isBookmarked = false,
}) => {
  const [boardStyle, setBoardStyle] = useState<'slate' | 'blackboard' | 'blueprint'>('blackboard');
  const [copied, setCopied] = useState(false);
  const [showVerification, setShowVerification] = useState(true);

  const copySolutionText = () => {
    const text = `
JEET MECHANICS PRO - ${solution.title}
Problem: ${solution.question}

GIVEN:
${solution.given.map((g) => `• ${g.symbol} (${g.label}) = ${g.value} ${g.unit}`).join('\n')}

TO FIND: ${solution.toFind}

FORMULA: ${solution.formula}
SUBSTITUTION: ${solution.substitution}

STEP 1: ${solution.step1}
STEP 2: ${solution.step2}
STEP 3: ${solution.step3}
STEP 4: ${solution.step4}

FINAL ANSWER: ${solution.finalAnswer.fullText}

HINGLISH EXPLANATION:
${solution.conceptExplanation}

VERIFICATION:
${solution.verification}
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const boardThemeClasses = {
    blackboard: 'bg-[#101b22] border-slate-700/80 shadow-2xl text-slate-100',
    slate: 'bg-slate-900 border-slate-800 text-slate-100',
    blueprint: 'bg-[#0B1E36] border-sky-800 text-sky-50',
  }[boardStyle];

  return (
    <div className={`mt-4 rounded-2xl border ${boardThemeClasses} overflow-hidden transition-all duration-300 font-sans`}>
      {/* Blackboard Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-black/40 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="flex h-3 w-3 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
          </span>
          <span className="font-mono text-xs font-semibold tracking-wider text-amber-300 uppercase">
            Blackboard Teacher Solution
          </span>
          <span className="hidden sm:inline-block text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
            Full 13 Steps
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Theme Switcher */}
          <div className="flex items-center rounded-lg bg-slate-800/80 p-0.5 text-xs">
            <button
              onClick={() => setBoardStyle('blackboard')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition ${
                boardStyle === 'blackboard' ? 'bg-emerald-800 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Chalkboard
            </button>
            <button
              onClick={() => setBoardStyle('blueprint')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition ${
                boardStyle === 'blueprint' ? 'bg-sky-700 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Blueprint
            </button>
          </div>

          {/* Copy Button */}
          <button
            onClick={copySolutionText}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white text-xs font-medium transition"
            title="Copy Full Solution"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy'}</span>
          </button>

          {/* Bookmark Button */}
          {onBookmark && (
            <button
              onClick={() => onBookmark(solution)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-amber-400 hover:bg-slate-700 text-xs font-medium transition"
              title="Save to bookmarks"
            >
              {isBookmarked ? (
                <BookmarkCheck className="w-3.5 h-3.5 text-amber-400" />
              ) : (
                <Bookmark className="w-3.5 h-3.5" />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Chalkboard Body */}
      <div className="p-4 sm:p-6 space-y-6">
        {/* 1. Question */}
        <div className="rounded-xl bg-black/25 p-3.5 border-l-4 border-amber-400">
          <div className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider mb-1 flex items-center gap-1.5">
            <span className="bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">1</span>
            QUESTION
          </div>
          <p className="text-slate-200 text-sm leading-relaxed font-sans">{solution.question}</p>
        </div>

        {/* 2 & 3: Given & To Find */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Given */}
          <div className="rounded-xl bg-slate-900/60 p-3.5 border border-slate-800">
            <div className="text-xs font-mono font-bold uppercase text-sky-400 tracking-wider mb-2 flex items-center gap-1.5">
              <span className="bg-sky-400 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">2</span>
              GIVEN DATA
            </div>
            <ul className="space-y-1.5 text-sm font-mono">
              {solution.given.map((item, idx) => (
                <li key={idx} className="flex items-center justify-between text-slate-300 border-b border-slate-800/40 pb-1">
                  <span className="text-sky-300 font-semibold">{item.symbol} ({item.label}):</span>
                  <span className="bg-slate-800/80 px-2 py-0.5 rounded text-amber-300 font-bold">
                    {item.value} {item.unit}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* To Find */}
          <div className="rounded-xl bg-slate-900/60 p-3.5 border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono font-bold uppercase text-emerald-400 tracking-wider mb-2 flex items-center gap-1.5">
                <span className="bg-emerald-400 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">3</span>
                TO FIND
              </div>
              <p className="text-slate-200 text-sm font-medium leading-relaxed">{solution.toFind}</p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] text-slate-400 font-mono">
              Units: Standard SI Units applied
            </div>
          </div>
        </div>

        {/* 4. Diagram */}
        {solution.diagramData && (
          <div>
            <div className="text-xs font-mono font-bold uppercase text-amber-300 tracking-wider mb-2 flex items-center gap-1.5">
              <span className="bg-amber-300 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">4</span>
              LABELLED ENGINEERING / FREE-BODY DIAGRAM
            </div>
            <InteractiveDiagram 
              data={solution.diagramData} 
              theme={boardStyle === 'blueprint' ? 'blueprint' : 'chalkboard'} 
            />
          </div>
        )}

        {/* 5. Formula */}
        <div className="rounded-xl bg-slate-950/50 p-4 border border-amber-500/30">
          <div className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider mb-1.5 flex items-center gap-1.5">
            <span className="bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">5</span>
            APPLICABLE FORMULA
          </div>
          <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
            <MathRenderer formula={solution.formula} size="lg" className="text-amber-300" />
          </div>
        </div>

        {/* 6. Substitution */}
        <div className="rounded-xl bg-slate-950/50 p-4 border border-sky-500/30">
          <div className="text-xs font-mono font-bold uppercase text-sky-400 tracking-wider mb-1.5 flex items-center gap-1.5">
            <span className="bg-sky-400 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">6</span>
            SUBSTITUTION OF VALUES
          </div>
          <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
            <MathRenderer formula={solution.substitution} size="md" className="text-sky-200" />
          </div>
        </div>

        {/* 7, 8, 9, 10: Step-by-Step Intermediate Calculations */}
        <div className="space-y-3">
          <div className="text-xs font-mono font-bold uppercase text-slate-300 tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            CLASSROOM BLACKBOARD CALCULATIONS (INTERMEDIATE STEPS)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Step 1 */}
            <div className="rounded-xl bg-slate-900/70 p-3.5 border border-slate-800">
              <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-amber-300">
                Step 1: Powers & Trigonometric Terms
              </span>
              <div className="mt-2 text-slate-200">
                <MathRenderer formula={solution.step1} size="sm" />
              </div>
            </div>

            {/* Step 2 */}
            <div className="rounded-xl bg-slate-900/70 p-3.5 border border-slate-800">
              <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-sky-300">
                Step 2: Multiplication & Division
              </span>
              <div className="mt-2 text-slate-200">
                <MathRenderer formula={solution.step2} size="sm" />
              </div>
            </div>

            {/* Step 3 */}
            <div className="rounded-xl bg-slate-900/70 p-3.5 border border-slate-800">
              <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-emerald-300">
                Step 3: Additions & Subtractions
              </span>
              <div className="mt-2 text-slate-200">
                <MathRenderer formula={solution.step3} size="sm" />
              </div>
            </div>

            {/* Step 4 */}
            <div className="rounded-xl bg-slate-900/70 p-3.5 border border-slate-800">
              <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-indigo-300">
                Step 4: Roots & Final Operations
              </span>
              <div className="mt-2 text-slate-200">
                <MathRenderer formula={solution.step4} size="sm" />
              </div>
            </div>
          </div>
        </div>

        {/* 11. Final Answer */}
        <div className="rounded-xl bg-gradient-to-r from-amber-500/20 via-amber-400/10 to-transparent p-4 border-2 border-amber-400 shadow-lg">
          <div className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider mb-1 flex items-center gap-1.5">
            <span className="bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">11</span>
            FINAL ANSWER WITH SI UNIT
          </div>
          <div className="text-xl sm:text-2xl font-mono font-bold text-amber-300 tracking-wide mt-1">
            {solution.finalAnswer.fullText}
          </div>
        </div>

        {/* 12. Concept Explanation (Hinglish) */}
        <div className="rounded-xl bg-slate-900/80 p-4 border border-purple-800/40">
          <div className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider mb-2 flex items-center gap-1.5">
            <span className="bg-purple-500 text-white px-1.5 py-0.2 rounded text-[10px]">12</span>
            TEACHER’S HINGLISH MASTERCLASS (KYUN AUR KAISE?)
          </div>
          <p className="text-slate-300 text-sm leading-relaxed font-sans italic bg-purple-950/30 p-3 rounded-lg border border-purple-900/30">
            "{solution.conceptExplanation}"
          </p>
        </div>

        {/* 13. Verification */}
        <div className="rounded-xl bg-slate-900/60 p-4 border border-emerald-800/40">
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs font-mono font-bold uppercase text-emerald-400 tracking-wider flex items-center gap-1.5">
              <span className="bg-emerald-500 text-slate-950 px-1.5 py-0.2 rounded text-[10px]">13</span>
              SOLUTION VERIFICATION & SANITY CHECK
            </div>
            <button
              onClick={() => setShowVerification(!showVerification)}
              className="text-xs text-slate-400 hover:text-emerald-300 font-mono"
            >
              {showVerification ? 'Hide' : 'Show'}
            </button>
          </div>
          {showVerification && (
            <p className="text-slate-300 text-xs sm:text-sm font-mono bg-emerald-950/20 p-2.5 rounded border border-emerald-900/30">
              {solution.verification}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
