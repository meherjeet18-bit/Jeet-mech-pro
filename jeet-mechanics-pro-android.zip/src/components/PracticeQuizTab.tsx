/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Practice & MCQ Quiz Mode Tab
 * Interactive student practice with "Try First" mode and instant feedback.
 * Created by Jeet
 */

import React, { useState } from 'react';
import { SYLLABUS_UNITS, MCQQuestion, PracticeProblem } from '../data/syllabusData';
import { 
  CheckCircle, 
  XCircle, 
  Award, 
  RotateCcw, 
  HelpCircle, 
  Eye, 
  EyeOff, 
  Sparkles,
  Flame,
  ArrowRight,
  Filter
} from 'lucide-react';

interface PracticeQuizTabProps {
  onOpenCalculator: (calcId: string) => void;
}

export const PracticeQuizTab: React.FC<PracticeQuizTabProps> = ({ onOpenCalculator }) => {
  const [activeSubTab, setActiveSubTab] = useState<'mcq' | 'try_first'>('mcq');
  const [selectedUnitFilter, setSelectedUnitFilter] = useState<number>(0); // 0 = all
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');

  // MCQ state
  const [currentMCQIndex, setCurrentMCQIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [answeredCount, setAnsweredCount] = useState<number>(0);

  // Try First numerical practice state
  const [selectedPracticeUnitId, setSelectedPracticeUnitId] = useState<number>(2);
  const [userNumericalAnswer, setUserNumericalAnswer] = useState<string>('');
  const [revealedSolutionId, setRevealedSolutionId] = useState<string | null>(null);
  const [checkFeedback, setCheckFeedback] = useState<string | null>(null);

  // Collect all MCQs from all units
  const allMCQs: (MCQQuestion & { unitName: string; unitCode: string })[] = [];
  SYLLABUS_UNITS.forEach((unit) => {
    unit.topics.forEach((topic) => {
      topic.mcqs.forEach((mcq) => {
        allMCQs.push({
          ...mcq,
          unitName: unit.shortTitle,
          unitCode: unit.code,
        });
      });
    });
  });

  const filteredMCQs = allMCQs.filter((m) => {
    if (selectedUnitFilter !== 0) {
      const matchUnit = SYLLABUS_UNITS.find((u) => u.id === selectedUnitFilter);
      if (matchUnit && m.unitCode !== matchUnit.code) return false;
    }
    if (selectedDifficulty !== 'All' && m.difficulty !== selectedDifficulty) {
      return false;
    }
    return true;
  });

  const currentMCQ = filteredMCQs[currentMCQIndex] || filteredMCQs[0];

  const handleSelectOption = (index: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOption(index);
    setIsAnswerSubmitted(true);
    setAnsweredCount((prev) => prev + 1);
    if (index === currentMCQ.correctIndex) {
      setScore((prev) => prev + 1);
    }
  };

  const nextMCQ = () => {
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    if (currentMCQIndex < filteredMCQs.length - 1) {
      setCurrentMCQIndex((prev) => prev + 1);
    } else {
      setCurrentMCQIndex(0);
    }
  };

  const resetQuiz = () => {
    setCurrentMCQIndex(0);
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setScore(0);
    setAnsweredCount(0);
  };

  // Collect practice problems
  const practiceProblems: (PracticeProblem & { unitName: string })[] = [];
  SYLLABUS_UNITS.forEach((unit) => {
    if (selectedPracticeUnitId === 0 || unit.id === selectedPracticeUnitId) {
      unit.topics.forEach((topic) => {
        topic.practiceQuestions.forEach((prob) => {
          practiceProblems.push({
            ...prob,
            unitName: unit.shortTitle,
          });
        });
      });
    }
  });

  const handleCheckTryFirst = (prob: PracticeProblem) => {
    if (!userNumericalAnswer.trim()) {
      setCheckFeedback('Please type your numerical answer first!');
      return;
    }

    const cleanInput = userNumericalAnswer.replace(/[^0-9.]/g, '');
    const cleanAnswer = prob.finalAnswer.replace(/[^0-9.]/g, '');

    const userVal = parseFloat(cleanInput);
    const ansVal = parseFloat(cleanAnswer);

    if (!isNaN(userVal) && !isNaN(ansVal) && Math.abs(userVal - ansVal) <= 0.5) {
      setCheckFeedback('🎉 Shabash! Exact/close match! Well done!');
    } else {
      setCheckFeedback(`Almost! Let's check the blackboard teacher steps below to see the derivation.`);
    }
    setRevealedSolutionId(prob.id);
  };

  return (
    <div className="space-y-6">
      {/* Subtab Toggle */}
      <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('mcq')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeSubTab === 'mcq'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            MCQ Exam Drill
          </button>
          <button
            onClick={() => setActiveSubTab('try_first')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeSubTab === 'try_first'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            "Try First" Numerical Practice
          </button>
        </div>

        {activeSubTab === 'mcq' && (
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-slate-400">Score:</span>
            <span className="text-amber-400 font-bold px-2 py-0.5 rounded bg-slate-800">
              {score} / {answeredCount}
            </span>
          </div>
        )}
      </div>

      {/* MCQ EXAM DRILL VIEW */}
      {activeSubTab === 'mcq' && currentMCQ && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
            <span className="text-slate-400">Filter Unit:</span>
            <select
              value={selectedUnitFilter}
              onChange={(e) => {
                setSelectedUnitFilter(parseInt(e.target.value));
                setCurrentMCQIndex(0);
                setIsAnswerSubmitted(false);
                setSelectedOption(null);
              }}
              className="rounded-lg bg-slate-800 border border-slate-700 px-2.5 py-1 text-slate-200"
            >
              <option value={0}>All 8 Units</option>
              {SYLLABUS_UNITS.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.code}: {u.shortTitle}
                </option>
              ))}
            </select>

            <span className="text-slate-400 ml-2">Level:</span>
            <select
              value={selectedDifficulty}
              onChange={(e) => {
                setSelectedDifficulty(e.target.value);
                setCurrentMCQIndex(0);
                setIsAnswerSubmitted(false);
                setSelectedOption(null);
              }}
              className="rounded-lg bg-slate-800 border border-slate-700 px-2.5 py-1 text-slate-200"
            >
              <option value="All">All Levels</option>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Challenging">Challenging</option>
            </select>

            <button
              onClick={resetQuiz}
              className="ml-auto flex items-center gap-1 text-slate-400 hover:text-white transition"
              title="Reset Quiz"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>

          {/* Question Card */}
          <div className="rounded-2xl bg-slate-800/80 border border-slate-700/80 p-5 sm:p-6 shadow-xl space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono text-xs border border-sky-500/30">
                  {currentMCQ.unitCode}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  Question {currentMCQIndex + 1} of {filteredMCQs.length}
                </span>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                currentMCQ.difficulty === 'Easy' ? 'bg-emerald-500/20 text-emerald-300' :
                currentMCQ.difficulty === 'Medium' ? 'bg-amber-500/20 text-amber-300' :
                'bg-rose-500/20 text-rose-300'
              }`}>
                {currentMCQ.difficulty}
              </span>
            </div>

            <div className="text-base sm:text-lg font-semibold text-slate-100 leading-relaxed">
              {currentMCQ.question}
            </div>

            {/* Options */}
            <div className="space-y-3">
              {currentMCQ.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = idx === currentMCQ.correctIndex;

                let btnStyle = 'bg-slate-900/60 border-slate-700/60 text-slate-300 hover:bg-slate-800 hover:border-slate-600';
                if (isAnswerSubmitted) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-bold';
                  } else if (isSelected && !isCorrect) {
                    btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswerSubmitted}
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full p-4 rounded-xl border text-left text-sm transition flex items-center justify-between cursor-pointer ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="h-6 w-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-mono text-xs font-bold text-slate-300">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{opt}</span>
                    </div>

                    {isAnswerSubmitted && isCorrect && (
                      <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                    )}
                    {isAnswerSubmitted && isSelected && !isCorrect && (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Answer Explanation & Next Button */}
            {isAnswerSubmitted && (
              <div className="rounded-xl bg-purple-950/30 p-4 border border-purple-500/30 space-y-3 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span className="text-xs font-mono font-bold uppercase text-purple-300">
                    Teacher Explanation & Concept
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans">
                  {currentMCQ.explanation}
                </p>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={nextMCQ}
                    className="flex items-center gap-2 px-5 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm hover:bg-amber-300 transition cursor-pointer"
                  >
                    <span>Next Question</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TRY FIRST NUMERICAL PRACTICE VIEW */}
      {activeSubTab === 'try_first' && (
        <div className="space-y-6">
          <div className="rounded-xl bg-slate-800/60 p-4 border border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-white text-sm">Self-Practice Mode</h3>
              <p className="text-xs text-slate-400">
                Attempt the question on paper first, type your answer, and verify with the classroom blackboard steps!
              </p>
            </div>
            <select
              value={selectedPracticeUnitId}
              onChange={(e) => setSelectedPracticeUnitId(parseInt(e.target.value))}
              className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-1.5 text-xs text-slate-200"
            >
              {SYLLABUS_UNITS.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.code}: {u.shortTitle}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-4">
            {practiceProblems.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-sm">
                No practice problems found for this unit.
              </div>
            ) : (
              practiceProblems.map((prob) => {
                const isRevealed = revealedSolutionId === prob.id;

                return (
                  <div
                    key={prob.id}
                    className="rounded-2xl bg-slate-800/80 border border-slate-700/70 p-5 shadow-lg space-y-4"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-slate-700">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                          {prob.title}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">({prob.unitName})</span>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-700 text-slate-300">
                        {prob.level}
                      </span>
                    </div>

                    <p className="text-sm font-semibold text-slate-100">{prob.problemText}</p>

                    <div className="text-xs font-mono text-sky-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                      Given: {prob.given.join(', ')} | To Find: {prob.toFind}
                    </div>

                    <div className="text-xs text-amber-300/80 italic font-mono">
                      💡 Hint: {prob.hint}
                    </div>

                    {/* Student input field */}
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-2">
                      <input
                        type="text"
                        value={userNumericalAnswer}
                        onChange={(e) => setUserNumericalAnswer(e.target.value)}
                        placeholder="Type your calculated answer (e.g. 10 or 10 N)..."
                        className="flex-1 rounded-xl bg-slate-900 border border-slate-700 px-3.5 py-2 text-sm text-white font-mono focus:border-amber-400 focus:outline-none"
                      />
                      <button
                        onClick={() => handleCheckTryFirst(prob)}
                        className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm hover:bg-amber-300 transition cursor-pointer"
                      >
                        Check & Reveal Steps
                      </button>
                    </div>

                    {checkFeedback && revealedSolutionId === prob.id && (
                      <div className="text-xs font-medium text-amber-300 bg-amber-950/30 p-2 rounded border border-amber-900/40">
                        {checkFeedback}
                      </div>
                    )}

                    {/* Revealed step-by-step blackboard solution */}
                    {isRevealed && (
                      <div className="rounded-xl bg-slate-900 p-4 border border-emerald-500/30 space-y-3 animate-in fade-in">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-mono font-bold uppercase text-emerald-400">
                            Teacher Blackboard Solution Steps
                          </span>
                          <span className="text-xs font-mono font-bold text-amber-300 bg-slate-800 px-2 py-0.5 rounded">
                            Final: {prob.finalAnswer}
                          </span>
                        </div>

                        <div className="space-y-1 font-mono text-xs text-slate-300">
                          {prob.solutionSteps.map((step, sidx) => (
                            <div key={sidx} className="flex items-start gap-2">
                              <span className="text-emerald-400 select-none">›</span>
                              <span>{step}</span>
                            </div>
                          ))}
                        </div>

                        <div className="pt-2 border-t border-slate-800 text-xs italic text-slate-400">
                          "{prob.hinglishExplanation}"
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
