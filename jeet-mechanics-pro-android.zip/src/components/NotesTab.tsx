/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Comprehensive Notes & Syllabus Dashboard Tab
 * All 8 Units with Hinglish Masterclass, Worked Examples, and Exam Alerts.
 * Created by Jeet
 */

import React, { useState } from 'react';
import { SYLLABUS_UNITS, SyllabusUnit, TopicNote } from '../data/syllabusData';
import { MathRenderer } from './MathRenderer';
import { 
  BookOpen, 
  CheckCircle, 
  AlertTriangle, 
  Calculator, 
  ChevronRight, 
  Sparkles,
  HelpCircle,
  FileText,
  Search,
  CheckCircle2,
  Circle
} from 'lucide-react';

interface NotesTabProps {
  onOpenCalculator: (calcId: string) => void;
  completedTopicIds: string[];
  onToggleTopicCompleted: (topicId: string) => void;
}

export const NotesTab: React.FC<NotesTabProps> = ({
  onOpenCalculator,
  completedTopicIds,
  onToggleTopicCompleted,
}) => {
  const [selectedUnitId, setSelectedUnitId] = useState<number>(1);
  const [selectedTopicId, setSelectedTopicId] = useState<string>('u1-t1');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const activeUnit = SYLLABUS_UNITS.find((u) => u.id === selectedUnitId) || SYLLABUS_UNITS[0];
  const activeTopic = activeUnit.topics.find((t) => t.id === selectedTopicId) || activeUnit.topics[0];

  // Filter topics across all units if search query is active
  const filteredUnits = searchQuery.trim()
    ? SYLLABUS_UNITS.map((unit) => ({
        ...unit,
        topics: unit.topics.filter(
          (t) =>
            t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            t.hinglishMasterclass.toLowerCase().includes(searchQuery.toLowerCase()) ||
            t.definition.toLowerCase().includes(searchQuery.toLowerCase())
        ),
      })).filter((u) => u.topics.length > 0)
    : SYLLABUS_UNITS;

  return (
    <div className="space-y-6">
      {/* Search & Unit selector bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search syllabus topics, definitions, Hinglish notes..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Total Progress Badge */}
        <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800/90 border border-slate-700/60 text-xs font-mono">
          <span className="text-slate-400">Progress:</span>
          <span className="text-amber-400 font-bold">
            {completedTopicIds.length} / {SYLLABUS_UNITS.reduce((acc, u) => acc + u.topics.length, 0)} Topics
          </span>
        </div>
      </div>

      {/* 8 Units Horizontal Scroller */}
      <div className="overflow-x-auto pb-1 scrollbar-thin">
        <div className="flex gap-2 min-w-max">
          {SYLLABUS_UNITS.map((u) => {
            const isSelected = selectedUnitId === u.id;
            const completedCountInUnit = u.topics.filter((t) => completedTopicIds.includes(t.id)).length;
            const isAllCompleted = completedCountInUnit === u.topics.length;

            return (
              <button
                key={u.id}
                onClick={() => {
                  setSelectedUnitId(u.id);
                  setSelectedTopicId(u.topics[0]?.id || '');
                }}
                className={`flex flex-col items-start p-3 rounded-xl border text-left transition min-w-[150px] cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-b from-slate-800 to-slate-900 border-amber-400 shadow-md shadow-amber-400/10'
                    : 'bg-slate-800/50 border-slate-700/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${isSelected ? 'bg-amber-400 text-slate-950' : 'bg-slate-700 text-slate-300'}`}>
                    {u.code}
                  </span>
                  {isAllCompleted ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <span className="text-[10px] text-slate-400 font-mono">
                      {completedCountInUnit}/{u.topics.length}
                    </span>
                  )}
                </div>
                <div className={`text-xs font-bold truncate w-full ${isSelected ? 'text-amber-300' : 'text-slate-200'}`}>
                  {u.shortTitle}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {u.weightage}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Layout: Topic List on Left (or Top) and Active Topic Content on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Topic Selector List */}
        <div className="lg:col-span-4 space-y-2">
          <div className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider px-1">
            Unit Topics ({activeUnit.topics.length})
          </div>
          {activeUnit.topics.map((t) => {
            const isTopicSelected = selectedTopicId === t.id;
            const isCompleted = completedTopicIds.includes(t.id);

            return (
              <div
                key={t.id}
                onClick={() => setSelectedTopicId(t.id)}
                className={`p-3.5 rounded-xl border transition cursor-pointer flex items-start justify-between gap-2 ${
                  isTopicSelected
                    ? 'bg-slate-800 border-amber-400/80 shadow-md text-white'
                    : 'bg-slate-800/40 border-slate-700/50 hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <div className="space-y-1 pr-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleTopicCompleted(t.id);
                      }}
                      className="text-slate-400 hover:text-emerald-400 transition"
                      title={isCompleted ? 'Mark as Incomplete' : 'Mark as Completed'}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-500" />
                      )}
                    </button>
                    <span className="font-semibold text-xs sm:text-sm">{t.title}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-1">{t.subheading}</p>
                </div>
                <ChevronRight className={`w-4 h-4 shrink-0 transition ${isTopicSelected ? 'text-amber-400 translate-x-0.5' : 'text-slate-600'}`} />
              </div>
            );
          })}
        </div>

        {/* Detailed Topic Note Card */}
        <div className="lg:col-span-8 space-y-6">
          <div className="rounded-2xl bg-slate-800/80 border border-slate-700/70 p-5 sm:p-6 shadow-xl space-y-6">
            {/* Topic Header & Actions */}
            <div className="flex flex-wrap items-start justify-between gap-3 pb-4 border-b border-slate-700/70">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                    {activeUnit.code}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">Diploma Course TH-7</span>
                </div>
                <h2 className="text-lg sm:text-2xl font-bold text-white mt-1.5">{activeTopic.title}</h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-0.5">{activeTopic.subheading}</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onToggleTopicCompleted(activeTopic.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition cursor-pointer ${
                    completedTopicIds.includes(activeTopic.id)
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{completedTopicIds.includes(activeTopic.id) ? 'Completed' : 'Mark Done'}</span>
                </button>

                {activeTopic.calculatorId && (
                  <button
                    onClick={() => onOpenCalculator(activeTopic.calculatorId!)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300 transition cursor-pointer"
                  >
                    <Calculator className="w-3.5 h-3.5" />
                    <span>Open Solver</span>
                  </button>
                )}
              </div>
            </div>

            {/* Standard English Definition */}
            <div className="rounded-xl bg-slate-900/70 p-4 border-l-4 border-sky-400">
              <span className="text-xs font-mono font-bold uppercase text-sky-400 tracking-wider block mb-1">
                Standard Engineering Definition
              </span>
              <p className="text-slate-200 text-sm leading-relaxed">{activeTopic.definition}</p>
            </div>

            {/* Teacher's Hinglish Masterclass */}
            <div className="rounded-xl bg-gradient-to-br from-purple-950/40 to-slate-900 p-4 border border-purple-500/30">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-mono font-bold uppercase text-purple-300 tracking-wider">
                  Teacher's Hinglish Masterclass (Samjho Asaan Bhasha Me)
                </span>
              </div>
              <p className="text-slate-200 text-sm leading-relaxed italic bg-black/20 p-3 rounded-lg border border-purple-900/30">
                "{activeTopic.hinglishMasterclass}"
              </p>
            </div>

            {/* Key Terms, Symbols and SI Units Table */}
            {activeTopic.keyTerms && activeTopic.keyTerms.length > 0 && (
              <div>
                <span className="text-xs font-mono font-bold uppercase text-slate-400 tracking-wider block mb-2">
                  Key Terms, Symbols & Units
                </span>
                <div className="overflow-x-auto rounded-xl border border-slate-700/60">
                  <table className="w-full text-left text-xs sm:text-sm">
                    <thead className="bg-slate-900/90 text-slate-300 font-mono text-[11px] uppercase border-b border-slate-700/60">
                      <tr>
                        <th className="p-2.5">Term</th>
                        <th className="p-2.5">Symbol</th>
                        <th className="p-2.5">SI Unit</th>
                        <th className="p-2.5">Concept Meaning</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {activeTopic.keyTerms.map((term, i) => (
                        <tr key={i} className="hover:bg-slate-800/40">
                          <td className="p-2.5 font-semibold text-slate-200">{term.term}</td>
                          <td className="p-2.5 font-mono text-amber-300 font-bold">{term.symbol}</td>
                          <td className="p-2.5 font-mono text-sky-300">{term.unit}</td>
                          <td className="p-2.5 text-slate-300 text-xs">{term.description}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Essential Formulas & When to Use */}
            {activeTopic.formulas && activeTopic.formulas.length > 0 && (
              <div>
                <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider block mb-2">
                  Essential Mathematical Formulas
                </span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {activeTopic.formulas.map((f, i) => (
                    <div key={i} className="rounded-xl bg-slate-900/80 p-3.5 border border-amber-500/20">
                      <div className="text-xs font-semibold text-amber-300 mb-1">{f.name}</div>
                      <div className="bg-black/30 p-2 rounded border border-slate-800 my-1.5">
                        <MathRenderer formula={f.math} size="sm" className="text-slate-100" />
                      </div>
                      <div className="text-[11px] text-slate-400 italic">
                        <span className="font-semibold text-slate-300">When to use: </span>
                        {f.whenToUse}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Worked Numerical Examples */}
            {activeTopic.workedExamples && activeTopic.workedExamples.length > 0 && (
              <div>
                <span className="text-xs font-mono font-bold uppercase text-emerald-400 tracking-wider block mb-2">
                  Worked Numerical Examples (Step-by-Step)
                </span>
                <div className="space-y-4">
                  {activeTopic.workedExamples.map((ex, i) => (
                    <div key={i} className="rounded-xl bg-slate-900/70 p-4 border border-emerald-800/30 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-300 uppercase tracking-wide">
                          Example {i + 1}: {ex.title}
                        </span>
                        <span className="text-xs font-mono text-amber-400 font-bold">{ex.answer}</span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-200 font-medium">{ex.question}</p>
                      <div className="text-xs font-mono text-sky-300 bg-black/20 px-2.5 py-1 rounded">
                        Given: {ex.given}
                      </div>
                      <div className="space-y-1 pt-1 border-t border-slate-800 text-xs font-mono text-slate-300">
                        {ex.steps.map((st, sidx) => (
                          <div key={sidx} className="flex items-start gap-2">
                            <span className="text-emerald-400 select-none">›</span>
                            <span>{st}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Common Mistakes & Exam Alert */}
            {activeTopic.commonMistakes && activeTopic.commonMistakes.length > 0 && (
              <div className="rounded-xl bg-rose-950/20 p-4 border border-rose-500/30">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold uppercase text-rose-400 tracking-wider mb-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  <span>Exam Alert & Common Mistakes to Avoid (Savdhaan!)</span>
                </div>
                <ul className="space-y-1.5 text-xs sm:text-sm text-slate-200">
                  {activeTopic.commonMistakes.map((cm, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-rose-400 font-bold select-none">✕</span>
                      <span>{cm}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Quick Revision Notes */}
            {activeTopic.quickRevision && (
              <div className="rounded-xl bg-slate-900/80 p-4 border border-slate-700/60">
                <span className="text-xs font-mono font-bold uppercase text-slate-400 tracking-wider block mb-2">
                  Quick Revision Bullet Points
                </span>
                <ul className="space-y-1 text-xs text-slate-300 font-mono">
                  {activeTopic.quickRevision.map((qr, qidx) => (
                    <li key={qidx} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                      <span>{qr}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
