/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Searchable Formula Bank Modal
 * Quick-access cheat sheet with all 8 units' formulas.
 * Created by Jeet
 */

import React, { useState } from 'react';
import { SYLLABUS_UNITS } from '../data/syllabusData';
import { MathRenderer } from './MathRenderer';
import { Search, X, Calculator, Bookmark, Check, Copy } from 'lucide-react';

interface FormulaBankModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenCalculator: (calcId: string) => void;
}

export const FormulaBankModal: React.FC<FormulaBankModalProps> = ({
  isOpen,
  onClose,
  onOpenCalculator,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedFormula, setCopiedFormula] = useState<string | null>(null);

  // Handle Escape key
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Flatten all formulas with unit info
  const allFormulas: {
    unitCode: string;
    unitTitle: string;
    name: string;
    math: string;
    whenToUse: string;
    calcId?: string;
  }[] = [];

  SYLLABUS_UNITS.forEach((unit) => {
    unit.topics.forEach((topic) => {
      topic.formulas.forEach((f) => {
        allFormulas.push({
          unitCode: unit.code,
          unitTitle: unit.shortTitle,
          name: f.name,
          math: f.math,
          whenToUse: f.whenToUse,
          calcId: topic.calculatorId,
        });
      });
    });
  });

  const filtered = allFormulas.filter(
    (f) =>
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.math.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.whenToUse.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.unitTitle.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const copyFormula = (math: string) => {
    navigator.clipboard.writeText(math);
    setCopiedFormula(math);
    setTimeout(() => setCopiedFormula(null), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl max-h-[85vh] rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 font-bold text-xs">
              TH-7
            </span>
            <h3 className="font-bold text-white text-base">Formula Cheat Sheet & Bank</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close formula bank"
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-3 border-b border-slate-800 bg-slate-900">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by formula name, symbol (R, Fx, MA, VR, Ixx)..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Formulas list */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1 scrollbar-thin">
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              No formulas match "{searchQuery}"
            </div>
          ) : (
            filtered.map((item, idx) => (
              <div
                key={idx}
                className="rounded-xl bg-slate-800/80 p-3.5 border border-slate-700/60 hover:border-amber-500/40 transition space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300">
                      {item.unitCode}
                    </span>
                    <span className="text-xs font-semibold text-slate-200">{item.name}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => copyFormula(item.math)}
                      className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white text-xs transition"
                      title="Copy Formula"
                    >
                      {copiedFormula === item.math ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    {item.calcId && (
                      <button
                        onClick={() => {
                          onOpenCalculator(item.calcId!);
                          onClose();
                        }}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-bold text-[11px] hover:bg-amber-300 transition"
                      >
                        <Calculator className="w-3 h-3" />
                        <span>Calculate</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <MathRenderer formula={item.math} size="md" className="text-amber-300" />
                </div>

                <p className="text-[11px] text-slate-400 italic">
                  <span className="text-slate-300 font-medium">Application:</span> {item.whenToUse}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
