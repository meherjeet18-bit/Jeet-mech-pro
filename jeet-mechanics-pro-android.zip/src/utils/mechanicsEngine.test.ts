/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Unit Tests for Mechanics Calculation Engine
 * Verifies mandatory numerical test cases and syllabus solvers
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  solveParallelogramLaw,
  solveResolutionOfForce,
  solveMomentOfForce,
  solveCouple,
  solveLamisTheorem,
  solveSimplySupportedBeam,
  solveHorizontalFriction,
  solveInclinedPlaneFriction,
  solveTSectionCentroid,
  solveRectangleMOI,
  solveLiftingMachine,
  solveGearTrain,
} from './mechanicsEngine.ts';

// -------------------------------------------------------------
// MANDATORY TEST NUMERICAL SPECIFIED BY USER
// -------------------------------------------------------------
test('Mandatory Test Numerical: F1=6N, F2=8N, theta=90 deg => R=10N', () => {
  const result = solveParallelogramLaw(6, 8, 90);

  // Exact numerical accuracy checks
  assert.equal(result.finalAnswer.value, '10');
  assert.equal(result.finalAnswer.unit, 'N');

  // Check the exact blackboard steps specified in prompt
  assert.ok(result.formula.includes('R = √(F₁² + F₂² + 2F₁F₂ cos θ)'));
  assert.ok(result.substitution.includes('R = √(6² + 8² + 2 × 6 × 8 × cos 90°)'));
  assert.ok(result.step1.includes('36 + 64 + 96 × 0'));
  assert.ok(result.step2.includes('36 + 64 + 0'));
  assert.ok(result.step3.includes('√100'));
  assert.ok(result.step4.includes('10 N'));
  assert.ok(result.conceptExplanation.includes('Pythagoras Theorem'));
});

test('Unit 2: Force Resolution into Fx and Fy', () => {
  // 100 N at 30 deg => Fx = 100 * cos(30°) = 86.603 N, Fy = 100 * sin(30°) = 50 N
  const res = solveResolutionOfForce(100, 30);
  assert.ok(res.finalAnswer.fullText.includes('86.603'));
  assert.ok(res.finalAnswer.fullText.includes('50'));
});

test('Unit 2: Moment of a force and Couple', () => {
  const m = solveMomentOfForce(50, 2, 90);
  assert.equal(m.finalAnswer.value, '100');

  const c = solveCouple(25, 0.4);
  assert.equal(c.finalAnswer.value, '10');
});

test("Unit 3: Lami's Theorem Solver", () => {
  // Symmetric equilibrium: F1 = 100 N, alpha = 120, beta = 120 => gamma = 120, F2=100, F3=100
  const lamis = solveLamisTheorem(100, 120, 120);
  assert.ok(lamis.step1.includes('120°'));
  assert.ok(String(lamis.finalAnswer.value).includes('100'));
});

test('Unit 3: Simply Supported Beam Reactions', () => {
  // Beam L = 6m, point load 1200 N at 2m from A, UDL = 0
  // R_B * 6 = 1200 * 2 = 2400 => R_B = 400 N, R_A = 800 N
  const beam = solveSimplySupportedBeam(6, 1200, 2, 0);
  assert.ok(beam.finalAnswer.fullText.includes('R_A = 800 N'));
  assert.ok(beam.finalAnswer.fullText.includes('R_B = 400 N'));
});

test('Unit 4: Friction on Horizontal Plane and Incline', () => {
  // W = 200 N, mu = 0.25, pull angle = 0 => P = 50 N
  const horiz = solveHorizontalFriction(200, 0.25, 0);
  assert.equal(horiz.finalAnswer.value, '50');

  // Incline: W = 100 N, mu = 0.3, alpha = 30, up the plane
  const inc = solveInclinedPlaneFriction(100, 0.3, 30, 'up');
  assert.ok(parseFloat(inc.finalAnswer.value as string) > 50);
});

test('Unit 5: Centroid of Composite T-Section', () => {
  // Flange: 100 x 20, Web: 20 x 80
  // A1 (web) = 1600, y1 = 40, A1*y1 = 64000
  // A2 (flange) = 2000, y2 = 80 + 10 = 90, A2*y2 = 180000
  // Total A = 3600, Total Ay = 244000, y_bar = 244000 / 3600 = 67.778 mm
  const tSec = solveTSectionCentroid(100, 20, 20, 80);
  assert.ok(tSec.finalAnswer.fullText.includes('67.778'));
});

test('Unit 6: Area Moment of Inertia of Rectangle', () => {
  // b = 20, d = 40
  // I_xx = (20 * 40^3) / 12 = 106666.667 mm^4
  // I_base = (20 * 40^3) / 3 = 426666.667 mm^4
  const moi = solveRectangleMOI(20, 40);
  assert.ok(moi.finalAnswer.fullText.includes('106666.667'));
  assert.ok(moi.finalAnswer.fullText.includes('426666.667'));
});

test('Unit 7: Simple Lifting Machine', () => {
  // Wheel and axle: Load = 1000 N, Effort = 250 N, D = 400 mm, d = 80 mm => VR = 5, MA = 4, eff = 80% (Reversible)
  const mach = solveLiftingMachine('wheel_axle', 1000, 250, { D: 400, d: 80 });
  assert.ok(mach.finalAnswer.fullText.includes('M.A. = 4'));
  assert.ok(mach.finalAnswer.fullText.includes('V.R. = 5'));
  assert.ok(mach.finalAnswer.fullText.includes('η = 80%'));
  assert.ok(mach.finalAnswer.fullText.includes('Reversible'));
});

test('Unit 8: Simple and Compound Gear Train', () => {
  // Driver N1 = 1200 RPM, T1 = 20, T2 = 60 => N2 = 1200 * (20/60) = 400 RPM
  const gearSimple = solveGearTrain('simple', 1200, 20, 60);
  assert.equal(gearSimple.finalAnswer.value, '400');
});
