/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO — Core Calculation & Step-by-Step Solution Engine
 * Designed according to Diploma First-Year Engineering Mechanics (Course Code: TH-7)
 * Created by Jeet
 */

export interface GivenItem {
  symbol: string;
  label: string;
  value: number | string;
  unit: string;
}

export interface BlackboardSolution {
  solverId: string;
  title: string;
  question: string;
  given: GivenItem[];
  toFind: string;
  formula: string;
  substitution: string;
  step1: string;
  step2: string;
  step3: string;
  step4: string;
  finalAnswer: {
    symbol: string;
    value: string | number;
    unit: string;
    fullText: string;
  };
  conceptExplanation: string;
  verification: string;
  diagramData?: Record<string, any>;
}

// Format numbers nicely: integer if whole, else up to 3 decimals, trimming trailing zeros
export function formatNum(n: number, decimals: number = 3): string {
  if (!isFinite(n) || isNaN(n)) return '0';
  const factor = Math.pow(10, decimals);
  const rounded = Math.round(n * factor) / factor;
  return rounded.toString();
}

export function degToRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

export function radToDeg(rad: number): number {
  return (rad * 180) / Math.PI;
}

// -------------------------------------------------------------
// UNIT 2: PARALLELOGRAM LAW OF FORCES (MANDATORY TEST NUMERICAL)
// -------------------------------------------------------------
export function solveParallelogramLaw(
  f1: number,
  f2: number,
  thetaDeg: number
): BlackboardSolution {
  const thetaRad = degToRad(thetaDeg);
  const cosVal = Math.cos(thetaRad);
  const sinVal = Math.sin(thetaRad);

  const f1Sq = f1 * f1;
  const f2Sq = f2 * f2;
  const twoF1F2 = 2 * f1 * f2;
  const productTerm = twoF1F2 * cosVal;
  const sumInside = f1Sq + f2Sq + productTerm;
  const r = Math.sqrt(Math.max(0, sumInside));

  // Direction alpha with F1: tan alpha = (F2 sin theta) / (F1 + F2 cos theta)
  const numAlpha = f2 * sinVal;
  const denAlpha = f1 + f2 * cosVal;
  let alphaDeg = 0;
  if (Math.abs(denAlpha) > 0.000001) {
    alphaDeg = radToDeg(Math.atan2(numAlpha, denAlpha));
    if (alphaDeg < 0) alphaDeg += 360;
  } else {
    alphaDeg = 90;
  }

  // Exact step-by-step strings matching classroom blackboard
  const f1SqStr = formatNum(f1Sq);
  const f2SqStr = formatNum(f2Sq);
  const twoF1F2Str = formatNum(twoF1F2);
  const cosStr = formatNum(cosVal, 4);
  const productTermStr = formatNum(productTerm);
  const sumInsideStr = formatNum(sumInside);
  const rStr = formatNum(r);
  const alphaStr = formatNum(alphaDeg, 2);

  return {
    solverId: 'parallelogram_law',
    title: 'Parallelogram Law of Forces',
    question: `Find the resultant R and its direction α for two forces F₁ = ${f1} N and F₂ = ${f2} N acting at a point with an included angle θ = ${thetaDeg}°.`,
    given: [
      { symbol: 'F₁', label: 'First Force', value: f1, unit: 'N' },
      { symbol: 'F₂', label: 'Second Force', value: f2, unit: 'N' },
      { symbol: 'θ', label: 'Included Angle', value: thetaDeg, unit: '°' },
    ],
    toFind: 'Resultant force magnitude (R) and direction angle (α) with respect to F₁.',
    formula: 'R = √(F₁² + F₂² + 2F₁F₂ cos θ)',
    substitution: `R = √(${f1}² + ${f2}² + 2 × ${f1} × ${f2} × cos ${thetaDeg}°)`,
    step1: `R = √(${f1SqStr} + ${f2SqStr} + ${twoF1F2Str} × ${cosStr})`,
    step2: `R = √(${f1SqStr} + ${f2SqStr} + ${productTermStr})`,
    step3: `R = √${sumInsideStr}`,
    step4: `R = ${rStr} N`,
    finalAnswer: {
      symbol: 'R',
      value: rStr,
      unit: 'N',
      fullText: `R = ${rStr} N at α = ${alphaStr}° with F₁`,
    },
    conceptExplanation: `Bhai samjho: Parallelogram Law bolta hai ki agar do concurrent forces ko kisi parallelogram ki do adjacent sides se represent karein, to unka diagonal resultant (R) ko represent karta hai. Jab θ = 90° hota hai, tab cos 90° = 0 ho jata hai aur ye seedha Pythagoras Theorem (R = √(F₁² + F₂²)) ban jata hai!`,
    verification: `Check: (1) Range test: |F₁ - F₂| ≤ R ≤ (F₁ + F₂) => |${f1} - ${f2}| ≤ ${rStr} ≤ ${f1 + f2}. Satisfied! (2) Direction formula tan α = (${f2} × sin ${thetaDeg}°) / (${f1} + ${f2} × cos ${thetaDeg}°) = ${alphaStr}°. Equilibrium check verified.`,
    diagramData: {
      type: 'parallelogram',
      f1,
      f2,
      thetaDeg,
      r,
      alphaDeg,
    },
  };
}

// -------------------------------------------------------------
// UNIT 2: RESOLUTION OF FORCES
// -------------------------------------------------------------
export function solveResolutionOfForce(
  f: number,
  thetaDeg: number
): BlackboardSolution {
  const thetaRad = degToRad(thetaDeg);
  const cosVal = Math.cos(thetaRad);
  const sinVal = Math.sin(thetaRad);

  const fx = f * cosVal;
  const fy = f * sinVal;

  const cosStr = formatNum(cosVal, 4);
  const sinStr = formatNum(sinVal, 4);
  const fxStr = formatNum(fx);
  const fyStr = formatNum(fy);

  return {
    solverId: 'force_resolution',
    title: 'Resolution of Force into Perpendicular Components',
    question: `Resolve a coplanar force F = ${f} N acting at an inclination angle θ = ${thetaDeg}° with the horizontal axis into its rectangular components Fₓ and Fᵧ.`,
    given: [
      { symbol: 'F', label: 'Magnitude of Force', value: f, unit: 'N' },
      { symbol: 'θ', label: 'Angle with Horizontal (X-axis)', value: thetaDeg, unit: '°' },
    ],
    toFind: 'Horizontal component (Fₓ) and Vertical component (Fᵧ).',
    formula: 'Fₓ = F cos θ  and  Fᵧ = F sin θ',
    substitution: `Fₓ = ${f} × cos ${thetaDeg}°  and  Fᵧ = ${f} × sin ${thetaDeg}°`,
    step1: `cos ${thetaDeg}° = ${cosStr},  sin ${thetaDeg}° = ${sinStr}`,
    step2: `Fₓ = ${f} × ${cosStr} = ${fxStr} N`,
    step3: `Fᵧ = ${f} × ${sinStr} = ${fyStr} N`,
    step4: `Vector form: F̄ = (${fxStr}) î + (${fyStr}) ĵ N`,
    finalAnswer: {
      symbol: 'Fₓ, Fᵧ',
      value: `Fₓ = ${fxStr} N, Fᵧ = ${fyStr} N`,
      unit: 'N',
      fullText: `Fₓ = ${fxStr} N (horizontal), Fᵧ = ${fyStr} N (vertical)`,
    },
    conceptExplanation: `Bhai dhyan do: Jiss axis ke sath angle θ ban raha hota hai, wahan hamesha 'cos θ' lagta hai (Base component). Dusri perpendicular axis par hamesha 'sin θ' lagta hai. Agar force 1st quadrant me hai to dono positive honge.`,
    verification: `Check: √(Fₓ² + Fᵧ²) = √(${fxStr}² + ${fyStr}²) = √(${formatNum(fx * fx + fy * fy)}) ≈ ${f} N. Component resolution matches original magnitude!`,
    diagramData: {
      type: 'resolution',
      f,
      thetaDeg,
      fx,
      fy,
    },
  };
}

// -------------------------------------------------------------
// UNIT 2: MOMENT OF A FORCE & VARIGNON'S THEOREM
// -------------------------------------------------------------
export function solveMomentOfForce(
  f: number,
  distance: number,
  angleDeg: number = 90
): BlackboardSolution {
  const angleRad = degToRad(angleDeg);
  const sinVal = Math.sin(angleRad);
  // Perpendicular distance d_perp = distance * sin(angle)
  const dPerp = distance * sinVal;
  const moment = f * dPerp;

  const sinStr = formatNum(sinVal, 4);
  const dPerpStr = formatNum(dPerp);
  const momentStr = formatNum(moment);

  return {
    solverId: 'moment_of_force',
    title: 'Moment of a Force (Law of Moments)',
    question: `Calculate the moment of a force F = ${f} N acting at a distance d = ${distance} m from a pivot point at an angle θ = ${angleDeg}°.`,
    given: [
      { symbol: 'F', label: 'Applied Force', value: f, unit: 'N' },
      { symbol: 'd', label: 'Lever Arm Distance', value: distance, unit: 'm' },
      { symbol: 'θ', label: 'Angle with Line of Action', value: angleDeg, unit: '°' },
    ],
    toFind: 'Moment of force (M) about the pivot point.',
    formula: 'M = F × d_⟂ = F × (d × sin θ)',
    substitution: `M = ${f} × (${distance} × sin ${angleDeg}°)`,
    step1: `sin ${angleDeg}° = ${sinStr}`,
    step2: `Perpendicular arm d_⟂ = ${distance} × ${sinStr} = ${dPerpStr} m`,
    step3: `M = ${f} × ${dPerpStr}`,
    step4: `M = ${momentStr} N·m`,
    finalAnswer: {
      symbol: 'M',
      value: momentStr,
      unit: 'N·m',
      fullText: `M = ${momentStr} N·m (${moment >= 0 ? 'Clockwise / Turning Effect' : 'Anti-Clockwise'})`,
    },
    conceptExplanation: `Bhai samjho: Moment ka matlab hota hai 'Turning effect of force'. Force kitna lamba lever use kar raha hai usse rotational power banti hai. Formula me hamesha 'perpendicular distance' (90° distance) lena hota hai, direct distance nahi!`,
    verification: `Check: Dimensional analysis [M] = [F] × [L] = N × m = N·m. Varignon's Theorem states that the moment of a force equals the algebraic sum of the moments of its components.`,
    diagramData: {
      type: 'moment',
      f,
      distance,
      angleDeg,
      dPerp,
      moment,
    },
  };
}

// -------------------------------------------------------------
// UNIT 2: MOMENT OF A COUPLE
// -------------------------------------------------------------
export function solveCouple(
  f: number,
  armDistance: number
): BlackboardSolution {
  const coupleMoment = f * armDistance;
  const fStr = formatNum(f);
  const armStr = formatNum(armDistance);
  const coupleStr = formatNum(coupleMoment);

  return {
    solverId: 'couple_moment',
    title: 'Couple & Moment of a Couple',
    question: `Find the moment of a couple formed by two equal, opposite and parallel forces of magnitude F = ${f} N separated by an arm distance of a = ${armDistance} m.`,
    given: [
      { symbol: 'F', label: 'Equal and Opposite Force', value: f, unit: 'N' },
      { symbol: 'a', label: 'Arm of Couple (Perpendicular Distance)', value: armDistance, unit: 'm' },
    ],
    toFind: 'Moment of the couple (C or M_couple).',
    formula: 'C = F × a',
    substitution: `C = ${f} × ${armDistance}`,
    step1: `Equal and opposite forces produce zero translatory effect (ΣF = 0).`,
    step2: `Pure rotational effect generated = Magnitude of one force × Arm distance.`,
    step3: `C = ${fStr} × ${armStr}`,
    step4: `C = ${coupleStr} N·m`,
    finalAnswer: {
      symbol: 'C',
      value: coupleStr,
      unit: 'N·m',
      fullText: `C = ${coupleStr} N·m (Pure rotatory moment)`,
    },
    conceptExplanation: `Bhai yaad rakho: Couple ka resultant force hamesha ZERO hota hai, isiliye ye body ko aage peeche (translate) nahi kar sakta! Ye sirf aur sirf pure rotation (ghumaav) create karta hai, jaise steering wheel ya bottle ka dhakkan kholte waqt dono ungliyon se barabar aur ulta force lagana.`,
    verification: `Verification: ΣF = +F - F = 0 N. Couple is a free vector; its moment is the same about any point in the plane.`,
    diagramData: {
      type: 'couple',
      f,
      armDistance,
      coupleMoment,
    },
  };
}

// -------------------------------------------------------------
// UNIT 3: LAMI'S THEOREM (EQUILIBRIUM OF 3 CONCURRENT FORCES)
// -------------------------------------------------------------
export function solveLamisTheorem(
  f1: number,
  alphaDeg: number,
  betaDeg: number
): BlackboardSolution {
  // alpha is angle opposite to F1
  // beta is angle opposite to F2
  // gamma is angle opposite to F3 = 360 - alpha - beta
  const gammaDeg = 360 - alphaDeg - betaDeg;
  const alphaRad = degToRad(alphaDeg);
  const betaRad = degToRad(betaDeg);
  const gammaRad = degToRad(gammaDeg);

  const sinAlpha = Math.sin(alphaRad);
  const sinBeta = Math.sin(betaRad);
  const sinGamma = Math.sin(gammaRad);

  // F1 / sin(alpha) = F2 / sin(beta) = F3 / sin(gamma) = k
  const k = f1 / sinAlpha;
  const f2 = k * sinBeta;
  const f3 = k * sinGamma;

  const sinAlphaStr = formatNum(sinAlpha, 4);
  const sinBetaStr = formatNum(sinBeta, 4);
  const sinGammaStr = formatNum(sinGamma, 4);
  const f2Str = formatNum(f2);
  const f3Str = formatNum(f3);
  const gammaStr = formatNum(gammaDeg, 1);

  return {
    solverId: 'lamis_theorem',
    title: "Lami's Theorem Solver",
    question: `Three coplanar concurrent forces F₁, F₂, and F₃ are in equilibrium. Given F₁ = ${f1} N, angle opposite to F₁ (α) = ${alphaDeg}°, and angle opposite to F₂ (β) = ${betaDeg}°. Find unknown forces F₂ and F₃.`,
    given: [
      { symbol: 'F₁', label: 'Known Force', value: f1, unit: 'N' },
      { symbol: 'α', label: 'Angle opposite to F₁', value: alphaDeg, unit: '°' },
      { symbol: 'β', label: 'Angle opposite to F₂', value: betaDeg, unit: '°' },
    ],
    toFind: 'Unknown forces F₂ and F₃ and angle γ.',
    formula: 'F₁ / sin α = F₂ / sin β = F₃ / sin γ',
    substitution: `${f1} / sin(${alphaDeg}°) = F₂ / sin(${betaDeg}°) = F₃ / sin(${gammaStr}°)`,
    step1: `Third angle γ = 360° - (α + β) = 360° - (${alphaDeg}° + ${betaDeg}°) = ${gammaStr}°`,
    step2: `Evaluate trigonometric terms: sin(${alphaDeg}°) = ${sinAlphaStr}, sin(${betaDeg}°) = ${sinBetaStr}, sin(${gammaStr}°) = ${sinGammaStr}`,
    step3: `Constant ratio k = ${f1} / ${sinAlphaStr} = ${formatNum(k)} N`,
    step4: `F₂ = k × sin β = ${formatNum(k)} × ${sinBetaStr} = ${f2Str} N\nF₃ = k × sin γ = ${formatNum(k)} × ${sinGammaStr} = ${f3Str} N`,
    finalAnswer: {
      symbol: 'F₂, F₃',
      value: `F₂ = ${f2Str} N, F₃ = ${f3Str} N`,
      unit: 'N',
      fullText: `F₂ = ${f2Str} N and F₃ = ${f3Str} N (with γ = ${gammaStr}°)`,
    },
    conceptExplanation: `Bhai Lami's Theorem ka golden rule: Ye ONLY tab lagta hai jab theek 3 forces concurrent ho aur body perfect equilibrium me ho! Har force apne samne wale (opposite) angle ke sine ke proportional hota hai: F₁/sin α = F₂/sin β = F₃/sin γ.`,
    verification: `Check: F₁/sin α = ${formatNum(f1 / sinAlpha)} ≈ F₂/sin β = ${formatNum(f2 / sinBeta)} ≈ F₃/sin γ = ${formatNum(f3 / sinGamma)}. Equilibrium condition validated!`,
    diagramData: {
      type: 'lamis',
      f1,
      f2,
      f3,
      alphaDeg,
      betaDeg,
      gammaDeg,
    },
  };
}

// -------------------------------------------------------------
// UNIT 3: BEAM SUPPORT REACTIONS (SIMPLY SUPPORTED BEAM)
// -------------------------------------------------------------
export function solveSimplySupportedBeam(
  spanL: number,
  pointLoadW: number,
  pointLoadDistA: number,
  udlW: number = 0
): BlackboardSolution {
  // Beam AB of span L.
  // Point load W at distance 'a' from A.
  // UDL w (N/m) over the entire span. Total UDL load = w * L acting at L/2.
  const totalUdlLoad = udlW * spanL;
  const totalLoad = pointLoadW + totalUdlLoad;

  // Moment about A: ΣM_A = 0
  // R_B * L = (pointLoadW * a) + (totalUdlLoad * L/2)
  const momentPointLoad = pointLoadW * pointLoadDistA;
  const momentUdl = totalUdlLoad * (spanL / 2);
  const sumMomentsAboutA = momentPointLoad + momentUdl;
  const rb = sumMomentsAboutA / spanL;
  const ra = totalLoad - rb;

  const raStr = formatNum(ra);
  const rbStr = formatNum(rb);
  const sumMomentsStr = formatNum(sumMomentsAboutA);

  return {
    solverId: 'beam_reactions',
    title: 'Simply Supported Beam Reactions',
    question: `A simply supported beam AB of span L = ${spanL} m carries a concentrated point load W = ${pointLoadW} N at distance a = ${pointLoadDistA} m from left support A${udlW > 0 ? ` and a UDL of w = ${udlW} N/m over the entire span` : ''}. Find support reactions R_A and R_B.`,
    given: [
      { symbol: 'L', label: 'Span of Beam', value: spanL, unit: 'm' },
      { symbol: 'W', label: 'Point Load', value: pointLoadW, unit: 'N' },
      { symbol: 'a', label: 'Point Load Distance from A', value: pointLoadDistA, unit: 'm' },
      ...(udlW > 0 ? [{ symbol: 'w', label: 'UDL Intensity', value: udlW, unit: 'N/m' }] : []),
    ],
    toFind: 'Support reactions R_A and R_B.',
    formula: 'ΣFᵧ = 0  =>  R_A + R_B = Total Downward Load\nΣM_A = 0  =>  R_B × L - (W × a + w × L × L/2) = 0',
    substitution: `R_B × ${spanL} = (${pointLoadW} × ${pointLoadDistA}) + (${udlW} × ${spanL} × ${spanL / 2})`,
    step1: `Total Downward Load = W_point + W_udl = ${pointLoadW} + ${formatNum(totalUdlLoad)} = ${formatNum(totalLoad)} N`,
    step2: `Take Moments about support A (ΣM_A = 0):\nR_B × ${spanL} = ${formatNum(momentPointLoad)} + ${formatNum(momentUdl)} = ${sumMomentsStr} N·m`,
    step3: `R_B = ${sumMomentsStr} / ${spanL} = ${rbStr} N`,
    step4: `Using ΣFᵧ = 0:\nR_A = Total Load - R_B = ${formatNum(totalLoad)} - ${rbStr} = ${raStr} N`,
    finalAnswer: {
      symbol: 'R_A, R_B',
      value: `R_A = ${raStr} N, R_B = ${rbStr} N`,
      unit: 'N',
      fullText: `R_A = ${raStr} N (upward) and R_B = ${rbStr} N (upward)`,
    },
    conceptExplanation: `Bhai equilibrium ka funda: Beam ko na to niche girna hai (ΣFᵧ = 0) aur na hi gol gol ghoomna hai (ΣM = 0). Hamesha kisi ek support (A) par moment le lo, jisse R_A gayab ho jata hai aur direct R_B mil jata hai!`,
    verification: `Check: R_A + R_B = ${raStr} + ${rbStr} = ${formatNum(ra + rb)} N == Total Load (${formatNum(totalLoad)} N). ΣFᵧ = 0 verified!`,
    diagramData: {
      type: 'beam',
      spanL,
      pointLoadW,
      pointLoadDistA,
      udlW,
      ra,
      rb,
    },
  };
}

// -------------------------------------------------------------
// UNIT 4: FRICTION ON HORIZONTAL SURFACE
// -------------------------------------------------------------
export function solveHorizontalFriction(
  weightW: number,
  mu: number,
  pullAngleDeg: number = 0
): BlackboardSolution {
  // If pull angle = 0, P is horizontal: P = mu * W, N = W.
  // If inclined pull at angle theta:
  // ΣFy = 0 => N + P sin theta = W => N = W - P sin theta
  // ΣFx = 0 => P cos theta = F_lim = mu * N
  // P cos theta = mu (W - P sin theta) => P (cos theta + mu sin theta) = mu * W
  const thetaRad = degToRad(pullAngleDeg);
  const cosVal = Math.cos(thetaRad);
  const sinVal = Math.sin(thetaRad);

  const denom = cosVal + mu * sinVal;
  const pRequired = (mu * weightW) / denom;
  const normalReaction = weightW - pRequired * sinVal;
  const limitingFriction = mu * normalReaction;

  const angleOfFrictionDeg = radToDeg(Math.atan(mu));

  const pStr = formatNum(pRequired);
  const nStr = formatNum(normalReaction);
  const fLimStr = formatNum(limitingFriction);
  const phiStr = formatNum(angleOfFrictionDeg, 2);

  return {
    solverId: 'horizontal_friction',
    title: 'Friction on Horizontal Surface',
    question: `A body of weight W = ${weightW} N rests on a rough horizontal surface with coefficient of friction μ = ${mu}. Find the minimum effort P required to cause impending motion when pulled at an angle θ = ${pullAngleDeg}° to horizontal.`,
    given: [
      { symbol: 'W', label: 'Weight of Body', value: weightW, unit: 'N' },
      { symbol: 'μ', label: 'Coefficient of Friction', value: mu, unit: '-' },
      { symbol: 'θ', label: 'Angle of Pull with Horizontal', value: pullAngleDeg, unit: '°' },
    ],
    toFind: 'Effort P, Normal Reaction N, and Limiting Friction F_lim.',
    formula: 'N = W - P sin θ  and  P cos θ = μ N  =>  P = (μ × W) / (cos θ + μ sin θ)',
    substitution: `P = (${mu} × ${weightW}) / (cos ${pullAngleDeg}° + ${mu} × sin ${pullAngleDeg}°)`,
    step1: `cos ${pullAngleDeg}° = ${formatNum(cosVal, 4)},  sin ${pullAngleDeg}° = ${formatNum(sinVal, 4)}`,
    step2: `Denominator = ${formatNum(cosVal, 4)} + (${mu} × ${formatNum(sinVal, 4)}) = ${formatNum(denom, 4)}`,
    step3: `Numerator = ${mu} × ${weightW} = ${formatNum(mu * weightW)} N`,
    step4: `P = ${formatNum(mu * weightW)} / ${formatNum(denom, 4)} = ${pStr} N\nNormal Reaction N = ${weightW} - (${pStr} × ${formatNum(sinVal, 4)}) = ${nStr} N\nLimiting Friction F_lim = μ × N = ${fLimStr} N`,
    finalAnswer: {
      symbol: 'P',
      value: pStr,
      unit: 'N',
      fullText: `P = ${pStr} N (Normal Reaction N = ${nStr} N, F_lim = ${fLimStr} N)`,
    },
    conceptExplanation: `Bhai dhyan do: Impending motion ka matlab hota hai 'the point where motion is just about to start'. Jab pull upar ki taraf angled hota hai (θ > 0), to uska vertical component normal reaction N ko kam kar deta hai, jisse friction bhi kam ho jata hai! Angle of friction φ = tan⁻¹(μ) = ${phiStr}°.`,
    verification: `Check: P cos θ = ${pStr} × ${formatNum(cosVal, 4)} = ${formatNum(pRequired * cosVal)} N. Limiting friction F_lim = μ × N = ${mu} × ${nStr} = ${fLimStr} N. Horizontal equilibrium balanced!`,
    diagramData: {
      type: 'horizontal_friction',
      weightW,
      mu,
      pullAngleDeg,
      pRequired,
      normalReaction,
      limitingFriction,
    },
  };
}

// -------------------------------------------------------------
// UNIT 4: FRICTION ON INCLINED PLANE
// -------------------------------------------------------------
export function solveInclinedPlaneFriction(
  weightW: number,
  mu: number,
  alphaDeg: number,
  direction: 'up' | 'down' = 'up'
): BlackboardSolution {
  // alpha = angle of inclination of plane
  // phi = angle of friction = atan(mu)
  // For motion impending UP the plane with force parallel to plane:
  // P_up = W sin(alpha) + mu * W cos(alpha) = W (sin alpha + mu cos alpha)
  // For motion impending DOWN the plane (minimum force to prevent sliding):
  // P_down = W sin(alpha) - mu * W cos(alpha)
  const alphaRad = degToRad(alphaDeg);
  const sinAlpha = Math.sin(alphaRad);
  const cosAlpha = Math.cos(alphaRad);

  const normalN = weightW * cosAlpha;
  const fLim = mu * normalN;
  const gravityComponentDownPlane = weightW * sinAlpha;

  let pEffort = 0;
  if (direction === 'up') {
    pEffort = gravityComponentDownPlane + fLim;
  } else {
    pEffort = Math.max(0, gravityComponentDownPlane - fLim);
  }

  const phiDeg = radToDeg(Math.atan(mu));
  const pStr = formatNum(pEffort);
  const nStr = formatNum(normalN);
  const fLimStr = formatNum(fLim);
  const gCompStr = formatNum(gravityComponentDownPlane);

  return {
    solverId: 'inclined_friction',
    title: `Friction on Inclined Plane (${direction === 'up' ? 'Impending UP' : 'Preventing Sliding DOWN'})`,
    question: `A body of weight W = ${weightW} N rests on an inclined plane of slope α = ${alphaDeg}° with coefficient of friction μ = ${mu}. Find the force P parallel to the plane required for impending motion ${direction === 'up' ? 'UP the plane' : 'to prevent sliding DOWN'}.`,
    given: [
      { symbol: 'W', label: 'Weight of Body', value: weightW, unit: 'N' },
      { symbol: 'μ', label: 'Coefficient of Friction', value: mu, unit: '-' },
      { symbol: 'α', label: 'Inclination of Plane', value: alphaDeg, unit: '°' },
      { symbol: 'Direction', label: 'Impending Motion', value: direction.toUpperCase(), unit: '-' },
    ],
    toFind: `Effort P parallel to the incline for motion ${direction}.`,
    formula: direction === 'up'
      ? 'P = W sin α + μ W cos α = W (sin α + μ cos α)'
      : 'P = W sin α - μ W cos α = W (sin α - μ cos α)',
    substitution: `P = ${weightW} × sin ${alphaDeg}° ${direction === 'up' ? '+' : '-'} ${mu} × (${weightW} × cos ${alphaDeg}°)`,
    step1: `sin ${alphaDeg}° = ${formatNum(sinAlpha, 4)},  cos ${alphaDeg}° = ${formatNum(cosAlpha, 4)}`,
    step2: `Normal Reaction N = W cos α = ${weightW} × ${formatNum(cosAlpha, 4)} = ${nStr} N`,
    step3: `Limiting Friction F_lim = μ × N = ${mu} × ${nStr} = ${fLimStr} N\nGravity Component down the plane = W sin α = ${gCompStr} N`,
    step4: `P = ${gCompStr} ${direction === 'up' ? '+' : '-'} ${fLimStr} = ${pStr} N`,
    finalAnswer: {
      symbol: 'P',
      value: pStr,
      unit: 'N',
      fullText: `P = ${pStr} N (parallel to plane, directed up the incline)`,
    },
    conceptExplanation: `Bhai rule samjho: Friction hamesha 'impending motion' ke ULTE direction me act karta hai! Jab body ko UPAR khinchna hai to friction NEECHE lagega, isiliye dono forces add hote hain. Agar body apne aap fisal rahi ho (α > φ = ${formatNum(phiDeg, 1)}°), to rokkne ke liye P = W(sin α - μ cos α) chahiye hota hai.`,
    verification: `Check: Angle of Repose α_repose = φ = tan⁻¹(${mu}) = ${formatNum(phiDeg, 2)}°. Since α (${alphaDeg}°) ${alphaDeg > phiDeg ? '>' : '<='} φ, body is naturally ${alphaDeg > phiDeg ? 'UNSTABLE without support' : 'in resting equilibrium'}.`,
    diagramData: {
      type: 'inclined_friction',
      weightW,
      mu,
      alphaDeg,
      direction,
      pEffort,
      normalN,
      fLim,
    },
  };
}

// -------------------------------------------------------------
// UNIT 5: CENTROID OF COMPOSITE SECTIONS (T-SECTION, I-SECTION, ETC.)
// -------------------------------------------------------------
export interface CompositePart {
  shape: string;
  name: string;
  width: number;
  height: number;
  x: number;
  y: number;
}

export function solveTSectionCentroid(
  flangeWidth: number,
  flangeThick: number,
  webWidth: number,
  webHeight: number
): BlackboardSolution & { tableRows: any[] } {
  // Let bottom of web be y = 0, symmetric about y-axis (X_bar = 0 or width/2)
  // Part 1: Web (rectangle: width = webWidth, height = webHeight)
  // Area A1 = webWidth * webHeight
  // y1 = webHeight / 2
  const a1 = webWidth * webHeight;
  const y1 = webHeight / 2;
  const a1y1 = a1 * y1;

  // Part 2: Flange (rectangle: width = flangeWidth, height = flangeThick)
  // Area A2 = flangeWidth * flangeThick
  // y2 = webHeight + (flangeThick / 2)
  const a2 = flangeWidth * flangeThick;
  const y2 = webHeight + flangeThick / 2;
  const a2y2 = a2 * y2;

  const totalA = a1 + a2;
  const totalAy = a1y1 + a2y2;
  const yBar = totalAy / totalA;
  const xBar = flangeWidth / 2; // Symmetric about vertical centerline

  const yBarStr = formatNum(yBar);
  const xBarStr = formatNum(xBar);

  const tableRows = [
    {
      part: '1 (Web)',
      area: formatNum(a1),
      y: formatNum(y1),
      ay: formatNum(a1y1),
    },
    {
      part: '2 (Flange)',
      area: formatNum(a2),
      y: formatNum(y2),
      ay: formatNum(a2y2),
    },
    {
      part: 'Total (Σ)',
      area: formatNum(totalA),
      y: '-',
      ay: formatNum(totalAy),
    },
  ];

  return {
    solverId: 'centroid_t_section',
    title: 'Centroid of Composite T-Section',
    question: `Find the centroid (X̄, Ȳ) of a standard T-section having flange ${flangeWidth} mm × ${flangeThick} mm and web ${webWidth} mm × ${webHeight} mm, measured from the base of the web.`,
    given: [
      { symbol: 'b_f', label: 'Flange Width', value: flangeWidth, unit: 'mm' },
      { symbol: 't_f', label: 'Flange Thickness', value: flangeThick, unit: 'mm' },
      { symbol: 't_w', label: 'Web Thickness', value: webWidth, unit: 'mm' },
      { symbol: 'h_w', label: 'Web Height', value: webHeight, unit: 'mm' },
    ],
    toFind: 'Centroid coordinates (X̄, Ȳ) from the bottom-most base.',
    formula: 'Ȳ = Σ(Aᵢ × yᵢ) / ΣAᵢ = (A₁y₁ + A₂y₂) / (A₁ + A₂)',
    substitution: `Ȳ = (${a1} × ${y1} + ${a2} × ${y2}) / (${a1} + ${a2})`,
    step1: `Part 1 (Web): A₁ = ${webWidth} × ${webHeight} = ${formatNum(a1)} mm²,  y₁ = ${webHeight}/2 = ${formatNum(y1)} mm`,
    step2: `Part 2 (Flange): A₂ = ${flangeWidth} × ${flangeThick} = ${formatNum(a2)} mm²,  y₂ = ${webHeight} + ${flangeThick}/2 = ${formatNum(y2)} mm`,
    step3: `ΣA = ${formatNum(a1)} + ${formatNum(a2)} = ${formatNum(totalA)} mm²\nΣ(A·y) = (${formatNum(a1)} × ${formatNum(y1)}) + (${formatNum(a2)} × ${formatNum(y2)}) = ${formatNum(totalAy)} mm³`,
    step4: `Ȳ = ${formatNum(totalAy)} / ${formatNum(totalA)} = ${yBarStr} mm\nBy symmetry about vertical Y-axis, X̄ = ${flangeWidth} / 2 = ${xBarStr} mm`,
    finalAnswer: {
      symbol: 'X̄, Ȳ',
      value: `X̄ = ${xBarStr} mm, Ȳ = ${yBarStr} mm`,
      unit: 'mm',
      fullText: `X̄ = ${xBarStr} mm, Ȳ = ${yBarStr} mm (from bottom of web)`,
    },
    conceptExplanation: `Bhai Centroid ka matlab hota hai 'Geometric Center of Area' (sirf 2D planes ke liye). Jab koi shape symmetrical ho (jaise T-section Y-axis ke symmetrical hai), to uska X̄ seedha center of symmetry par hota hai bina calculation ke! Bas vertical Ȳ nikalna hota hai weighted average formula se.`,
    verification: `Check: Total height of T-section H = ${webHeight + flangeThick} mm. Since flange has large area at top, Ȳ (${yBarStr} mm) must lie above web midpoint (${formatNum(webHeight / 2)} mm). Condition satisfied!`,
    tableRows,
    diagramData: {
      type: 't_section',
      flangeWidth,
      flangeThick,
      webWidth,
      webHeight,
      yBar,
      xBar,
    },
  };
}

// -------------------------------------------------------------
// UNIT 6: MOMENT OF INERTIA (PARALLEL AXIS THEOREM & I-SECTION)
// -------------------------------------------------------------
export function solveRectangleMOI(b: number, d: number): BlackboardSolution {
  const ixx = (b * Math.pow(d, 3)) / 12;
  const iyy = (d * Math.pow(b, 3)) / 12;
  const ibase = (b * Math.pow(d, 3)) / 3; // About base using parallel axis: I_G + Ah^2 = bd^3/12 + bd*(d/2)^2 = bd^3/3

  const ixxStr = formatNum(ixx);
  const iyyStr = formatNum(iyy);
  const ibaseStr = formatNum(ibase);

  return {
    solverId: 'moi_rectangle',
    title: 'Moment of Inertia of Rectangle',
    question: `Calculate the area moment of inertia of a rectangular section of breadth b = ${b} mm and depth d = ${d} mm about its centroidal X-X and Y-Y axes, and about its base.`,
    given: [
      { symbol: 'b', label: 'Breadth', value: b, unit: 'mm' },
      { symbol: 'd', label: 'Depth', value: d, unit: 'mm' },
    ],
    toFind: 'I_xx (centroidal), I_yy (centroidal), and I_base.',
    formula: 'I_xx = (b × d³) / 12  and  I_base = (b × d³) / 3',
    substitution: `I_xx = (${b} × ${d}³) / 12`,
    step1: `Evaluate powers: d³ = ${d}³ = ${Math.pow(d, 3)} mm³`,
    step2: `Numerator = ${b} × ${Math.pow(d, 3)} = ${b * Math.pow(d, 3)} mm⁴`,
    step3: `I_xx = (${b * Math.pow(d, 3)}) / 12 = ${ixxStr} mm⁴`,
    step4: `Using Parallel Axis Theorem for base (h = d/2):\nI_base = I_xx + A × h² = ${ixxStr} + (${b * d} × (${d}/2)²) = ${ibaseStr} mm⁴\nI_yy = (d × b³) / 12 = ${iyyStr} mm⁴`,
    finalAnswer: {
      symbol: 'I_xx',
      value: ixxStr,
      unit: 'mm⁴',
      fullText: `I_xx = ${ixxStr} mm⁴, I_yy = ${iyyStr} mm⁴, I_base = ${ibaseStr} mm⁴`,
    },
    conceptExplanation: `Bhai samjho: Area Moment of Inertia (Second Moment of Area) bending resistance ko darshata hai! Jiss axis ke across bending hoti hai, uski depth ka cube (d³) aata hai. Yahi wajah hai ki wooden beams ya steel girders ko vertical (deep) rakha jata hai na ki flat!`,
    verification: `Check: Parallel axis theorem confirms I_base = I_G + Ah² = bd³/12 + bd(d²/4) = bd³/3. Ratio I_base / I_xx = (1/3) / (1/12) = 4. Exact check verified!`,
    diagramData: {
      type: 'rect_moi',
      b,
      d,
      ixx,
      iyy,
      ibase,
    },
  };
}

// -------------------------------------------------------------
// UNIT 7: SIMPLE LIFTING MACHINES
// -------------------------------------------------------------
export function solveLiftingMachine(
  machineType: 'wheel_axle' | 'screw_jack' | 'pulley_1' | 'pulley_2' | 'crab_winch',
  loadW: number,
  effortP: number,
  params: Record<string, number>
): BlackboardSolution {
  // Machine-specific Velocity Ratio calculation
  let vr = 1;
  let vrFormulaStr = '';
  let vrSubStr = '';

  if (machineType === 'wheel_axle') {
    // params: D (effort wheel diameter), d (load axle diameter)
    const D = params.D || 300;
    const d = params.d || 100;
    vr = D / d;
    vrFormulaStr = 'V.R. = D / d';
    vrSubStr = `V.R. = ${D} / ${d} = ${formatNum(vr)}`;
  } else if (machineType === 'screw_jack') {
    // params: L (length of handle), p (pitch of screw)
    const L = params.L || 500;
    const p = params.p || 10;
    vr = (2 * Math.PI * L) / p;
    vrFormulaStr = 'V.R. = (2 × π × L) / p';
    vrSubStr = `V.R. = (2 × π × ${L}) / ${p} = ${formatNum(vr)}`;
  } else if (machineType === 'pulley_1') {
    // First system of pulleys: VR = 2^n
    const n = params.n || 3;
    vr = Math.pow(2, n);
    vrFormulaStr = 'V.R. = 2ⁿ';
    vrSubStr = `V.R. = 2^${n} = ${vr}`;
  } else if (machineType === 'pulley_2') {
    // Second system of pulleys (block and tackle): VR = total pulleys n
    const n = params.n || 4;
    vr = n;
    vrFormulaStr = 'V.R. = n';
    vrSubStr = `V.R. = ${n}`;
  } else if (machineType === 'crab_winch') {
    // Single Purchase Crab Winch: VR = (2R / d) * (T2 / T1)
    const R = params.R || 300;
    const d = params.d || 100;
    const T1 = params.T1 || 20; // Pinion
    const T2 = params.T2 || 100; // Spur gear
    vr = ((2 * R) / d) * (T2 / T1);
    vrFormulaStr = 'V.R. = (2R / d) × (T₂ / T₁)';
    vrSubStr = `V.R. = ((2 × ${R}) / ${d}) × (${T2} / ${T1}) = ${formatNum(vr)}`;
  }

  const ma = loadW / effortP;
  const efficiency = (ma / vr) * 100;
  const isReversible = efficiency > 50;

  // Effort lost in friction: P_f = P - (W / VR)
  const idealEffort = loadW / vr;
  const effortLostFriction = effortP - idealEffort;

  const maStr = formatNum(ma);
  const vrStr = formatNum(vr);
  const effStr = formatNum(efficiency, 2);
  const pLostStr = formatNum(effortLostFriction);

  return {
    solverId: `machine_${machineType}`,
    title: `Lifting Machine Analysis (${machineType.replace('_', ' ').toUpperCase()})`,
    question: `A lifting machine lifts a load of W = ${loadW} N by an effort P = ${effortP} N with calculated Velocity Ratio V.R. = ${vrStr}. Find Mechanical Advantage (M.A.), Efficiency (η), effort lost in friction, and whether the machine is reversible.`,
    given: [
      { symbol: 'W', label: 'Load Lifted', value: loadW, unit: 'N' },
      { symbol: 'P', label: 'Effort Applied', value: effortP, unit: 'N' },
      { symbol: 'V.R.', label: 'Velocity Ratio', value: vrStr, unit: '-' },
    ],
    toFind: 'Mechanical Advantage (M.A.), Efficiency (η), Effort lost in friction (P_f), Reversibility.',
    formula: 'M.A. = W / P  and  η = (M.A. / V.R.) × 100%',
    substitution: `M.A. = ${loadW} / ${effortP}  and  η = (${maStr} / ${vrStr}) × 100%`,
    step1: `Velocity Ratio Calculation: ${vrFormulaStr} => ${vrSubStr}`,
    step2: `Mechanical Advantage: M.A. = Load / Effort = ${loadW} / ${effortP} = ${maStr}`,
    step3: `Efficiency: η = (M.A. / V.R.) × 100% = (${maStr} / ${vrStr}) × 100% = ${effStr}%`,
    step4: `Effort Lost in Friction: P_f = P - (W / V.R.) = ${effortP} - (${loadW} / ${vrStr}) = ${pLostStr} N\nReversibility condition: η ${isReversible ? '> 50% => REVERSIBLE' : '≤ 50% => NON-REVERSIBLE (SELF-LOCKING)'}`,
    finalAnswer: {
      symbol: 'M.A., η',
      value: `M.A. = ${maStr}, η = ${effStr}%`,
      unit: '%',
      fullText: `M.A. = ${maStr}, V.R. = ${vrStr}, η = ${effStr}% (${isReversible ? 'Reversible' : 'Self-Locking / Non-Reversible'})`,
    },
    conceptExplanation: `Bhai exam hack: Agar kisi machine ki efficiency 50% se zyada hoti hai to wo REVERSIBLE hoti hai (effort chhodte hi load wapas gir jayega). Agar efficiency ≤ 50% hai to machine SELF-LOCKING hoti hai, jaise Screw Jack — car ko uthaane ke baad handle chhodne par bhi car niche nahi girti!`,
    verification: `Check: Maximum Theoretical Efficiency = 100%. Calculated η = ${effStr}%. Since friction exists, P_f (${pLostStr} N) > 0 and η < 100%. Verified!`,
    diagramData: {
      type: 'lifting_machine',
      machineType,
      loadW,
      effortP,
      ma,
      vr,
      efficiency,
      isReversible,
      effortLostFriction,
    },
  };
}

// -------------------------------------------------------------
// UNIT 8: GEAR AND GEAR TRAIN
// -------------------------------------------------------------
export function solveGearTrain(
  trainType: 'simple' | 'compound',
  speedDriverN1: number,
  teethT1: number,
  teethT2: number,
  compoundParams?: { teethT3: number; teethT4: number }
): BlackboardSolution {
  let speedLast = 0;
  let speedRatio = 0;
  let formulaStr = '';
  let subStr = '';
  let step3Str = '';

  if (trainType === 'simple') {
    // Simple gear train: N1 / N2 = T2 / T1 => N2 = N1 * (T1 / T2)
    speedRatio = teethT2 / teethT1; // Driver to follower speed ratio
    speedLast = speedDriverN1 * (teethT1 / teethT2);
    formulaStr = 'Speed Ratio = N₁ / N₂ = T₂ / T₁';
    subStr = `${speedDriverN1} / N₂ = ${teethT2} / ${teethT1}`;
    step3Str = `N₂ = N₁ × (T₁ / T₂) = ${speedDriverN1} × (${teethT1} / ${teethT2}) = ${formatNum(speedLast)} RPM`;
  } else {
    // Compound gear train: N1 / N4 = (T2 * T4) / (T1 * T3)
    const t3 = compoundParams?.teethT3 || 25;
    const t4 = compoundParams?.teethT4 || 75;
    speedRatio = (teethT2 * t4) / (teethT1 * t3);
    speedLast = speedDriverN1 / speedRatio;
    formulaStr = 'Speed Ratio = N_driver / N_driven = (T₂ × T₄) / (T₁ × T₃)';
    subStr = `Speed Ratio = (${teethT2} × ${t4}) / (${teethT1} × ${t3})`;
    step3Str = `Speed Ratio = ${formatNum(teethT2 * t4)} / ${formatNum(teethT1 * t3)} = ${formatNum(speedRatio, 3)}\nN_last = N₁ / Speed Ratio = ${speedDriverN1} / ${formatNum(speedRatio, 3)} = ${formatNum(speedLast)} RPM`;
  }

  const speedLastStr = formatNum(speedLast);
  const speedRatioStr = formatNum(speedRatio, 3);

  return {
    solverId: `geartrain_${trainType}`,
    title: `${trainType === 'simple' ? 'Simple' : 'Compound'} Gear Train Velocity Ratio`,
    question: `A ${trainType} gear train has driver gear 1 with T₁ = ${teethT1} teeth rotating at N₁ = ${speedDriverN1} RPM meshing with gear 2 (T₂ = ${teethT2} teeth)${trainType === 'compound' ? ` compounded with gear 3 (T₃ = ${compoundParams?.teethT3}) driving gear 4 (T₄ = ${compoundParams?.teethT4})` : ''}. Find the speed of the driven gear and the speed ratio.`,
    given: [
      { symbol: 'N₁', label: 'Driver Speed', value: speedDriverN1, unit: 'RPM' },
      { symbol: 'T₁', label: 'Driver Teeth', value: teethT1, unit: 'teeth' },
      { symbol: 'T₂', label: 'Driven Teeth (Gear 2)', value: teethT2, unit: 'teeth' },
      ...(trainType === 'compound' && compoundParams
        ? [
            { symbol: 'T₃', label: 'Compound Gear 3 Teeth', value: compoundParams.teethT3, unit: 'teeth' },
            { symbol: 'T₄', label: 'Follower Gear 4 Teeth', value: compoundParams.teethT4, unit: 'teeth' },
          ]
        : []),
    ],
    toFind: 'Speed of the driven gear (N_driven) and Speed Ratio.',
    formula: formulaStr,
    substitution: subStr,
    step1: `Teeth ratio is inversely proportional to rotational speed (N ∝ 1/T).`,
    step2: `Evaluate product of driven teeth vs driver teeth: ${trainType === 'simple' ? `T₂ / T₁ = ${teethT2}/${teethT1}` : `(T₂ × T₄) / (T₁ × T₃)`}`,
    step3: step3Str,
    step4: `Direction: In external meshing, adjacent gears rotate in OPPOSITE directions.${trainType === 'simple' ? ' If driver is Clockwise, driven is Anti-Clockwise.' : ' Driven gear direction depends on compound pairing count.'}`,
    finalAnswer: {
      symbol: 'N_driven',
      value: speedLastStr,
      unit: 'RPM',
      fullText: `N_driven = ${speedLastStr} RPM (Speed Ratio = ${speedRatioStr}:1)`,
    },
    conceptExplanation: `Bhai gear ka funda bahut simple hai: Bada gear dheere ghoomta hai (zyada torque deta hai) aur chhota gear tezz ghoomta hai (kam torque). Simple gear train me intermediate gears (idlers) speed ratio ko affect nahi karte, sirf rotation direction ko badalte hain! Compound train me space bachane ke liye ek hi shaft par 2 gears lagaye jaate hain.`,
    verification: `Check: Train Value = 1 / Speed Ratio = ${formatNum(1 / speedRatio, 4)}. Speed ratio matches ratio of teeth product!`,
    diagramData: {
      type: 'geartrain',
      trainType,
      speedDriverN1,
      speedLast,
      teethT1,
      teethT2,
    },
  };
}
