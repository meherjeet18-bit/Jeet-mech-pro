/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * JEET MECHANICS PRO
 * Complete Engineering Mechanics Learning & Calculation Android App
 * Diploma First-Year Course Code: TH-7 (2026–27)
 * Created by Jeet
 */

import React, { useState, useEffect } from 'react';
import { SYLLABUS_UNITS } from './data/syllabusData';
import { BlackboardSolution } from './utils/mechanicsEngine';
import { CalculatorsTab } from './components/CalculatorsTab';
import { NotesTab } from './components/NotesTab';
import { PracticeQuizTab } from './components/PracticeQuizTab';
import { FormulaBankModal } from './components/FormulaBankModal';
import { AboutCreatorModal } from './components/AboutCreatorModal';
import { BlackboardSolutionView } from './components/BlackboardSolutionView';
import { usePWAInstall } from './hooks/usePWAInstall';
import {
  Compass,
  Calculator,
  BookOpen,
  Award,
  Download,
  Bookmark,
  History,
  Trash2,
  ChevronRight,
  Sparkles,
  Layers,
  Info,
  CheckCircle2,
  Flame,
  ArrowRight
} from 'lucide-react';

export default function App() {
  const { isInstallable, install } = usePWAInstall();

  // App navigation state
  const [activeTab, setActiveTab] = useState<'calculators' | 'notes' | 'practice' | 'saved'>('calculators');
  const [activeCalculatorId, setActiveCalculatorId] = useState<string>('parallelogram_law');

  // Modals state
  const [showFormulaBank, setShowFormulaBank] = useState<boolean>(false);
  const [showAboutCreator, setShowAboutCreator] = useState<boolean>(false);

  // Splash screen state (skip if ?autostart=1 in URL or previously seen)
  const [showSplash, setShowSplash] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return false;
    }
    return true;
  });

  // Local storage persistence: Calculation History, Bookmarks, and Completed Topics
  const [history, setHistory] = useState<BlackboardSolution[]>(() => {
    try {
      const saved = localStorage.getItem('jeet_mech_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [bookmarks, setBookmarks] = useState<BlackboardSolution[]>(() => {
    try {
      const saved = localStorage.getItem('jeet_mech_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [completedTopicIds, setCompletedTopicIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('jeet_mech_completed_topics');
      return saved ? JSON.parse(saved) : ['u1-t1', 'u2-t1'];
    } catch {
      return ['u1-t1', 'u2-t1'];
    }
  });

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('jeet_mech_history', JSON.stringify(history.slice(0, 20)));
    } catch {}
  }, [history]);

  useEffect(() => {
    try {
      localStorage.setItem('jeet_mech_bookmarks', JSON.stringify(bookmarks));
    } catch {}
  }, [bookmarks]);

  useEffect(() => {
    try {
      localStorage.setItem('jeet_mech_completed_topics', JSON.stringify(completedTopicIds));
    } catch {}
  }, [completedTopicIds]);

  // Automatically dismiss splash after 2.4s if not dismissed manually
  useEffect(() => {
    if (showSplash) {
      const timer = setTimeout(() => {
        setShowSplash(false);
      }, 2400);
      return () => clearTimeout(timer);
    }
  }, [showSplash]);

  const handleSaveToHistory = (solution: BlackboardSolution) => {
    setHistory((prev) => {
      // Avoid duplicate consecutive entries
      if (prev.length > 0 && prev[0].question === solution.question) {
        return prev;
      }
      return [solution, ...prev].slice(0, 20);
    });
  };

  const handleToggleBookmark = (solution: BlackboardSolution) => {
    setBookmarks((prev) => {
      const exists = prev.some((b) => b.solverId === solution.solverId && b.question === solution.question);
      if (exists) {
        return prev.filter((b) => !(b.solverId === solution.solverId && b.question === solution.question));
      } else {
        return [solution, ...prev];
      }
    });
  };

  const handleToggleTopicCompleted = (topicId: string) => {
    setCompletedTopicIds((prev) =>
      prev.includes(topicId) ? prev.filter((id) => id !== topicId) : [...prev, topicId]
    );
  };

  const openCalculator = (calcId: string) => {
    setActiveCalculatorId(calcId);
    setActiveTab('calculators');
  };

  return (
    <div className="min-h-screen bg-[#08101E] text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      {/* ------------------------------------------------------------- */}
      {/* SPLASH SCREEN (A Project by Jeet)                             */}
      {/* ------------------------------------------------------------- */}
      {showSplash && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-b from-[#08101E] via-[#0B192C] to-[#1E3E62] p-6 text-center animate-in fade-in duration-300">
          <div className="relative mb-6">
            <div className="absolute inset-0 rounded-full bg-amber-400/20 blur-xl animate-pulse" />
            <div className="relative p-5 rounded-3xl bg-slate-900/90 border-2 border-amber-400/60 shadow-2xl">
              <img src="/icon.svg" alt="Jeet Mechanics Pro Logo" className="w-24 h-24" />
            </div>
          </div>

          <span className="text-xs font-mono font-bold tracking-widest text-amber-400 uppercase bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20 mb-2">
            Diploma First-Year Course TH-7 (2026–27)
          </span>

          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight mb-2">
            JEET MECHANICS PRO
          </h1>

          <p className="text-base sm:text-lg text-amber-300 font-bold tracking-wider uppercase mb-6">
            A Project by Jeet
          </p>

          <p className="text-xs text-slate-300 max-w-xs sm:max-w-md leading-relaxed mb-8">
            Complete Step-by-Step Blackboard Numerical Solvers, Vector Diagrams, Hinglish Notes & Formula Bank.
          </p>

          <button
            onClick={() => setShowSplash(false)}
            className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-sm shadow-xl hover:from-amber-300 hover:to-amber-400 transition cursor-pointer"
          >
            <span>Start Learning</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TOP APP BAR (Native Android Style Header)                     */}
      {/* ------------------------------------------------------------- */}
      <header className="sticky top-0 z-40 bg-[#0B192C]/95 backdrop-blur-md border-b border-slate-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Brand Logo & Creator */}
          <div className="flex items-center gap-3">
            <div className="p-1 rounded-xl bg-slate-800 border border-amber-400/40 shrink-0">
              <img src="/icon.svg" alt="App Icon" className="w-8 h-8 rounded-lg" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-white text-base sm:text-lg tracking-tight">
                  Jeet Mechanics Pro
                </span>
                <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[10px] font-mono bg-sky-500/20 text-sky-300 border border-sky-500/30">
                  TH-7
                </span>
              </div>
              <div className="text-[11px] font-medium text-amber-400 tracking-wide flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>Created by Jeet</span>
              </div>
            </div>
          </div>

          {/* Action Buttons: Formula Bank, Install App, About Creator */}
          <div className="flex items-center gap-2">
            {/* Formula Bank Button */}
            <button
              onClick={() => setShowFormulaBank(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
              title="Search all formulas"
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Formula Bank</span>
            </button>

            {/* Download Android Project ZIP Button */}
            <a
              href="/downloads/jeet-mechanics-pro-android.zip"
              download="jeet-mechanics-pro-android.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-bold shadow-md transition cursor-pointer no-underline"
              title="Download full Android project ZIP"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Android Project (.zip)</span>
            </a>

            {/* In-App PWA Install Button */}
            {isInstallable && (
              <button
                onClick={install}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold shadow-md transition cursor-pointer"
                title="Install offline application"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Install App</span>
              </button>
            )}

            {/* About Creator Button */}
            <button
              onClick={() => setShowAboutCreator(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-semibold border border-amber-400/30 transition cursor-pointer"
              title="About Creator Jeet & Android APK"
            >
              <Award className="w-3.5 h-3.5" />
              <span className="hidden md:inline">About Jeet</span>
            </button>
          </div>
        </div>

        {/* Primary Tab Navigation */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex border-t border-slate-800/80 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('calculators')}
            className={`flex items-center gap-2 py-3 px-3 sm:px-5 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'calculators'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>Blackboard Solvers</span>
          </button>

          <button
            onClick={() => setActiveTab('notes')}
            className={`flex items-center gap-2 py-3 px-3 sm:px-5 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'notes'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Syllabus Notes (8 Units)</span>
          </button>

          <button
            onClick={() => setActiveTab('practice')}
            className={`flex items-center gap-2 py-3 px-3 sm:px-5 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'practice'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Practice & MCQs</span>
          </button>

          <button
            onClick={() => setActiveTab('saved')}
            className={`flex items-center gap-2 py-3 px-3 sm:px-5 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'saved'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved ({bookmarks.length})</span>
          </button>
        </div>
      </header>

      {/* ------------------------------------------------------------- */}
      {/* MAIN BODY CONTENT                                             */}
      {/* ------------------------------------------------------------- */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 pb-20">
        {/* Tab 1: Calculators */}
        {activeTab === 'calculators' && (
          <CalculatorsTab
            initialCalculatorId={activeCalculatorId}
            onSaveToHistory={handleSaveToHistory}
            onBookmark={handleToggleBookmark}
            bookmarkedIds={bookmarks.map((b) => b.solverId)}
          />
        )}

        {/* Tab 2: Notes */}
        {activeTab === 'notes' && (
          <NotesTab
            onOpenCalculator={openCalculator}
            completedTopicIds={completedTopicIds}
            onToggleTopicCompleted={handleToggleTopicCompleted}
          />
        )}

        {/* Tab 3: Practice & MCQs */}
        {activeTab === 'practice' && (
          <PracticeQuizTab onOpenCalculator={openCalculator} />
        )}

        {/* Tab 4: Saved Bookmarks & History */}
        {activeTab === 'saved' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Bookmark className="w-5 h-5 text-amber-400" />
                <span>Saved Bookmarks & Calculation History</span>
              </h2>
              {history.length > 0 && (
                <button
                  onClick={() => setHistory([])}
                  className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300 font-mono transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear History</span>
                </button>
              )}
            </div>

            {/* Bookmarks Section */}
            <div className="space-y-3">
              <div className="text-xs font-mono font-bold uppercase text-slate-400 tracking-wider">
                Bookmarked Blackboard Solutions ({bookmarks.length})
              </div>

              {bookmarks.length === 0 ? (
                <div className="rounded-xl bg-slate-900/60 border border-slate-800 p-6 text-center text-xs text-slate-400">
                  No bookmarks yet. Tap the bookmark icon on any blackboard solution to save it for quick revision!
                </div>
              ) : (
                <div className="space-y-6">
                  {bookmarks.map((bm, idx) => (
                    <div key={idx} className="relative">
                      <BlackboardSolutionView
                        solution={bm}
                        onBookmark={handleToggleBookmark}
                        isBookmarked={true}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* History Section */}
            <div className="space-y-3 pt-6 border-t border-slate-800">
              <div className="text-xs font-mono font-bold uppercase text-slate-400 tracking-wider">
                Recent Calculations History ({history.length})
              </div>

              {history.length === 0 ? (
                <div className="rounded-xl bg-slate-900/60 border border-slate-800 p-6 text-center text-xs text-slate-400">
                  No calculation history recorded yet. Solve any problem in the Blackboard Solvers tab!
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {history.map((h, i) => (
                    <div
                      key={i}
                      className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                        <span className="text-sky-400 font-semibold">{h.title}</span>
                        <span className="text-amber-400 font-bold">{h.finalAnswer.symbol} = {h.finalAnswer.value} {h.finalAnswer.unit}</span>
                      </div>
                      <p className="text-xs text-slate-300 line-clamp-2">{h.question}</p>
                      <div className="flex justify-end pt-1">
                        <button
                          onClick={() => {
                            setActiveCalculatorId(h.solverId);
                            setActiveTab('calculators');
                          }}
                          className="text-[11px] text-amber-400 hover:text-amber-300 font-medium flex items-center gap-1"
                        >
                          <span>Re-open in Solver</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* ------------------------------------------------------------- */}
      {/* FOOTER                                                        */}
      {/* ------------------------------------------------------------- */}
      <footer className="mt-auto border-t border-slate-800 bg-[#060D18] py-6 px-4 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">Jeet Mechanics Pro</span>
            <span>•</span>
            <span className="text-amber-400 font-medium">Created by Jeet</span>
          </div>

          <div className="text-[11px] text-slate-500 font-mono">
            Diploma First-Year Course Code: TH-7 (2026–27) • 100% Offline
          </div>

          <button
            onClick={() => setShowAboutCreator(true)}
            className="text-slate-400 hover:text-amber-400 transition underline underline-offset-4"
          >
            About & Android APK Guide
          </button>
        </div>
      </footer>

      {/* ------------------------------------------------------------- */}
      {/* MODALS                                                        */}
      {/* ------------------------------------------------------------- */}
      <FormulaBankModal
        isOpen={showFormulaBank}
        onClose={() => setShowFormulaBank(false)}
        onOpenCalculator={openCalculator}
      />

      <AboutCreatorModal
        isOpen={showAboutCreator}
        onClose={() => setShowAboutCreator(false)}
      />
    </div>
  );
}
