package com.jeet.mechanicspro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
