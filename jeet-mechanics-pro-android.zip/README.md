# Jeet Mechanics Pro — Android Project

**Complete Engineering Mechanics Learning & Calculation Android Application**  
*Diploma First-Year Engineering Mechanics (Course Code: TH-7, 2026–27)*  
**Created & Designed by Jeet**

---

## 📱 How to Build the Android APK (`.apk`)

This repository contains the complete Capacitor-powered Android project with all 8 syllabus units, 13-step blackboard solvers, vector diagrams, offline formulas, and quizzes bundled inside `android/app/src/main/assets/public`.

### Option 1: One-Click Build with Android Studio (Recommended)
1. Download and extract this project ZIP.
2. Open **Android Studio**.
3. Click **Open an Existing Project** and select the `android/` folder inside this directory.
4. Wait for Gradle sync to complete (all plugins and dependencies will be configured automatically).
5. From the top menu, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Once built, click **locate** in the popup notification to get your installable **`app-debug.apk`**!
7. Sideload the APK directly onto your Android device.

---

### Option 2: Command Line (Terminal / Mac / Linux / Windows)
If you have Java 17 and Android SDK installed on your computer:
```bash
# Navigate to the android directory
cd android

# On Linux / macOS:
chmod +x gradlew
./gradlew assembleDebug

# On Windows (cmd / PowerShell):
gradlew.bat assembleDebug
```
The output APK will be generated at:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

### Option 3: Free Automatic Cloud APK Build via GitHub Actions
1. Push this project to a GitHub repository.
2. The included `.github/workflows/build-apk.yml` file will automatically run.
3. Once completed, go to the **Actions** tab on your GitHub repository.
4. Click on the latest workflow run and download the **`Jeet-Mechanics-Pro-debug-apk`** artifact ZIP containing your pre-compiled APK!

---

## ✨ Features Included
- **All 8 Syllabus Units**: Complete notes, formulas, and diagrams for Units 1 to 8.
- **13-Step Blackboard Teacher Solution Engine**: Step-by-step intermediate evaluations with mathematical rendering ($\sqrt{}$, $F_x$, $F_y$, $\theta$, $\mu$).
- **Mandatory Numerical Solvers**: Parallelogram Law ($F_1 = 6\text{ N}, F_2 = 8\text{ N}, \theta = 90^\circ \implies R = 10\text{ N}$), Lami's Theorem, Beam Reactions, Friction on Incline, T-Section Centroid, Moment of Inertia, Lifting Machines, and Gear Trains.
- **Interactive Free-Body Diagrams (FBD)**: Vector arrows, right angles, and normal forces rendered dynamically in SVG.
- **100% Offline Capability**: Runs locally on device without network access.

---
*A Project by Jeet*
